import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'ble_sniper_service.dart';
import 'zvt_packet.dart';
import 'offline_tile_server.dart';

void main() => runApp(const BouhProFieldApp());

class BouhProFieldApp extends StatelessWidget {
  const BouhProFieldApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BOUH-ZVT V58 Pro GeoRadar',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050608),
        colorSchemeSeed: const Color(0xFFFFCC00),
      ),
      home: const ProFieldHome(),
    );
  }
}

class ProFieldHome extends StatefulWidget {
  const ProFieldHome({super.key});

  @override
  State<ProFieldHome> createState() => _ProFieldHomeState();
}

class _ProFieldHomeState extends State<ProFieldHome> with SingleTickerProviderStateMixin {
  final BleSniperService _ble = BleSniperService();
  final OfflineTileServer _tileServer = OfflineTileServer();
  final List<ZvtPacket> _events = <ZvtPacket>[];

  late final WebViewController _webController;
  late final AnimationController _pulse;

  StreamSubscription<ZvtPacket>? _packetSub;
  StreamSubscription<String>? _statusSub;
  Timer? _demoTimer;

  ZvtPacket _packet = ZvtPacket.empty();
  String _status = 'OFFLINE';
  bool _demoMode = true;
  bool _showMap = true;
  int _tick = 0;
  int _lastAlertSeq = -1;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 980))..repeat(reverse: true);

    _webController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF050608));

    _startMapEngine();

    _packetSub = _ble.packets.listen((packet) {
      setState(() {
        _demoMode = false;
        _packet = packet;
        _events.insert(0, packet);
        if (_events.length > 50) _events.removeLast();
      });
      _handleAlert(packet);
      _syncWebViewPacket(packet);
    });

    _statusSub = _ble.status.listen((value) => setState(() => _status = value));

    _demoTimer = Timer.periodic(const Duration(milliseconds: 850), (_) {
      if (!_demoMode) return;
      _tick++;
      final packet = ZvtPacket.demo(_tick);
      setState(() {
        _packet = packet;
        _events.insert(0, packet);
        if (_events.length > 50) _events.removeLast();
      });
      _handleAlert(packet);
      _syncWebViewPacket(packet);
    });
  }

  Future<void> _startMapEngine() async {
    try {
      await _tileServer.start();
    } catch (_) {}
    await _webController.loadFlutterAsset('assets/html/field_map_v58.html');
  }


  void _syncWebViewPacket(ZvtPacket packet) {
    final js = "window.BOUH_RENDER_PACKET && window.BOUH_RENDER_PACKET({"
        "decision:'${packet.decisionLabel}',"
        "lat:${packet.latitude},"
        "lon:${packet.longitude},"
        "signal:${packet.signal},"
        "geoBias:${packet.geoBias},"
        "mineralization:${packet.mineralization},"
        "weighted:${packet.weightedDecision}"
        "});";
    _webController.runJavaScript(js);
  }

  void _handleAlert(ZvtPacket packet) {
    if (packet.sequence == _lastAlertSeq) return;
    if (packet.decision == SniperDecision.dig) {
      _lastAlertSeq = packet.sequence;
      _showAlert('DIG NOW', 'هدف قنص حي عالي الأولوية. تحقق ميدانياً فوراً.', const Color(0xFFFFD000), Icons.warning_rounded);
    } else if (packet.decision == SniperDecision.suspect && packet.weightedDecision >= 66) {
      _lastAlertSeq = packet.sequence;
      _showAlert('SUSPECT TARGET', 'اشتباه عرق/جيب غني. كرر المرور من اتجاهين.', const Color(0xFFFF8A00), Icons.radar_rounded);
    }
  }

  void _showAlert(String title, String body, Color color, IconData icon) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: const Color(0xFF111722),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 4),
        content: Row(
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.w900)),
                  Text(body),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _connectLive() async {
    setState(() {
      _demoMode = false;
      _status = 'STARTING LIVE BLE...';
    });
    await _ble.connectLive(deviceNamePrefix: 'BOUH');
  }

  void _toggleDemo() => setState(() {
        _demoMode = !_demoMode;
        _status = _demoMode ? 'DEMO LIVE STREAM' : 'OFFLINE';
      });

  @override
  void dispose() {
    _demoTimer?.cancel();
    _packetSub?.cancel();
    _statusSub?.cancel();
    unawaited(_ble.dispose());
    unawaited(_tileServer.stop());
    _pulse.dispose();
    super.dispose();
  }

  Color get _decisionColor {
    switch (_packet.decision) {
      case SniperDecision.dig:
        return const Color(0xFFFFD000);
      case SniperDecision.suspect:
        return const Color(0xFFFF8A00);
      case SniperDecision.scan:
        return const Color(0xFF00E676);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BOUH-ZVT V58 GeoRadar'),
        actions: [
          IconButton(onPressed: _connectLive, icon: const Icon(Icons.bluetooth_connected_rounded)),
          IconButton(onPressed: () => setState(() => _showMap = !_showMap), icon: Icon(_showMap ? Icons.radar_rounded : Icons.map_rounded)),
          IconButton(onPressed: _toggleDemo, icon: Icon(_demoMode ? Icons.pause_circle : Icons.play_circle)),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            _LiveHeader(status: _demoMode ? 'DEMO LIVE' : _status, packet: _packet, color: _decisionColor),
            Expanded(
              flex: _showMap ? 6 : 4,
              child: _showMap
                  ? Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: WebViewWidget(controller: _webController),
                      ),
                    )
                  : _NativeRadar(packet: _packet, color: _decisionColor, pulse: _pulse),
            ),
            _ActionStrip(packet: _packet, color: _decisionColor),
            _EventFeed(events: _events),
          ],
        ),
      ),
    );
  }
}

class _LiveHeader extends StatelessWidget {
  const _LiveHeader({required this.status, required this.packet, required this.color});

  final String status;
  final ZvtPacket packet;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF101721),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: color.withOpacity(.55)),
        boxShadow: [BoxShadow(color: color.withOpacity(.16), blurRadius: 26)],
      ),
      child: Row(
        children: [
          Icon(Icons.sensors_rounded, color: color, size: 34),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(status, style: const TextStyle(fontWeight: FontWeight.w900)),
              Text(
                'GPS ${packet.latitude.toStringAsFixed(6)}, ${packet.longitude.toStringAsFixed(6)} • ${packet.preset}',
                style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12),
              ),
            ]),
          ),
          Text(packet.decisionLabel, style: TextStyle(color: color, fontSize: 30, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _NativeRadar extends StatelessWidget {
  const _NativeRadar({required this.packet, required this.color, required this.pulse});

  final ZvtPacket packet;
  final Color color;
  final Animation<double> pulse;

  @override
  Widget build(BuildContext context) {
    final signal = packet.weightedDecision.clamp(0, 100) / 100;
    final angle = (packet.sequence % 360) * math.pi / 180;
    final radius = 24 + 110 * signal;
    final x = math.cos(angle) * radius;
    final y = math.sin(angle) * radius;

    return AnimatedBuilder(
      animation: pulse,
      builder: (_, __) {
        final size = 40 + pulse.value * 16 + signal * 44;
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            color: const Color(0xFF101721),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white.withOpacity(.10)),
          ),
          child: Center(
            child: Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 320,
                  height: 320,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: color.withOpacity(.30), width: 2),
                    gradient: RadialGradient(colors: [color.withOpacity(.20), color.withOpacity(.08), Colors.transparent]),
                  ),
                ),
                for (final r in [90.0, 150.0])
                  Container(width: r, height: r, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.10)))),
                Transform.translate(
                  offset: Offset(x, y),
                  child: Container(
                    width: size,
                    height: size,
                    decoration: BoxDecoration(color: color, shape: BoxShape.circle, boxShadow: [BoxShadow(color: color.withOpacity(.60), blurRadius: 30, spreadRadius: 8)]),
                    child: const Icon(Icons.gps_fixed_rounded, color: Colors.black),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ActionStrip extends StatelessWidget {
  const _ActionStrip({required this.packet, required this.color});

  final ZvtPacket packet;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xEE101721),
      margin: const EdgeInsets.fromLTRB(10, 8, 10, 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          LinearProgressIndicator(
            minHeight: 11,
            borderRadius: BorderRadius.circular(99),
            value: packet.weightedDecision.clamp(0, 100) / 100,
            color: color,
            backgroundColor: Colors.white.withOpacity(.09),
          ),
          const SizedBox(height: 9),
          Row(children: [
            Expanded(child: _MiniMetric(label: 'Signal', value: packet.signal.toStringAsFixed(0))),
            Expanded(child: _MiniMetric(label: 'Geo', value: '${(packet.geoBias * 100).toStringAsFixed(0)}%')),
            Expanded(child: _MiniMetric(label: 'Mineral', value: '${(packet.mineralization * 100).toStringAsFixed(0)}%')),
            Expanded(child: _MiniMetric(label: 'Large', value: packet.largeMass ? 'YES' : 'NO')),
          ]),
        ]),
      ),
    );
  }
}

class _MiniMetric extends StatelessWidget {
  const _MiniMetric({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Text(label, style: TextStyle(color: Colors.white.withOpacity(.55), fontSize: 11)),
      const SizedBox(height: 3),
      Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
    ]);
  }
}

class _EventFeed extends StatelessWidget {
  const _EventFeed({required this.events});

  final List<ZvtPacket> events;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 142,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(10, 0, 10, 8),
        itemCount: events.take(12).length,
        itemBuilder: (_, index) {
          final e = events[index];
          final color = e.decision == SniperDecision.dig
              ? const Color(0xFFFFD000)
              : e.decision == SniperDecision.suspect
                  ? const Color(0xFFFF8A00)
                  : const Color(0xFF00E676);
          return Card(
            color: const Color(0xFF101721),
            child: ListTile(
              dense: true,
              leading: Icon(Icons.bolt_rounded, color: color),
              title: Text('${e.decisionLabel} • ${e.weightedDecision.toStringAsFixed(1)}%'),
              subtitle: Text('TauLate ${e.tauLate.toStringAsFixed(0)} µs • LowF ${e.lowFrequencyNoise.toStringAsFixed(2)} • Iron ${e.ironScore.toStringAsFixed(0)}'),
            ),
          );
        },
      ),
    );
  }
}
