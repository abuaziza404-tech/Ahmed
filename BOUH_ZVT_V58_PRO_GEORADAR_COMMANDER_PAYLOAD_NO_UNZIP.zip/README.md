# BOUH-ZVT Pro Field App

تطبيق Flutter Android جاهز للرفع إلى GitHub Actions.

## يحتوي على

- Flutter Android app
- WebView لخريطة V4 Smooth Field Map
- BLE Live Client
- Native Radar
- Pop-up alerts عند DIG/SUSPECT
- بيانات خلايا علمية داخل `assets/data/targets.json`
- Firmware Teensy
- Firmware ESP32 BLE Bridge
- GitHub Actions لبناء APK/AAB

## البيانات

```text
target_count: 2000
source: /mnt/data/BOUH_V56_HIGH_DENSITY_EARTH_READER_FUSION/BOUH_V56_top_earth_reader_targets.csv
extra_data_files: BOUH_V56_top_earth_reader_targets.csv, BOUH_V55_top_geological_targets.csv, priority_sample.csv
```

## البنية

```text
lib/
android/
assets/html/
assets/data/
firmware/teensy/
firmware/esp32_ble_bridge/
.github/workflows/build.yml
```

## GitHub Actions

بعد الرفع:

```text
Actions → Build BOUH-ZVT Pro Field Android → Run workflow
```

سيتم إنتاج:

```text
BOUH-ZVT-Pro-debug-apk
BOUH-ZVT-Pro-release-apk
BOUH-ZVT-Pro-release-aab
```

## BLE Packet

```text
decision=DIG,lat=19.8251647,lon=36.7557669,gps=1.2,mineralization=0.78,geoBias=0.84,signal=94,weighted=91,tauLate=760,lateEarly=0.64,lowFreq=0.16,iron=22,gold=88,largeMass=1,temp=42.0,preset=SINKAT,seq=1201
```

## UUID

```text
Device: BOUH-ZVT-LIVE
Service: 6e400001-b5a3-f393-e0a9-e50e24dcca9e
Notify:  6e400003-b5a3-f393-e0a9-e50e24dcca9e
```

## تنبيه

DIG/SUSPECT يعني أولوية تحقق ميداني عالية، وليس إثباتًا مباشرًا للذهب.


## Offline MBTiles

تمت إضافة `assets/offline/BOUH_FIELD_OFFLINE.mbtiles` و `lib/offline_tile_server.dart`.

التطبيق يشغل خادم تايلات داخلي:

```text
http://127.0.0.1:8765
```

وتظهر طبقة `BOUH Offline MBTiles` داخل الخريطة.


## V57 Hybrid Commander Safe Merge

تم دمج قاعدة V52 الكبيرة بدون إضعاف النظام.

```text
V52 full DB: assets/data/BOUH_V52_92253_REAL_3ZONES.db
V52 cells: 92253
V52 max score: 96
V56 targets preserved: 2000
Hybrid display targets: 8000
Offline MBTiles: preserved
BLE Live Client: preserved
GitHub Actions no-unzip: preserved
```

الهدف من الدمج:
- الحفاظ على سرعة الخريطة.
- إبقاء قاعدة 92,253 cell كاملة داخل التطبيق.
- عرض طبقة خفيفة هجينة لا تكسر الأداء.
- عدم إضعاف BLE أو MBTiles أو الرادار.


## V57.1 Kotlin JVM Target Fix

تم إصلاح خطأ Gradle/Kotlin JVM target validation بتوحيد Java و Kotlin على target 17.

الملفات المعدلة:

```text
android/app/build.gradle
android/build.gradle
android/gradle.properties
tools/validate_android_config.py
```


## V58 Pro GeoRadar Commander

تمت إضافة نظام خريطة/رادار متكامل:

```text
field_map_v58.html
BOUH_V58_georadar_analysis_cells.json
Linked radar map pin
Ground coordinate analysis
Cell-density layer
Flutter → WebView packet sync
```

النسخة تحافظ على بيانات V52/V56 وأنظمة BLE وOffline MBTiles ونظام GitHub Actions.
