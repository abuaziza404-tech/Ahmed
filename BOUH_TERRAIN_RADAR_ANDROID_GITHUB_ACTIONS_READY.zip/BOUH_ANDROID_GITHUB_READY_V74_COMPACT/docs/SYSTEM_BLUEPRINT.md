# BOUH V70 System Blueprint

## Offline
SQLite/CSV cells drive field use without internet. Values must be labeled as saved/proxy unless derived from raw raster.

## Online
FastAPI + PostGIS + Celery/Redis worker pipeline:
1. ingest AOI and user files,
2. fetch Sentinel-2/Sentinel-1/Landsat/ASTER/DEM when authorized,
3. preprocess via GDAL/Rasterio/PyProj,
4. compute spectral/terrain/structure indicators,
5. update cells and target ranking,
6. sync field evidence.

## Scores
BOUH_SCORE = 0.25 Structure + 0.20 Terrain + 0.20 Alteration + 0.15 Pattern + 0.10 Field Evidence + 0.10 Noise Control - penalties.

No confirmed gold label without field recovery/assay/QAQC.
