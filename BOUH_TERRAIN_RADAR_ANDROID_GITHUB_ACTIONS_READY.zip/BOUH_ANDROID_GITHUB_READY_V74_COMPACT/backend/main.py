from __future__ import annotations
from fastapi import FastAPI
from pydantic import BaseModel
from datetime import datetime

app = FastAPI(title="BOUH Smart Discovery API", version="0.70.0")

class AnalyzeRequest(BaseModel):
    lat: float
    lon: float
    radius_m: int = 500
    source_status: str | None = None

@app.get("/health")
def health():
    return {"ok": True, "engine": "BOUH_V70_BACKEND_BLUEPRINT", "time": datetime.utcnow().isoformat()+"Z"}

@app.post("/analyze")
def analyze(req: AnalyzeRequest):
    # Placeholder endpoint for future raw-raster recomputation.
    return {
        "ok": True,
        "lat": req.lat,
        "lon": req.lon,
        "mode": "backend_blueprint_only",
        "message": "Connect PostGIS + raw Sentinel/Landsat/ASTER/DEM pipeline to compute true refreshed indices.",
        "updated_score": None,
        "target_type": None,
        "confidence": None,
    }
