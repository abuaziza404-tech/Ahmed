# BOUH Backend Skeleton

هيكل للمرحلة السحابية: FastAPI + PostGIS + Celery/Redis + Rasterio/GDAL.
هذه الملفات توثيقية/تمهيدية ولا تدخل في بناء APK.
