# BOUH WebView app: keep JavaScript bridge if added later
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
