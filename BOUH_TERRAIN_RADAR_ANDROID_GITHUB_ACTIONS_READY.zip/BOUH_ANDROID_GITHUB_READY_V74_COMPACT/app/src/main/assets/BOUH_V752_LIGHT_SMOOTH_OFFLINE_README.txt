V75.2: smoothed offline layers, JPG compressed, duplicate runtimes removed.
