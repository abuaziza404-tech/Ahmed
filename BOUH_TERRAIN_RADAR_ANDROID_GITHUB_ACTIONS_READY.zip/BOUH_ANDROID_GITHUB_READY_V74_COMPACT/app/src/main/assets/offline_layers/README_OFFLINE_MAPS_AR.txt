هذه نسخة GitHub مضغوطة أقل من 25MB.
الخرائط المحلية عالية الدقة لا تُدمج داخل ZIP حتى لا يتجاوز حد GitHub.
التطبيق يدعم On-demand cache ويدعم إضافة MBTiles/XYZ لاحقًا داخل assets/offline_tiles أو تنزيلها بعد التثبيت.
