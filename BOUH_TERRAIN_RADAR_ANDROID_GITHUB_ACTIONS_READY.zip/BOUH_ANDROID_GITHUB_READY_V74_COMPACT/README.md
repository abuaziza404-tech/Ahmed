BOUH Terrain Radar V74 Compact package for GitHub Actions. Heavy offline tiles are excluded to keep ZIP under 25MB. On-demand caching and offline layer hooks remain available.
