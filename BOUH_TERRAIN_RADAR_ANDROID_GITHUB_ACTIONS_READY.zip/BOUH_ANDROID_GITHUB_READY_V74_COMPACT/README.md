BOUH Terrain Radar V74 Compact package for GitHub Actions. Heavy offline tiles are excluded to keep ZIP under 25MB. On-demand caching and offline layer hooks remain available.


V74.2: زيادة عرض الخلايا الفعالة من 2,500 إلى 12,000، وخلايا العلامات الأولية إلى 2,500، والـ Heatmap إلى 6,000. لم تتم إضافة خلايا ذهب وهمية؛ كل التوسعة من RAW_CELLS المحفوظة وTOP60.
