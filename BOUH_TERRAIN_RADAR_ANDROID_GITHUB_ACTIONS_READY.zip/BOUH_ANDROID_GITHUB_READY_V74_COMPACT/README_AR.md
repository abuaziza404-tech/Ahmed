BOUH Terrain Radar V74.9 Hard Offline Runtime

هذه الحزمة تضيف محرك خريطة محلي احتياطي وطبقات صور Offline داخل APK لضمان عدم توقف التطبيق عند انقطاع الإنترنت.
