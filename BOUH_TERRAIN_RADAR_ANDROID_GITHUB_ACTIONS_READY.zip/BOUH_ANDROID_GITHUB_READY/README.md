# BOUH Terrain Radar Android — GitHub Actions Ready

هذه الحزمة تحول نسخة HTML المعتمدة لمحرك BOUH V68 إلى تطبيق Android WebView يحافظ على واجهة V52/V65 ويحمّل `index.html` من assets.

## البناء
- ارفع هذه الملفات إلى GitHub أو ارفع ZIP المصدر واستخدم ملف workflow المرفق في الرسالة.
- GitHub Actions يبني APK Debug تلقائيًا.

## ملاحظات صدق
- الخلايا والتحليل المحلي يعملان من داخل `index.html`.
- جلب Sentinel/Landsat/ASTER الخام والتحديث 24/7 يحتاج Backend فعلي كما هو موضح في `docs/SYSTEM_BLUEPRINT.md`.
