# BOUH FieldScout V13 Auto-Darbeel

نسخة ميدانية واقعية لمشروع BOUH:
- كاميرا RealView.
- تكبير رقمي حقيقي عبر Camera2 crop region حتى حد كاميرا الجهاز.
- أزرار 2X / 5X / 10X و ZOOM+/ZOOM-.
- Clarity للتحليل البصري وليس ادعاء طيفي.
- Auto Scan يحلل الإطار بصريًا: brightness/contrast/edges/texture/quartz-like/FeOx-like/vegetation-risk/dark-regolith proxy.
- Manual gates: Structure / Carrier / FeOx / Trap.
- Decision Class A/B/C/Reject وفق قاعدة الصدق.
- GPZ 7000 strategy.
- Save+Photo مع الإحداثيات.
- Export CSV.

تنبيه: تحليل الكاميرا بصري ميداني فقط ولا ينتج نسب طيفية. التحليل الطيفي الحقيقي يحتاج GeoTIFF/RAW bands/DEM.
