package com.bouh.fieldscout;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener, LocationListener {
    private TextureView textureView;
    private TextView hudTop, hudAnalysis, hudDecision;
    private CameraDevice cameraDevice;
    private CameraCaptureSession session;
    private CaptureRequest.Builder requestBuilder;
    private HandlerThread bgThread;
    private Handler bgHandler;
    private ImageReader imageReader;
    private CameraCharacteristics characteristics;
    private Rect activeArray;
    private float zoom = 1.0f;
    private float maxZoom = 8.0f;
    private int clarity = 3;
    private boolean torch = false;
    private boolean autoAnalyzer = true;
    private boolean boostPreview = false;
    private String cameraId;
    private Size previewSize = new Size(1280, 720);
    private long frameCount = 0;
    private long fpsStart = System.currentTimeMillis();
    private int fps = 0;
    private double lat = 0, lon = 0, alt = 0;
    private float heading = 0;
    private SensorManager sensorManager;
    private LocationManager locationManager;
    private final float[] gravityValues = new float[3];
    private final float[] magValues = new float[3];
    private boolean hasGravity = false, hasMag = false;

    private int manualStructure = 0; // 0 none, 1 weak, 2 clear, 3 strong
    private int manualCarrier = 0;   // 0 none, 1 clay weak, 2 clay/silica, 3 quartz+clay
    private int manualFeOx = 0;      // 0 none, 1 light, 2 gossan, 3 laterite risk
    private int manualTrap = 0;      // 0 none, 1 wadi, 2 pediment, 3 ridge/shear
    private String lastAuto = "Waiting for frames...";
    private String lastDecision = "Decision pending";
    private final ArrayList<String> records = new ArrayList<>();

    private static final int REQ = 404;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        buildUi();
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (!hasPerms()) requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ);
    }

    private boolean hasPerms() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (hasPerms() && textureView.isAvailable()) openCamera();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        textureView = new TextureView(this);
        root.addView(textureView, new FrameLayout.LayoutParams(-1, -1));
        textureView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) { if (hasPerms()) openCamera(); }
            public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st) { return true; }
            public void onSurfaceTextureUpdated(SurfaceTexture st) {}
        });

        LinearLayout overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setPadding(18, 18, 18, 18);
        overlay.setBackgroundColor(Color.argb(40,0,0,0));
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        hudTop = label(22, Color.rgb(238,214,140));
        hudAnalysis = label(18, Color.WHITE);
        hudDecision = label(19, Color.rgb(255,226,120));
        overlay.addView(hudTop);
        overlay.addView(hudAnalysis);
        overlay.addView(hudDecision);

        View spacer = new View(this);
        overlay.addView(spacer, new LinearLayout.LayoutParams(1,0,1));

        ScrollView panelScroll = new ScrollView(this);
        panelScroll.setFillViewport(false);
        panelScroll.setBackgroundColor(Color.argb(155,0,0,0));
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(8, 8, 8, 28);
        panelScroll.addView(panel);
        overlay.addView(panelScroll, new LinearLayout.LayoutParams(-1, dp(285)));

        TextView title = label(18, Color.rgb(238,214,140));
        title.setText("BOUH FieldScout V13 Auto-Darbeel — تكبير واضح + تحليل بصري ميداني حقيقي");
        panel.addView(title);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        panel.addView(grid);
        addBtn(grid, "ZOOM-", v -> setZoom(zoom - 0.5f));
        addBtn(grid, "ZOOM+", v -> setZoom(zoom + 0.5f));
        addBtn(grid, "2X", v -> setZoom(2f));
        addBtn(grid, "5X", v -> setZoom(5f));
        addBtn(grid, "10X", v -> setZoom(10f));
        addBtn(grid, "CLARITY+", v -> { clarity = Math.min(9, clarity+1); updateDecision(); });
        addBtn(grid, "CLARITY-", v -> { clarity = Math.max(0, clarity-1); updateDecision(); });
        addBtn(grid, "RAW/BOOST", v -> { boostPreview = !boostPreview; textureView.setAlpha(boostPreview?0.92f:1f); updateDecision(); });
        addBtn(grid, "TORCH", v -> { torch = !torch; applyRequest(); });
        addBtn(grid, "AUTO SCAN", v -> { autoAnalyzer = !autoAnalyzer; updateDecision(); });
        addBtn(grid, "SAVE+PHOTO", v -> savePhotoRecord());
        addBtn(grid, "EXPORT", v -> exportRecords());

        addBtn(grid, "STRUCT", v -> { manualStructure = (manualStructure+1)%4; updateDecision(); });
        addBtn(grid, "CARRIER", v -> { manualCarrier = (manualCarrier+1)%4; updateDecision(); });
        addBtn(grid, "FEOX", v -> { manualFeOx = (manualFeOx+1)%4; updateDecision(); });
        addBtn(grid, "TRAP", v -> { manualTrap = (manualTrap+1)%4; updateDecision(); });

        TextView truth = label(16, Color.LTGRAY);
        truth.setText("قاعدة الصدق: التحليل التلقائي من الكاميرا = بصري ميداني فقط. لا نسب طيفية ولا قرار حفر نهائي بدون GeoTIFF/DEM/عينات.");
        panel.addView(truth);

        setContentView(root);
        updateDecision();
    }

    private TextView label(int sp, int color) {
        TextView t = new TextView(this);
        t.setTextSize(sp); t.setTextColor(color); t.setShadowLayer(4,1,1,Color.BLACK);
        return t;
    }

    private void addBtn(GridLayout grid, String s, View.OnClickListener l) {
        Button b = new Button(this); b.setText(s); b.setTextSize(13); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundColor(Color.argb(190, 70,70,70)); b.setOnClickListener(l);
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams(); lp.width = dp(84); lp.height = dp(48); lp.setMargins(5,5,5,5);
        grid.addView(b, lp);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onResume() {
        super.onResume(); startBg();
        Sensor acc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensor mag = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if (acc != null) sensorManager.registerListener(this, acc, SensorManager.SENSOR_DELAY_UI);
        if (mag != null) sensorManager.registerListener(this, mag, SensorManager.SENSOR_DELAY_UI);
        try { if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 1, this); } catch(Exception ignored) {}
        if (textureView.isAvailable() && hasPerms()) openCamera();
    }
    @Override protected void onPause() { closeCamera(); stopBg(); try { sensorManager.unregisterListener(this); locationManager.removeUpdates(this);} catch(Exception ignored){} super.onPause(); }

    private void startBg(){ bgThread = new HandlerThread("bouh-camera"); bgThread.start(); bgHandler = new Handler(bgThread.getLooper()); }
    private void stopBg(){ if(bgThread!=null){ bgThread.quitSafely(); try{bgThread.join();}catch(Exception ignored){} bgThread=null; bgHandler=null; } }

    private void openCamera() {
        try {
            CameraManager cm = (CameraManager)getSystemService(Context.CAMERA_SERVICE);
            for (String id: cm.getCameraIdList()) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) { cameraId = id; characteristics = cc; break; }
            }
            if (cameraId == null) return;
            activeArray = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            Float mz = characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            if (mz != null) maxZoom = Math.max(2f, Math.min(20f, mz));
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null && map.getOutputSizes(SurfaceTexture.class) != null) previewSize = chooseSize(map.getOutputSizes(SurfaceTexture.class));
            imageReader = ImageReader.newInstance(640, 480, android.graphics.ImageFormat.YUV_420_888, 2);
            imageReader.setOnImageAvailableListener(r -> { Image img = null; try { img = r.acquireLatestImage(); if (img != null) analyzeFrame(img); } finally { if (img != null) img.close(); } }, bgHandler);
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
            cm.openCamera(cameraId, new CameraDevice.StateCallback() {
                public void onOpened(CameraDevice c) { cameraDevice = c; createSession(); }
                public void onDisconnected(CameraDevice c) { c.close(); cameraDevice=null; }
                public void onError(CameraDevice c, int e) { c.close(); cameraDevice=null; runOnUiThread(() -> hudAnalysis.setText("Camera error: "+e)); }
            }, bgHandler);
        } catch(Exception e) { hudAnalysis.setText("Open camera failed: "+e.getMessage()); }
    }

    private Size chooseSize(Size[] sizes) {
        Size best = sizes[0];
        for (Size s: sizes) if (s.getWidth() <= 1920 && s.getWidth() > best.getWidth()) best = s;
        return best;
    }

    private void createSession() {
        try {
            SurfaceTexture st = textureView.getSurfaceTexture(); if (st == null) return;
            st.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            Surface preview = new Surface(st);
            requestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            requestBuilder.addTarget(preview);
            requestBuilder.addTarget(imageReader.getSurface());
            cameraDevice.createCaptureSession(Arrays.asList(preview, imageReader.getSurface()), new CameraCaptureSession.StateCallback() {
                public void onConfigured(CameraCaptureSession s) { session=s; applyRequest(); }
                public void onConfigureFailed(CameraCaptureSession s) { runOnUiThread(() -> hudAnalysis.setText("Camera session failed")); }
            }, bgHandler);
        } catch(Exception e) { runOnUiThread(() -> hudAnalysis.setText("Session failed: "+e.getMessage())); }
    }

    private void closeCamera(){ try{ if(session!=null) session.close(); if(cameraDevice!=null) cameraDevice.close(); if(imageReader!=null) imageReader.close(); }catch(Exception ignored){} session=null; cameraDevice=null; imageReader=null; }

    private void setZoom(float z) { zoom = Math.max(1f, Math.min(maxZoom, z)); applyRequest(); updateDecision(); }

    private void applyRequest() {
        if (session == null || requestBuilder == null) return;
        try {
            requestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            requestBuilder.set(CaptureRequest.CONTROL_AE_MODE, torch ? CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH : CaptureRequest.CONTROL_AE_MODE_ON);
            requestBuilder.set(CaptureRequest.FLASH_MODE, torch ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            if (activeArray != null) requestBuilder.set(CaptureRequest.SCALER_CROP_REGION, cropForZoom(zoom));
            session.setRepeatingRequest(requestBuilder.build(), null, bgHandler);
        } catch(CameraAccessException ignored) {}
    }

    private Rect cropForZoom(float z) {
        int w = activeArray.width(), h = activeArray.height();
        int cropW = (int)(w / z), cropH = (int)(h / z);
        int left = activeArray.left + (w - cropW)/2;
        int top = activeArray.top + (h - cropH)/2;
        return new Rect(left, top, left+cropW, top+cropH);
    }

    private void analyzeFrame(Image img) {
        frameCount++; long now = System.currentTimeMillis();
        if (now - fpsStart >= 1000) { fps = (int)frameCount; frameCount = 0; fpsStart = now; }
        if (!autoAnalyzer) return;
        int w = img.getWidth(), h = img.getHeight();
        Image.Plane yP = img.getPlanes()[0], uP = img.getPlanes()[1], vP = img.getPlanes()[2];
        ByteBuffer yb = yP.getBuffer(), ub = uP.getBuffer(), vb = vP.getBuffer();
        int yStride = yP.getRowStride(), uStride = uP.getRowStride(), vStride = vP.getRowStride();
        int uPix = uP.getPixelStride(), vPix = vP.getPixelStride();
        long sum=0, sum2=0; int n=0, bright=0, red=0, green=0, dark=0, edge=0, rough=0;
        int step = 8 + Math.max(0, 6-clarity);
        for (int yy=step; yy<h-step; yy+=step) {
            for (int xx=step; xx<w-step; xx+=step) {
                int yi = yy*yStride + xx;
                if (yi < 0 || yi >= yb.limit()) continue;
                int Y = yb.get(yi) & 0xff;
                int Y2 = yb.get(yy*yStride + Math.min(w-1, xx+step)) & 0xff;
                int Y3 = yb.get(Math.min(h-1, yy+step)*yStride + xx) & 0xff;
                int ui = (yy/2)*uStride + (xx/2)*uPix;
                int vi = (yy/2)*vStride + (xx/2)*vPix;
                int U=128, V=128;
                if (ui>=0 && ui<ub.limit()) U = ub.get(ui)&0xff;
                if (vi>=0 && vi<vb.limit()) V = vb.get(vi)&0xff;
                int C = Y - 16, D = U - 128, E = V - 128;
                int R = clamp((298*C + 409*E + 128) >> 8);
                int G = clamp((298*C - 100*D - 208*E + 128) >> 8);
                int B = clamp((298*C + 516*D + 128) >> 8);
                sum += Y; sum2 += Y*Y; n++;
                if (Y > 178 && Math.abs(R-G)<30 && Math.abs(R-B)<35) bright++;
                if (R > G*1.16 && R > B*1.12 && Y > 45) red++;
                if (G > R*1.10 && G > B*1.08 && Y > 50) green++;
                if (Y < 62 && R >= G && G >= B) dark++;
                int d = Math.abs(Y-Y2)+Math.abs(Y-Y3);
                if (d > 55) edge++;
                if (d > 32) rough++;
            }
        }
        if (n == 0) return;
        double mean = sum/(double)n; double variance = sum2/(double)n - mean*mean;
        double contrast = Math.sqrt(Math.max(0, variance));
        int q = pct(bright,n), ox = pct(red,n), veg = pct(green,n), dr = pct(dark,n), ed = pct(edge,n), tex = pct(rough,n);
        String terrain = "Visual: ";
        if (veg > 22) terrain += "Vegetation/noise high; ";
        if (q > 5) terrain += "quartz/silica-like bright pixels; ";
        if (ox > 8) terrain += "FeOx/gossan-like redness; ";
        if (dr > 18) terrain += "dark regolith proxy; ";
        if (ed > 10 || tex > 25) terrain += "high texture/line edges; ";
        if (terrain.equals("Visual: ")) terrain += "no strong visual carrier in camera frame; ";
        String caution = "AUTO VISUAL ONLY";
        lastAuto = String.format(Locale.US, "%s | mean %.0f contrast %.0f | Q-like %d%% FeOx-like %d%% VegRisk %d%% DarkReg %d%% Edge %d%% Texture %d%%", terrain, mean, contrast, q, ox, veg, dr, ed, tex);
        runOnUiThread(() -> updateDecision());
    }

    private int clamp(int v){ return Math.max(0, Math.min(255, v)); }
    private int pct(int a, int n){ return (int)Math.round(100.0*a/Math.max(1,n)); }

    private void updateDecision() {
        String sName = new String[]{"لا توجد", "ضعيفة", "واضحة", "Shear/Dilation قوي"}[manualStructure];
        String cName = new String[]{"لا يوجد", "Clay/Silica ضعيف", "Clay/Silica واضح", "Quartz+Clay قوي"}[manualCarrier];
        String fName = new String[]{"لا يوجد", "FeOx خفيف", "FeOx/Gossan واضح", "FeOx أحمر/Laterite خطر"}[manualFeOx];
        String tName = new String[]{"لا توجد", "Wadi/Drainage", "Pediment/Hill-foot", "Ridge/Shear trap"}[manualTrap];
        int score = 0;
        score += manualStructure * 25;
        score += manualCarrier * 18;
        score += Math.min(2, manualFeOx) * 8;
        score += manualTrap * 10;
        boolean reject = manualStructure == 0 || manualCarrier == 0 || (manualFeOx > 0 && manualStructure == 0);
        String cls;
        if (reject) cls = "REJECT / HOLD: لا Structure أو لا Clay/Silica/Quartz";
        else if (score >= 95) cls = "CLASS A: فحص GPZ + عينة + توثيق";
        else if (score >= 70) cls = "CLASS B: اختبار مسارات قصيرة + عينات";
        else cls = "CLASS C: ملاحظة/مرور فقط";
        String gpz;
        if (manualFeOx == 3) gpz = "GPZ: Severe/Difficult | High Yield | Sens 8-11 | Audio Low/On | swing slow";
        else if (manualCarrier >= 2 && manualFeOx <= 1) gpz = "GPZ: Normal | General/Deep | Sens 12-16 | Audio Off | ركز جيوب bedrock";
        else gpz = "GPZ: Difficult | High Yield | Sens 9-12 | Ground balance متكرر";
        lastDecision = cls + "\n" + gpz;
        hudTop.setText(String.format(Locale.US, "BOUH FIELDSCOUT V13 AUTO-DARBEEL • FPS %d | Z %.1fx/%.1f | clarity %d | torch %s\n%.6f, %.6f | alt %.0fm | head %.0f°", fps, zoom, maxZoom, clarity, torch?"ON":"OFF", lat, lon, alt, heading));
        hudAnalysis.setText("AUTO: " + lastAuto);
        hudDecision.setText("Manual gates: Structure="+sName+" | Carrier="+cName+" | FeOx="+fName+" | Trap="+tName+"\n"+lastDecision);
    }

    private void savePhotoRecord() {
        try {
            Bitmap bm = textureView.getBitmap();
            if (bm != null) {
                String name = "BOUH_V13_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/BOUH_FieldScout_V13");
                Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                if (uri != null) { OutputStream os = getContentResolver().openOutputStream(uri); bm.compress(Bitmap.CompressFormat.JPEG, 92, os); if(os!=null) os.close(); }
            }
            String rec = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()) + "," + lat + "," + lon + "," + alt + "," + heading + "," + lastDecision.replace('\n',' ') + "," + lastAuto.replace(',', ';');
            records.add(rec);
            Toast.makeText(this, "Saved field photo + record", Toast.LENGTH_SHORT).show();
        } catch(Exception e) { Toast.makeText(this, "Save failed: "+e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void exportRecords() {
        try {
            StringBuilder csv = new StringBuilder("time,lat,lon,alt,heading,decision,auto_visual\n");
            for(String r: records) csv.append(r).append('\n');
            String name = "BOUH_FieldScout_V13_records_"+System.currentTimeMillis()+".csv";
            ContentValues cv = new ContentValues(); cv.put(MediaStore.Downloads.DISPLAY_NAME, name); cv.put(MediaStore.Downloads.MIME_TYPE, "text/csv"); cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            OutputStream os = getContentResolver().openOutputStream(uri); os.write(csv.toString().getBytes()); os.close();
            Toast.makeText(this, "Exported CSV to Downloads", Toast.LENGTH_LONG).show();
        } catch(Exception e) { Toast.makeText(this, "Export failed: "+e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    @Override public void onSensorChanged(SensorEvent e) {
        if (e.sensor.getType()==Sensor.TYPE_ACCELEROMETER) { System.arraycopy(e.values,0,gravityValues,0,3); hasGravity=true; }
        if (e.sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD) { System.arraycopy(e.values,0,magValues,0,3); hasMag=true; }
        if (hasGravity && hasMag) { float[] R=new float[9], I=new float[9]; if(SensorManager.getRotationMatrix(R,I,gravityValues,magValues)){ float[] o=new float[3]; SensorManager.getOrientation(R,o); heading=(float)((Math.toDegrees(o[0])+360)%360); } }
    }
    @Override public void onAccuracyChanged(Sensor s, int a) {}
    @Override public void onLocationChanged(Location l) { lat=l.getLatitude(); lon=l.getLongitude(); alt=l.hasAltitude()?l.getAltitude():0; runOnUiThread(this::updateDecision); }
}
