# BOUH Darbeel V8 Photon-Telescope

نسخة احترافية تركز على التفاصيل والمسافة بدون الاعتماد على شاشة خضراء.

## المحرك
- Photon Stack لتجميع الإطارات الضعيفة
- Super Range لرفع تفاصيل المركز والأجسام البعيدة
- Local contrast + Laplacian detail recovery
- Dehaze للغبار/الضباب
- أوضاع REAL DETAIL / PHOTON STACK / TELESCOPE FAR / STARLIGHT / DUST FOG CUT

## الصدق الفيزيائي
لا يمكن لأي تطبيق هاتف أن يرى في ظلام مطلق بلا ضوء. للحصول على اختراق ظلام فعلي استخدم IR 850/940nm أو حساس حراري خارجي مع عدسة تقريب وحامل ثابت.
