package com.bouh.darbeel;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import android.location.*;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Semaphore;

public class MainActivity extends Activity implements SensorEventListener, LocationListener {
    private static final int REQ = 4047;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private ImageReader reader;
    private HandlerThread camThread;
    private Handler camHandler;
    private ProcessingView view;
    private String cameraId;
    private final Semaphore cameraLock = new Semaphore(1);
    private int mode = 0, range = 2, lens = 0;
    private float zoom = 1.0f, gain = 1.35f, gamma = 0.72f, contrast = 1.20f, detail = 0.55f, denoise = 0.35f, dehaze = 0.25f;
    private boolean tripod = false, torch = false, autoBrain = true, photonStack = true, superRange = true;
    private long lastFrameNs=0; private float fps=0;
    private Bitmap latestBitmap;
    private int[] prevY;
    private int[] stackY; private int stackCount=0;
    private float heading=0, altitude=0; private double lat=0, lon=0; private boolean hasLoc=false;
    private SensorManager sensorManager; private LocationManager locationManager;
    private final String[] modes = {"REAL DETAIL", "PHOTON STACK", "TELESCOPE FAR", "STARLIGHT LIFT", "DUST/FOG CUT", "DESERT NATURAL", "EDGE LOCK", "IR READY", "GREEN OPTIONAL"};
    private final String[] ranges = {"NEAR", "MID", "FAR", "EXTREME"};
    private final String[] lenses = {"PHONE", "CLIP 3X", "CLIP 5X", "SCOPE 10X"};

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); buildUi(); sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE); locationManager=(LocationManager)getSystemService(LOCATION_SERVICE); if(Build.VERSION.SDK_INT>=23 && (checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)){requestPermissions(new String[]{Manifest.permission.CAMERA,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION}, REQ);} }
    @Override public void onResume(){ super.onResume(); startThreads(); openCamera(); Sensor s=sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION); if(s!=null) sensorManager.registerListener(this,s,SensorManager.SENSOR_DELAY_UI); try{ if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1500,1,this);}catch(Exception ignored){} }
    @Override public void onPause(){ closeCamera(); if(sensorManager!=null) sensorManager.unregisterListener(this); try{locationManager.removeUpdates(this);}catch(Exception ignored){} stopThreads(); super.onPause(); }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g); openCamera();}

    private void buildUi(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK); view=new ProcessingView(this); root.addView(view,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout side=new LinearLayout(this); side.setOrientation(LinearLayout.VERTICAL); side.setPadding(12,12,12,12); side.setAlpha(0.88f);
        String[] labels={"MODE","RANGE","LENS","ZOOM+","ZOOM-","GAIN+","GAIN-","DETAIL+","DETAIL-","DENOISE+","STACK","SUPER RANGE","TRIPOD","TORCH","CAPTURE"};
        for(String l:labels){ Button bt=new Button(this); bt.setText(l); bt.setTextSize(10); bt.setAllCaps(false); bt.setPadding(6,3,6,3); bt.setOnClickListener(v->handleButton(((Button)v).getText().toString())); side.addView(bt,new LinearLayout.LayoutParams(dp(112),dp(38))); }
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(128),-2,Gravity.RIGHT|Gravity.CENTER_VERTICAL); root.addView(side,sp);
        TextView title=new TextView(this); title.setText("BOUH DARBEEL V8 PHOTON-TELESCOPE  •  Ahmed Abu Aziza"); title.setTextColor(Color.rgb(230,210,130)); title.setShadowLayer(3,1,1,Color.BLACK); title.setTextSize(13); title.setPadding(16,10,16,10); root.addView(title,new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT));
        TextView hint=new TextView(this); hint.setText("Photon Stack + Super Range + dehaze/detail recovery. No green screen default."); hint.setTextColor(Color.LTGRAY); hint.setTextSize(10); hint.setPadding(16,0,16,16); root.addView(hint,new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.LEFT));
        setContentView(root);
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);} 
    private void handleButton(String l){ if(l.equals("MODE")) mode=(mode+1)%modes.length; else if(l.equals("RANGE")) range=(range+1)%ranges.length; else if(l.equals("LENS")) lens=(lens+1)%lenses.length; else if(l.equals("ZOOM+")) zoom=Math.min(8f,zoom+0.35f); else if(l.equals("ZOOM-")) zoom=Math.max(1f,zoom-0.35f); else if(l.equals("GAIN+")) gain=Math.min(3.8f,gain+0.15f); else if(l.equals("GAIN-")) gain=Math.max(0.7f,gain-0.15f); else if(l.equals("DETAIL+")) detail=Math.min(1.4f,detail+0.12f); else if(l.equals("DENOISE+")) denoise=denoise>0.85f?0.1f:denoise+0.12f; else if(l.equals("DETAIL-")) detail=Math.max(0.05f,detail-0.12f); else if(l.equals("STACK")){photonStack=!photonStack; stackY=null; stackCount=0;} else if(l.equals("SUPER RANGE")) superRange=!superRange; else if(l.equals("TRIPOD")) tripod=!tripod; else if(l.equals("TORCH")){torch=!torch; applyTorch();} else if(l.equals("CAPTURE")) saveCapture(); view.invalidate(); }

    private void startThreads(){ camThread=new HandlerThread("BOUH-Camera"); camThread.start(); camHandler=new Handler(camThread.getLooper()); }
    private void stopThreads(){ if(camThread!=null){camThread.quitSafely(); try{camThread.join();}catch(Exception ignored){} camThread=null; camHandler=null;} }
    private void openCamera(){ if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) return; try{ CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE); cameraId=cm.getCameraIdList()[0]; for(String id:cm.getCameraIdList()){CameraCharacteristics cc=cm.getCameraCharacteristics(id); Integer facing=cc.get(CameraCharacteristics.LENS_FACING); if(facing!=null && facing==CameraCharacteristics.LENS_FACING_BACK){cameraId=id; break;}} reader=ImageReader.newInstance(960,540,ImageFormat.YUV_420_888,3); reader.setOnImageAvailableListener(this::onImage,camHandler); cameraLock.acquire(); cm.openCamera(cameraId,new CameraDevice.StateCallback(){ public void onOpened(CameraDevice c){cameraLock.release(); camera=c; createSession();} public void onDisconnected(CameraDevice c){cameraLock.release(); c.close(); camera=null;} public void onError(CameraDevice c,int e){cameraLock.release(); c.close(); camera=null;}},camHandler);}catch(Exception e){Toast.makeText(this,"Camera error: "+e.getMessage(),Toast.LENGTH_LONG).show();} }
    private void closeCamera(){ try{cameraLock.acquire(); if(session!=null){session.close(); session=null;} if(camera!=null){camera.close(); camera=null;} if(reader!=null){reader.close(); reader=null;}}catch(Exception ignored){} finally{cameraLock.release();} }
    private void createSession(){ try{ CaptureRequest.Builder b=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW); b.addTarget(reader.getSurface()); b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE); b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON); camera.createCaptureSession(Collections.singletonList(reader.getSurface()),new CameraCaptureSession.StateCallback(){ public void onConfigured(CameraCaptureSession s){session=s; try{session.setRepeatingRequest(b.build(),null,camHandler);}catch(Exception ignored){}} public void onConfigureFailed(CameraCaptureSession s){}},camHandler);}catch(Exception ignored){} }
    private void applyTorch(){ try{ if(camera==null||session==null) return; CaptureRequest.Builder b=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW); b.addTarget(reader.getSurface()); b.set(CaptureRequest.FLASH_MODE, torch?CaptureRequest.FLASH_MODE_TORCH:CaptureRequest.FLASH_MODE_OFF); b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE); session.setRepeatingRequest(b.build(),null,camHandler);}catch(Exception ignored){} }

    private void onImage(ImageReader ir){ Image img=null; try{img=ir.acquireLatestImage(); if(img==null) return; long now=System.nanoTime(); if(lastFrameNs>0) fps=0.90f*fps+0.10f*(1_000_000_000f/(now-lastFrameNs)); lastFrameNs=now; processYuv(img); }catch(Exception ignored){} finally{ if(img!=null) img.close(); } }
    private void processYuv(Image img){ int w=img.getWidth(), h=img.getHeight(); Image.Plane yp=img.getPlanes()[0]; ByteBuffer yb=yp.getBuffer(); int stride=yp.getRowStride(); int[] out=new int[w*h]; int[] yarr=new int[w*h]; byte[] row=new byte[stride]; for(int yy=0;yy<h;yy++){ yb.position(yy*stride); yb.get(row,0,Math.min(stride,yb.remaining()+stride)); for(int x=0;x<w;x++){yarr[yy*w+x]=row[x]&255;} }
        autoTune(yarr,w,h); int den=(int)(denoise*100); boolean usePrev=prevY!=null && prevY.length==yarr.length; int rBoost = (range==3?18:range==2?10:0) + (lens==3?8:lens==2?5:0); for(int y=1;y<h-1;y++){ int off=y*w; for(int x=1;x<w-1;x++){ int i=off+x; int v=yarr[i]; if(usePrev){ v=(v*(100-den)+prevY[i]*den)/100; }
                if(photonStack || tripod || mode==1){
                    if(stackY!=null && stackY.length==yarr.length){
                        int oldStack=stackY[i];
                        int weight = tripod ? 7 : 4;
                        v = (v*weight + oldStack*(10-weight))/10;
                    }
                }
                int lap = (v*4 - yarr[i-1]-yarr[i+1]-yarr[i-w]-yarr[i+w]);
                int diag=(yarr[i-w-1]+yarr[i-w+1]+yarr[i+w-1]+yarr[i+w+1])/4;
                int local=(yarr[i-1]+yarr[i+1]+yarr[i-w]+yarr[i+w]+diag)/5;
                float dx=(x-w*0.5f)/(w*0.5f), dy=(y-h*0.5f)/(h*0.5f);
                float centerWeight=1.0f - Math.min(0.55f,(dx*dx+dy*dy)*0.35f);
                int contrastLift=(int)((v-128)*(contrast + (superRange?0.12f:0f))*centerWeight+128);
                int deh=(int)(v + dehaze*(v-local));
                int farBoost = (superRange && (mode==2 || range>=2)) ? (int)(Math.abs(lap)*0.22f + (128-Math.abs(v-128))*0.03f) : 0;
                int vv=(int)(contrastLift*0.48 + deh*0.40 + lap*detail*centerWeight + farBoost);
                vv=(int)(Math.pow(Math.max(0,Math.min(255,vv))/255.0, gamma)*255.0*gain)+rBoost;
                vv=Math.max(0,Math.min(255,vv)); int color=mapModeColor(vv, v, lap); out[i]=color; } }
        if((photonStack||tripod||mode==1) && (stackY==null || stackY.length!=yarr.length)){ stackY=new int[yarr.length]; System.arraycopy(yarr,0,stackY,0,yarr.length); stackCount=1; }
        else if(photonStack||tripod||mode==1){ int keep=tripod?8:5; for(int i=0;i<yarr.length;i++){ stackY[i]=(stackY[i]*(keep-1)+yarr[i])/keep; } stackCount=Math.min(99,stackCount+1); }
        prevY=yarr; latestBitmap=Bitmap.createBitmap(out,w,h,Bitmap.Config.ARGB_8888); runOnUiThread(()->view.setFrame(latestBitmap)); }
    private void autoTune(int[] y,int w,int h){ if(!autoBrain) return; long sum=0; int step=7; for(int i=0;i<y.length;i+=step) sum+=y[i]; float mean=sum/(float)(y.length/step); if(mean<38){gain=2.45f; gamma=0.50f; contrast=1.42f; denoise=tripod?0.62f:0.38f; detail=0.72f;} else if(mean<70){gain=1.95f; gamma=0.62f; contrast=1.32f; detail=0.66f;} else {gain=1.22f; gamma=0.86f; contrast=1.12f; detail=0.48f;} if(mode==1 || mode==2 || range>=2){dehaze=0.48f; detail+=0.24f; contrast+=0.10f;} if(mode==4){dehaze=0.82f; contrast+=0.24f;} if(superRange && range>=2){detail+=0.18f; gamma=Math.max(0.48f,gamma-0.05f);} }
    private int mapModeColor(int vv,int raw,int lap){ if(mode==5){ return Color.rgb(clamp((int)(vv*1.08)),clamp((int)(vv*1.01)),clamp((int)(vv*0.84))); } if(mode==6){ int e=clamp(Math.abs(lap)*3); return Color.rgb(e,e,e); } if(mode==7){ return Color.rgb(clamp((int)(vv*1.15)),clamp((int)(vv*0.75)),clamp((int)(vv*0.55))); } if(mode==8){ return Color.rgb(0,clamp((int)(vv*1.15)),clamp(vv/4)); } if(mode==3){ int c=clamp((int)(vv*1.15)); return Color.rgb(c,c,clamp((int)(c*0.92))); } return Color.rgb(vv,vv,vv); }
    private int clamp(int v){return Math.max(0,Math.min(255,v));}

    private void saveCapture(){ try{ if(latestBitmap==null) return; String ts=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date()); ContentValues cv=new ContentValues(); cv.put(MediaStore.Images.Media.DISPLAY_NAME,"BOUH_DARBEEL_V8_"+ts+".jpg"); cv.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg"); cv.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/BOUH_Darbeel_V8_PhotonTelescope"); Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv); OutputStream os=getContentResolver().openOutputStream(uri); latestBitmap.compress(Bitmap.CompressFormat.JPEG,94,os); os.close(); Toast.makeText(this,"Saved Photon-Telescope capture",Toast.LENGTH_SHORT).show(); }catch(Exception e){Toast.makeText(this,"Save failed: "+e.getMessage(),Toast.LENGTH_LONG).show();} }

    @Override public void onSensorChanged(SensorEvent e){ heading=e.values[0]; view.invalidate(); }
    @Override public void onAccuracyChanged(Sensor s,int a){}
    @Override public void onLocationChanged(Location l){ lat=l.getLatitude(); lon=l.getLongitude(); altitude=(float)l.getAltitude(); hasLoc=true; view.invalidate(); }

    public class ProcessingView extends View{ private Bitmap frame; private Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); public ProcessingView(Context c){super(c);} public void setFrame(Bitmap b){frame=b; invalidate();}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); int W=getWidth(),H=getHeight(); if(frame!=null){ Rect src=new Rect(0,0,frame.getWidth(),frame.getHeight()); float z=zoom*(lens==1?1.18f:lens==2?1.38f:lens==3?1.70f:1f); int dw=(int)(frame.getWidth()/z), dh=(int)(frame.getHeight()/z); src.set((frame.getWidth()-dw)/2,(frame.getHeight()-dh)/2,(frame.getWidth()+dw)/2,(frame.getHeight()+dh)/2); c.drawBitmap(frame,src,new Rect(0,0,W,H),null);} else {c.drawColor(Color.BLACK);} drawHud(c,W,H); }
        private void drawHud(Canvas c,int W,int H){ p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.argb(140,230,210,130)); float cx=W/2f, cy=H/2f, r=Math.min(W,H)*0.30f; c.drawCircle(cx,cy,r,p); c.drawLine(cx-r*0.72f,cy,cx-r*0.16f,cy,p); c.drawLine(cx+r*0.16f,cy,cx+r*0.72f,cy,p); c.drawLine(cx,cy-r*0.72f,cx,cy-r*0.16f,p); c.drawLine(cx,cy+r*0.16f,cx,cy+r*0.72f,p);
            p.setStyle(Paint.Style.FILL); p.setTextSize(24); p.setColor(Color.argb(225,245,235,180)); c.drawText(String.format(Locale.US,"FPS %.0f | %s | %s | %s | Z %.1fx",fps,modes[mode],ranges[range],lenses[lens],zoom),18,58,p); p.setTextSize(20); c.drawText(String.format(Locale.US,"GAIN %.2f  GAMMA %.2f  DETAIL %.2f  DENOISE %.2f  DEHAZE %.2f",gain,gamma,detail,denoise,dehaze),18,88,p); p.setTextSize(18); String loc=hasLoc?String.format(Locale.US,"GPS %.5f, %.5f  ALT %.0fm",lat,lon,altitude):"GPS searching"; c.drawText(String.format(Locale.US,"HDG %.0f°  %s  TRIPOD %s  STACK %s  RANGEAI %s  TORCH %s",heading,loc,tripod?"ON":"OFF",photonStack?"ON":"OFF",superRange?"ON":"OFF",torch?"ON":"OFF"),18,H-28,p); }
    }
}
