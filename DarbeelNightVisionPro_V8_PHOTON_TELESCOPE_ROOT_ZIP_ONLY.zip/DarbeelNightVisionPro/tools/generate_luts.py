import json, math, os
from pathlib import Path

def gamma_lut(gamma, gain=1.0):
    return [max(0,min(255,int((i/255.0)**gamma*255*gain))) for i in range(256)]

def sigmoid_lut(k=8.0, mid=0.45):
    out=[]
    for i in range(256):
        x=i/255.0
        y=1/(1+math.exp(-k*(x-mid)))
        out.append(max(0,min(255,int(y*255))))
    return out

assets=Path('app/src/main/assets'); assets.mkdir(parents=True, exist_ok=True)
profile={
  'engine':'BOUH Darbeel V8 Photon Telescope',
  'truth':'software enhancement needs photons; IR/thermal hardware required for true darkness',
  'luts':{
    'starlight': gamma_lut(0.48,1.18),
    'real_detail': gamma_lut(0.72,1.05),
    'long_range': sigmoid_lut(7.5,0.38),
    'dust_fog_cut': sigmoid_lut(9.5,0.46)
  },
  'pipeline':['YUV luminance','temporal photon stack','adaptive gamma','local contrast','laplacian detail','dehaze','super range center weighting']
}
(assets/'bouh_v8_photon_luts.json').write_text(json.dumps(profile, indent=2))
print('Generated', assets/'bouh_v8_photon_luts.json')
