import cv2, numpy as np
from pathlib import Path

out=Path('build/vision-test'); out.mkdir(parents=True, exist_ok=True)
h,w=360,640
y=np.zeros((h,w),np.uint8)
# synthetic darkness + faint far objects + fog
cv2.rectangle(y,(300,140),(342,190),28,-1)
cv2.circle(y,(445,158),18,34,-1)
cv2.line(y,(80,260),(570,235),30,1)
noise=np.random.default_rng(1447).normal(0,7,(h,w)).astype(np.int16)
dark=np.clip(y.astype(np.int16)+noise+8,0,255).astype(np.uint8)
blur=cv2.GaussianBlur(dark,(0,0),2.2)
# local contrast and detail recovery
clahe=cv2.createCLAHE(clipLimit=2.8,tileGridSize=(8,8)).apply(dark)
sharp=cv2.addWeighted(clahe,1.65,cv2.GaussianBlur(clahe,(0,0),1.1),-0.65,0)
edge=cv2.Laplacian(sharp,cv2.CV_16S,ksize=3)
edge=cv2.convertScaleAbs(edge)
fused=cv2.addWeighted(sharp,0.88,edge,0.35,0)
cv2.imwrite(str(out/'input_dark.png'),dark)
cv2.imwrite(str(out/'v8_detail_recovery.png'),fused)
score=float(fused.std())/max(1,float(dark.std()))
Path(out/'vision_score.txt').write_text(f'contrast_recovery_ratio={score:.3f}\n')
assert score>1.20, score
print('V8 validation passed, contrast recovery ratio',score)
