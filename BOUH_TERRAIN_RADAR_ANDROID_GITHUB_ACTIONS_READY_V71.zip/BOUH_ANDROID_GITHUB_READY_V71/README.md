# BOUH Terrain Radar V71

GitHub Actions ready Android WebView package. V71 preserves the approved UI and adds guarded prospectivity scoring, improved HD map layer defaults, Arabic indicators, and safer score caps outside trusted coverage.
