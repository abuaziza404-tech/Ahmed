# BOUH MapScout V22.4 Stable Overzoom GPS UI

## Critical fixes
- GPS jitter fix:
  - Location updates request minDistance=2m.
  - Internal accept filter ignores movement <2m unless stale/better.
  - Low-pass smoothing for coordinates.
  - Bearing smoothing using circular low-pass filter.

- Infinite overzoom:
  - display max zoom = Z24.
  - native max zoom = Z17.
  - Tile URL clamps z/x/y to parent tile, avoiding layer disappearance after Z17.8.
  - Visual overzoom only; no true extra satellite resolution.

- Dynamic buttons:
  - Q activates Quartz/Clay style.
  - Fe activates Iron style.
  - P activates Prospecting Radar style + power mode.
  - GPR/Paleo/Drainage bars update from pin point and radar model.

- UI:
  - Floating toolbar.
  - Draggable bottom sheet.
  - Modern dark UI.
