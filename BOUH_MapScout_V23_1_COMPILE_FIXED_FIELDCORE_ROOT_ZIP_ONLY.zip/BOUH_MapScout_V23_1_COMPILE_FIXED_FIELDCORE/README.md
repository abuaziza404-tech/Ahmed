# BOUH MapScout V23.1 Compile Fixed FieldCore

إصلاح مباشر للخطأ الفعلي في GitHub Actions:
- osmdroid MapView.setMaxZoomLevel يحتاج Double.
- تم تحويل:
  map.setMaxZoomLevel(OverzoomTileSources.DISPLAY_MAX_ZOOM)
  إلى:
  map.setMaxZoomLevel((double) OverzoomTileSources.DISPLAY_MAX_ZOOM)

الميزات:
- Native osmdroid MapView.
- Infinite Overzoom Z24 مع native Z17 clamp.
- GPS jitter filter 2m.
- Floating toolbar.
- Pin Drop.
- Radar proxy.
- Dynamic GPR/Paleo/Drainage bars.
- Fe/Q/P modes.
- SQLite waypoints.
- KML/CSV export.
