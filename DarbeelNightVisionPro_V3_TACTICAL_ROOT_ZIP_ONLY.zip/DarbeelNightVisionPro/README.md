# Darbeel Night Vision Pro V3 Tactical

Android camera app for digital night-vision style low-light viewing.

Features:
- Camera2 live preview
- Tactical HUD
- Green Ultra, White Boost, Amber Desert, Edge Scout, Red Low-Light, Blue Haze modes
- Zoom, exposure, gain, gamma, contrast controls
- Ultra Night toggle
- Torch light toggle when hardware supports flash
- Capture processed screen image into Pictures/DarbeelV3

Technical note: this is digital low-light enhancement. It is not thermal or true infrared unless the phone or external camera hardware provides such sensors.
