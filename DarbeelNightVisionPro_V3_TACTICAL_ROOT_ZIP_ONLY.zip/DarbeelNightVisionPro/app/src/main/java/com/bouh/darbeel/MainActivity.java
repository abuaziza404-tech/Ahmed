package com.bouh.darbeel;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.hardware.camera2.*;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 77;
    private TextureView texture;
    private HudView hud;
    private TextView status;
    private LinearLayout controls;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private CaptureRequest.Builder builder;
    private CameraManager cameraManager;
    private String cameraId;
    private Rect activeArray;
    private boolean flashOn = false;
    private boolean hudVisible = true;
    private boolean ultraNight = true;
    private int mode = 0;
    private float zoom = 1.5f;
    private float maxZoom = 8f;
    private int exposure = 0;
    private float gain = 2.4f;
    private float gamma = 0.62f;
    private float contrast = 1.35f;
    private long frameCount = 0;
    private long lastFpsTs = 0;
    private int fps = 0;

    private final String[] modeNames = {"GREEN ULTRA", "WHITE BOOST", "AMBER DESERT", "EDGE SCOUT", "RED LOW-LIGHT", "BLUE HAZE"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        buildUi();
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        else openWhenReady();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        texture = new TextureView(this);
        root.addView(texture, new FrameLayout.LayoutParams(-1, -1));
        hud = new HudView(this);
        root.addView(hud, new FrameLayout.LayoutParams(-1, -1));
        status = new TextView(this);
        status.setTextColor(Color.rgb(155,255,155));
        status.setTextSize(13);
        status.setShadowLayer(5,0,0,Color.BLACK);
        status.setPadding(16,16,16,16);
        root.addView(status, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP|Gravity.START));

        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(12,12,12,22);
        controls.setBackgroundColor(Color.argb(42,0,0,0));
        addRow("ULTRA", "LIGHT", "MODE", "CAPTURE");
        addRow("GAIN-", "GAIN+", "ZOOM-", "ZOOM+");
        addRow("EXP-", "EXP+", "CON-", "CON+");
        addRow("GAMMA-", "GAMMA+", "RESET", "HUD");
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(controls, cp);
        root.setOnClickListener(v -> toggleHud());
        setContentView(root);
        updateStatus();
    }

    private void addRow(String... names) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        for (String n: names) {
            Button bt = new Button(this);
            bt.setText(n);
            bt.setTextColor(Color.WHITE);
            bt.setTextSize(12);
            bt.setAllCaps(false);
            bt.setBackgroundColor(Color.argb(165,70,70,70));
            bt.setOnClickListener(v -> action(n));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 48, 1f);
            lp.setMargins(5,5,5,5);
            row.addView(bt, lp);
        }
        controls.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private void action(String a) {
        switch (a) {
            case "ULTRA": ultraNight = !ultraNight; if (ultraNight) { gain = Math.max(gain, 2.8f); gamma = Math.min(gamma, 0.55f); contrast = Math.max(contrast, 1.45f);} break;
            case "LIGHT": flashOn = !flashOn; break;
            case "MODE": mode = (mode + 1) % modeNames.length; break;
            case "CAPTURE": saveCapture(); return;
            case "GAIN-": gain = clamp(gain - .25f, 1f, 6f); break;
            case "GAIN+": gain = clamp(gain + .25f, 1f, 6f); break;
            case "ZOOM-": zoom = clamp(zoom - .5f, 1f, maxZoom); break;
            case "ZOOM+": zoom = clamp(zoom + .5f, 1f, maxZoom); break;
            case "EXP-": exposure = Math.max(-6, exposure - 1); break;
            case "EXP+": exposure = Math.min(6, exposure + 1); break;
            case "CON-": contrast = clamp(contrast - .1f, .7f, 2.6f); break;
            case "CON+": contrast = clamp(contrast + .1f, .7f, 2.6f); break;
            case "GAMMA-": gamma = clamp(gamma - .05f, .25f, 1.8f); break;
            case "GAMMA+": gamma = clamp(gamma + .05f, .25f, 1.8f); break;
            case "RESET": zoom=1.5f; gain=2.4f; gamma=.62f; contrast=1.35f; exposure=0; ultraNight=true; flashOn=false; break;
            case "HUD": toggleHud(); break;
        }
        hud.invalidate(); updateStatus(); applyCameraParams();
    }

    private float clamp(float v, float a, float b){ return Math.max(a, Math.min(b, v)); }
    private void toggleHud(){ hudVisible=!hudVisible; int vis=hudVisible?View.VISIBLE:View.GONE; hud.setVisibility(vis); controls.setVisibility(vis); status.setVisibility(vis); }

    private void openWhenReady(){ texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
        @Override public void onSurfaceTextureAvailable(android.graphics.SurfaceTexture st, int w, int h){ openCamera(); }
        @Override public void onSurfaceTextureSizeChanged(android.graphics.SurfaceTexture st, int w, int h){}
        @Override public boolean onSurfaceTextureDestroyed(android.graphics.SurfaceTexture st){ return true; }
        @Override public void onSurfaceTextureUpdated(android.graphics.SurfaceTexture st){ tickFps(); }
    }); if(texture.isAvailable()) openCamera(); }

    private void openCamera() {
        try {
            for (String id : cameraManager.getCameraIdList()) {
                CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) { cameraId = id; break; }
            }
            if(cameraId == null) cameraId = cameraManager.getCameraIdList()[0];
            CameraCharacteristics ch = cameraManager.getCameraCharacteristics(cameraId);
            activeArray = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            Float mz = ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            if(mz != null) maxZoom = Math.min(10f, Math.max(2f, mz));
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
                    @Override public void onOpened(CameraDevice c) { camera = c; startPreview(); }
                    @Override public void onDisconnected(CameraDevice c) { c.close(); }
                    @Override public void onError(CameraDevice c, int e) { Toast.makeText(MainActivity.this,"Camera error "+e,Toast.LENGTH_LONG).show(); c.close(); }
                }, null);
        } catch(Exception e){ Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void startPreview(){
        try{
            android.graphics.SurfaceTexture st = texture.getSurfaceTexture();
            st.setDefaultBufferSize(1280,720);
            Surface s = new Surface(st);
            builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            builder.addTarget(s);
            camera.createCaptureSession(Arrays.asList(s), new CameraCaptureSession.StateCallback(){
                @Override public void onConfigured(CameraCaptureSession cs){ session=cs; applyCameraParams(); }
                @Override public void onConfigureFailed(CameraCaptureSession cs){ Toast.makeText(MainActivity.this,"Preview failed",Toast.LENGTH_LONG).show(); }
            }, null);
        }catch(Exception e){ Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void applyCameraParams(){
        if(builder == null || session == null) return;
        try{
            builder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
            builder.set(CaptureRequest.CONTROL_AE_MODE, flashOn ? CaptureRequest.CONTROL_AE_MODE_ON : CaptureRequest.CONTROL_AE_MODE_ON);
            builder.set(CaptureRequest.FLASH_MODE, flashOn ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            builder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, exposure);
            if(activeArray != null){
                int cx = activeArray.centerX(), cy = activeArray.centerY();
                int w = (int)(activeArray.width()/zoom), h=(int)(activeArray.height()/zoom);
                Rect crop = new Rect(cx-w/2, cy-h/2, cx+w/2, cy+h/2);
                builder.set(CaptureRequest.SCALER_CROP_REGION, crop);
            }
            session.setRepeatingRequest(builder.build(), null, null);
        }catch(Exception ignored){}
    }

    private void tickFps(){ frameCount++; long now=System.currentTimeMillis(); if(lastFpsTs==0) lastFpsTs=now; if(now-lastFpsTs>=1000){ fps=(int)frameCount; frameCount=0; lastFpsTs=now; updateStatus(); } }
    private void updateStatus(){ if(status!=null) status.setText("Active | FPS "+fps+" | Flash "+(flashOn?"ON":"OFF")+" | V3 Tactical\nMode: "+modeNames[mode]+" | Zoom "+String.format(Locale.US,"%.1f",zoom)+"x/"+String.format(Locale.US,"%.1f",maxZoom)+"x | Gain "+String.format(Locale.US,"%.2f",gain)+" | Gamma "+String.format(Locale.US,"%.2f",gamma)+"\nContrast "+String.format(Locale.US,"%.2f",contrast)+" | EXP "+exposure+" | Ultra "+(ultraNight?"ON":"OFF")); }

    private void saveCapture(){
        try{
            Bitmap src = texture.getBitmap();
            if(src == null){ Toast.makeText(this,"No frame",Toast.LENGTH_SHORT).show(); return; }
            Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(out); c.drawBitmap(src,0,0,null); hud.drawFilterOnly(c, out.getWidth(), out.getHeight());
            String name = "Darbeel_V3_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
            ContentValues values = new ContentValues(); values.put(MediaStore.Images.Media.DISPLAY_NAME, name); values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg"); values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DarbeelV3");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if(uri != null){ OutputStream os = getContentResolver().openOutputStream(uri); out.compress(Bitmap.CompressFormat.JPEG, 92, os); if(os != null) os.close(); Toast.makeText(this,"Saved: "+name,Toast.LENGTH_SHORT).show(); }
        }catch(Exception e){ Toast.makeText(this,"Capture failed: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==REQ_CAMERA && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) openWhenReady(); else finish(); }
    @Override protected void onPause(){ super.onPause(); try{ if(session!=null) session.close(); if(camera!=null) camera.close(); }catch(Exception ignored){} session=null; camera=null; }
    @Override protected void onResume(){ super.onResume(); if(texture!=null && texture.isAvailable() && camera==null && checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) openCamera(); }

    class HudView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        public HudView(Context c){ super(c); }
        @Override protected void onDraw(Canvas c){ super.onDraw(c); drawFilterOnly(c,getWidth(),getHeight()); drawScope(c); }
        void drawFilterOnly(Canvas c, int w, int h){
            int overlay; switch(mode){
                case 1: overlay = Color.argb(45,255,255,255); break;
                case 2: overlay = Color.argb(75,255,150,40); break;
                case 3: overlay = Color.argb(55,120,255,120); break;
                case 4: overlay = Color.argb(70,255,40,40); break;
                case 5: overlay = Color.argb(60,70,120,255); break;
                default: overlay = Color.argb(80,40,255,70);
            }
            p.setStyle(Paint.Style.FILL); p.setColor(overlay); c.drawRect(0,0,w,h,p);
            if(ultraNight){ p.setColor(Color.argb((int)(25*gain),120,255,120)); c.drawRect(0,0,w,h,p); }
            // vignette rings, visible night scope impression
            float cx=w/2f, cy=h/2f, r=Math.min(w,h)*0.46f;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(28); p.setColor(Color.argb(105,0,0,0)); c.drawCircle(cx,cy,r,p);
        }
        void drawScope(Canvas c){
            int w=getWidth(), h=getHeight(); float cx=w/2f, cy=h/2f; float r=Math.min(w,h)*0.115f;
            p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(92,110,255,120)); c.drawCircle(cx,cy,r*1.45f,p);
            p.setColor(Color.argb(105,130,255,130)); c.drawCircle(cx,cy,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.argb(190,180,255,180));
            c.drawCircle(cx,cy,r,p); c.drawLine(cx-r*.85f,cy,cx-r*.20f,cy,p); c.drawLine(cx+r*.20f,cy,cx+r*.85f,cy,p); c.drawLine(cx,cy-r*.85f,cx,cy-r*.20f,p); c.drawLine(cx,cy+r*.20f,cx,cy+r*.85f,p);
            p.setTextSize(18); p.setColor(Color.argb(160,180,255,180)); p.setStyle(Paint.Style.FILL); c.drawText("BOUH V3", cx-r, cy+r+24, p);
        }
    }
}
