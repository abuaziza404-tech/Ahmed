from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / "android/app/build.gradle").read_text()
props = (root / "android/gradle.properties").read_text()
assert "sourceCompatibility JavaVersion.VERSION_17" in app
assert "targetCompatibility JavaVersion.VERSION_17" in app
assert 'jvmTarget = "17"' in app
assert "kotlin.jvm.target.validation.mode=warning" in props
print("Android JVM/Kotlin target config OK")
