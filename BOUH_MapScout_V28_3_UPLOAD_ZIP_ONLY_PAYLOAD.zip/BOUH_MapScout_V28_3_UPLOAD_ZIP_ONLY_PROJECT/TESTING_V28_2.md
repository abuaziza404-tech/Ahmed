# TESTING V28.2 — BOUH Gold Support Radar

## Pre-upload checks

```bash
python3 tools/validate_gold_radar_dataset.py . --write-report qa_gold_support_report.json
python3 tools/generate_gold_support_preview.py . qa_gold_support_preview.csv
```

Expected:

```text
Each CSV file: rows OK
GoldSupport% min/mean/max printed
Top 5 targets printed
qa_gold_support_report.json created
qa_gold_support_preview.csv created
```

## GitHub Actions tests

1. Repository contains direct Android files:
   - `settings.gradle`
   - `build.gradle`
   - `app/build.gradle`
   - `app/src/main/AndroidManifest.xml`
   - `app/src/main/assets/*.csv`
   - `.github/workflows/build-bouh-mapscout-v28-2.yml`

2. Workflow stage `Validate Android source layout` passes.

3. Workflow stage `Validate terrain CSV and scoring model` passes.

4. Workflow stage `Build debug APK with stacktrace` passes.

5. Artifact contains:
   - `BOUH_MapScout_V28_2_GOLD_SUPPORT_RADAR.apk`
   - `qa_gold_support_report.json`
   - `qa_gold_support_preview.csv`
   - `BUILD_INFO.txt`

## APK smoke tests

1. Install APK.
2. Open app.
3. Confirm title shows `BOUH Terrain Truth Radar V28.2`.
4. Deny GPS once.
   - Expected: app still shows targets from local data.
5. Grant GPS.
   - Expected: radar uses distance and bearing.
6. Tap each visible target chip.
   - Expected: details update.
7. Tap `Navigate`.
   - Expected: Android opens maps geo URI.
8. Tap `Export`.
   - Expected: analyzed CSV copied to clipboard.
9. Turn off network.
   - Expected: app still loads local CSV assets.

## Data replacement test with 156k cells

1. Add the full grid:

```text
app/src/main/assets/bouh_truth_grid_v27_156k.csv
```

2. Keep the same required columns.
3. Run:

```bash
python3 tools/validate_gold_radar_dataset.py . --write-report qa_gold_support_report.json
```

4. Confirm row count is approximately 156000.
5. Push to GitHub and build again.

## Acceptance criteria

- No missing CSV columns.
- All lat/lon values in valid ranges.
- All `GoldSupport%` values between 0 and 100.
- APK builds in GitHub Actions.
- App loads without internet.
- Radar and target details are usable on phone.
