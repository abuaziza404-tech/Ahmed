# BOUH MapScout V28.2 — Gold Support Radar

Android field-radar app for ranking terrain cells by surface indicators supportive of possible gold-mineralization environments.

> Scientific note: `GoldSupport%` is an exploration-support score. It is not proof that gold exists. Field mapping, samples, assays, structural interpretation, alteration mapping, and expert validation are required.

## Why V28.2 is different

This package is a **direct GitHub repository**. You do not need to upload a ZIP inside the repository anymore.

Upload these files as-is to GitHub, then run GitHub Actions.

## Main features

- Reads real CSV terrain candidate data from Android assets.
- Calculates `GoldSupport%` for every cell or point.
- Uses transparent sub-scores:
  - FeOx b2/b1
  - low NDVI / exposed ground
  - VNIR brightness from b1/b2/b3n
  - source model score
  - candidate class
- Draws a circular GPS radar.
- Shows target details, distance, bearing, priority, confidence, and reason text.
- Opens navigation to the selected target.
- Exports analyzed CSV to clipboard.
- Includes QA scripts and GitHub Actions validation.

## Required CSV columns

```csv
rank,lat,lon,utm_e,utm_n,score,feox_b2_b1,ndvi,b1,b2,b3n,class
```

Included asset files:

```text
app/src/main/assets/BOUH_ASTER_VNIR_candidate_points.csv
app/src/main/assets/bouh_truth_grid_v28.csv
```

To use the full 156k-cell dataset, add:

```text
app/src/main/assets/bouh_truth_grid_v27_156k.csv
```

using the same column names. The app automatically tries `bouh_truth_grid_v28.csv`, then `bouh_truth_grid_v27_156k.csv`, then the candidate-points CSV.

## Scoring model

```text
GoldSupport% =
  40% FeOx b2/b1
+ 25% low NDVI / exposed ground
+ 15% VNIR brightness balance
+ 15% source model score
+  5% candidate class
```

Normalization ranges:

```text
FeOx b2/b1:        1.35 → 1.55
NDVI:             -0.05 → 0.08, inverted
Brightness:       90.0 → 380.0
Source score:     60.0 → 85.0
Class A+/A/B+/B/C: transparent class multiplier
```

## GitHub Actions build

Workflow:

```text
.github/workflows/build-bouh-mapscout-v28-2.yml
```

It validates:

```text
Android project files
AndroidManifest exported rules
Java radar source files
CSV columns and numeric ranges
GoldSupport% between 0 and 100
QA JSON report
QA CSV preview
Debug APK build
```

Artifact output:

```text
BOUH_MapScout_V28_2_GOLD_SUPPORT_RADAR_APK_AND_QA
```

Inside the artifact:

```text
BOUH_MapScout_V28_2_GOLD_SUPPORT_RADAR.apk
qa_gold_support_report.json
qa_gold_support_preview.csv
TESTING_V28_2.md
BUILD_INFO.txt
```

## Local validation

```bash
python3 tools/validate_gold_radar_dataset.py . --write-report qa_gold_support_report.json
python3 tools/generate_gold_support_preview.py . qa_gold_support_preview.csv
```

## Local build

```bash
gradle --no-daemon clean lintDebug assembleDebug --stacktrace
```

APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Upload to GitHub

1. Create a new empty GitHub repository.
2. Upload the contents of this folder, not the folder itself.
3. Confirm that `.github/workflows/build-bouh-mapscout-v28-2.yml` exists in the repo.
4. Go to **Actions**.
5. Run **Build BOUH MapScout V28.2 Direct Repo APK**.
6. Download the artifact.

## Version

V28.2 direct-repo QA package.
