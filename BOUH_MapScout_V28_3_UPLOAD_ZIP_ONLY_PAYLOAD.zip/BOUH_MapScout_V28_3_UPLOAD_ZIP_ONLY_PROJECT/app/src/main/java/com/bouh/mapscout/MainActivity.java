package com.bouh.mapscout;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int REQUEST_LOCATION = 2801;

    private final TerrainTruthEngine engine = new TerrainTruthEngine();

    private RadarCircleView radarView;
    private LinearLayout targetList;
    private TextView statusText;
    private TextView detailText;
    private TextView headerText;
    private TerrainCell selectedCell;
    private Location lastLocation;

    private final int bg = 0xFF07100A;
    private final int panel = 0xFF102015;
    private final int text = 0xFFEAF4EA;
    private final int muted = 0xFF9CAE9B;
    private final int gold = 0xFFFFC94A;
    private final int danger = 0xFFFF6B35;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();

        try {
            engine.load(this);
            List<TerrainCell> topCells = engine.topCells(100);
            if (!topCells.isEmpty()) {
                selectedCell = topCells.get(0);
            }
            radarView.setCells(topCells);
            radarView.setSelectedCell(selectedCell);
            renderStatus();
            renderTargetList();
            renderDetails(selectedCell);
            requestLocationThenRefresh();
        } catch (IOException error) {
            statusText.setText("Dataset load failed: " + error.getMessage());
            detailText.setText("ضع ملف CSV داخل app/src/main/assets بالأعمدة المطلوبة: rank, lat, lon, utm_e, utm_n, score, feox_b2_b1, ndvi, b1, b2, b3n, class");
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(12), dp(10), dp(12), dp(10));

        headerText = new TextView(this);
        headerText.setText("BOUH Terrain Truth Radar V28.2");
        headerText.setTextColor(gold);
        headerText.setTextSize(22);
        headerText.setTypeface(Typeface.DEFAULT_BOLD);
        headerText.setGravity(Gravity.CENTER);
        root.addView(headerText, new LinearLayout.LayoutParams(-1, -2));

        statusText = new TextView(this);
        statusText.setTextColor(muted);
        statusText.setTextSize(13);
        statusText.setPadding(0, dp(6), 0, dp(8));
        statusText.setGravity(Gravity.CENTER);
        root.addView(statusText, new LinearLayout.LayoutParams(-1, -2));

        radarView = new RadarCircleView(this);
        root.addView(radarView, new LinearLayout.LayoutParams(-1, 0, 1.04f));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);
        buttons.setPadding(0, dp(6), 0, dp(6));

        Button gpsButton = makeButton("GPS");
        gpsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestLocationThenRefresh();
            }
        });

        Button navButton = makeButton("Navigate");
        navButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                navigateToSelected();
            }
        });

        Button exportButton = makeButton("Export");
        exportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                copyExportToClipboard();
            }
        });

        Button radiusButton = makeButton("25 km");
        radiusButton.setOnClickListener(new View.OnClickListener() {
            private boolean wide = false;

            @Override
            public void onClick(View view) {
                wide = !wide;
                radarView.setDisplayRadiusMeters(wide ? 25000.0 : 10000.0);
                ((Button) view).setText(wide ? "10 km" : "25 km");
            }
        });

        buttons.addView(gpsButton, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(navButton, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(exportButton, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(radiusButton, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(buttons, new LinearLayout.LayoutParams(-1, -2));

        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        targetList = new LinearLayout(this);
        targetList.setOrientation(LinearLayout.HORIZONTAL);
        scroller.addView(targetList, new HorizontalScrollView.LayoutParams(-2, -2));
        root.addView(scroller, new LinearLayout.LayoutParams(-1, -2));

        detailText = new TextView(this);
        detailText.setTextColor(text);
        detailText.setTextSize(13);
        detailText.setPadding(dp(12), dp(10), dp(12), dp(10));
        detailText.setBackgroundColor(panel);
        detailText.setMovementMethod(new ScrollingMovementMethod());

        ScrollView detailScroll = new ScrollView(this);
        detailScroll.addView(detailText, new ScrollView.LayoutParams(-1, -2));
        root.addView(detailScroll, new LinearLayout.LayoutParams(-1, 0, 0.88f));

        setContentView(root);
    }

    private Button makeButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(0xFF101010);
        button.setTextSize(12);
        button.setAllCaps(false);
        return button;
    }

    private void renderStatus() {
        String gps = lastLocation == null
                ? "GPS waiting"
                : String.format(Locale.US, "GPS %.5f, %.5f", lastLocation.getLatitude(), lastLocation.getLongitude());
        statusText.setText(engine.getLoadSummary() + " · " + gps + " · GoldSupport is an exploration-support score, not proof of gold.");
    }

    private void renderTargetList() {
        targetList.removeAllViews();
        for (TerrainCell cell : engine.topCells(30)) {
            TextView chip = new TextView(this);
            chip.setText(String.format(Locale.US, "#%d %.1f%% %s\n%s", cell.rank, cell.goldSupportPercent, cell.classLabel, cell.distanceText()));
            chip.setTextSize(12);
            chip.setTextColor(cell == selectedCell ? 0xFF101010 : text);
            chip.setTypeface(Typeface.DEFAULT_BOLD);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(10), dp(8), dp(10), dp(8));
            chip.setBackgroundColor(cell == selectedCell ? gold : panel);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    selectedCell = cell;
                    radarView.setSelectedCell(cell);
                    renderTargetList();
                    renderDetails(cell);
                }
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(132), -2);
            params.setMargins(0, 0, dp(8), dp(8));
            targetList.addView(chip, params);
        }
    }

    private void renderDetails(TerrainCell cell) {
        if (cell == null) {
            detailText.setText("No target selected.");
            return;
        }

        String details = String.format(Locale.US,
                "TARGET %s\n\n" +
                        "Gold support: %.1f%%\n" +
                        "Priority: %s\n" +
                        "Confidence: %s\n\n" +
                        "Coordinates: %s\n" +
                        "UTM: %s\n" +
                        "Distance: %s\n" +
                        "Bearing: %s\n\n" +
                        "INDICATORS\n" +
                        "FeOx b2/b1: %.4f → %.1f%%\n" +
                        "NDVI: %.4f → exposed-ground %.1f%%\n" +
                        "B1/B2/B3N: %d / %d / %d → brightness %.1f%%\n" +
                        "Source score: %.2f → %.1f%%\n" +
                        "Class: %s → %.1f%%\n\n" +
                        "WHY THIS CELL WAS RANKED\n%s\n\n" +
                        "FIELD NOTE\n" +
                        "This radar estimates surface indicators supportive of gold-mineralization environments. It does not confirm subsurface gold. Use it to prioritize mapping, sampling, and geological verification.",
                cell.title(),
                cell.goldSupportPercent,
                cell.priorityLabel,
                cell.confidenceLabel,
                cell.coordinateText(),
                cell.utmText(),
                cell.distanceText(),
                cell.bearingText(),
                cell.feoxB2B1,
                cell.feoxPercent,
                cell.ndvi,
                cell.exposedGroundPercent,
                cell.b1,
                cell.b2,
                cell.b3n,
                cell.brightnessPercent,
                cell.sourceScore,
                cell.modelPercent,
                cell.classLabel,
                cell.classPercent,
                cell.reasonText
        );

        detailText.setText(details);
    }

    private void requestLocationThenRefresh() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, REQUEST_LOCATION);
            return;
        }

        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Location location = null;

        try {
            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location network = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            location = newerLocation(gps, network);
        } catch (SecurityException ignored) {
            location = null;
        }

        if (location == null) {
            Toast.makeText(this, "لم أجد موقعًا حاليًا. افتح GPS أو Location Settings.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            try {
                startActivity(intent);
            } catch (RuntimeException ignored) {
            }
            renderStatus();
            return;
        }

        lastLocation = location;
        engine.updateDistances(location);
        radarView.setUserLocation(location);
        radarView.setCells(engine.topCells(100));
        if (!engine.topCells(1).isEmpty()) {
            selectedCell = engine.topCells(1).get(0);
            radarView.setSelectedCell(selectedCell);
        }
        renderStatus();
        renderTargetList();
        renderDetails(selectedCell);
    }

    private Location newerLocation(Location a, Location b) {
        if (a == null) return b;
        if (b == null) return a;
        return a.getTime() >= b.getTime() ? a : b;
    }

    private void navigateToSelected() {
        if (selectedCell == null) {
            Toast.makeText(this, "اختر هدفًا أولًا.", Toast.LENGTH_SHORT).show();
            return;
        }
        Uri uri = Uri.parse(String.format(Locale.US, "geo:0,0?q=%.6f,%.6f(BOUH%%20Gold%%20Support%%20%.1f%%25)", selectedCell.latitude, selectedCell.longitude, selectedCell.goldSupportPercent));
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        try {
            startActivity(intent);
        } catch (RuntimeException error) {
            Toast.makeText(this, "لا يوجد تطبيق ملاحة متاح.", Toast.LENGTH_LONG).show();
        }
    }

    private void copyExportToClipboard() {
        String csv = engine.exportAnalyzedCsv();
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("BOUH analyzed gold support CSV", csv));
        Toast.makeText(this, "تم نسخ CSV المحلل إلى الحافظة.", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION) {
            requestLocationThenRefresh();
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
