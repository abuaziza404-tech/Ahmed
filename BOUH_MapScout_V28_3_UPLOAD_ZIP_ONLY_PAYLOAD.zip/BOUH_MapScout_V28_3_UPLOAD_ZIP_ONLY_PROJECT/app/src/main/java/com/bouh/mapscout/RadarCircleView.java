package com.bouh.mapscout;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.location.Location;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class RadarCircleView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<TerrainCell> cells = new ArrayList<>();
    private Location userLocation;
    private TerrainCell selectedCell;
    private double displayRadiusMeters = 10000.0;

    private final int backgroundColor = 0xFF07100A;
    private final int gridColor = 0x664C6B54;
    private final int textColor = 0xFFEAF4EA;
    private final int goldColor = 0xFFFFC94A;
    private final int orangeColor = 0xFFFF8A2A;
    private final int yellowColor = 0xFFE7D84A;
    private final int grayColor = 0xFF7D877F;
    private final int redGoldColor = 0xFFFF3B30;

    public RadarCircleView(Context context) {
        super(context);
        init();
    }

    public RadarCircleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setFocusable(true);
    }

    public void setCells(List<TerrainCell> newCells) {
        cells.clear();
        if (newCells != null) {
            cells.addAll(newCells);
        }
        invalidate();
    }

    public void setUserLocation(Location location) {
        userLocation = location;
        invalidate();
    }

    public void setSelectedCell(TerrainCell cell) {
        selectedCell = cell;
        invalidate();
    }

    public void setDisplayRadiusMeters(double meters) {
        displayRadiusMeters = Math.max(500.0, meters);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(backgroundColor);

        float width = getWidth();
        float height = getHeight();
        float size = Math.min(width, height) * 0.86f;
        float centerX = width / 2f;
        float centerY = height / 2f;
        float radius = size / 2f;

        drawGrid(canvas, centerX, centerY, radius);
        drawRadarSweep(canvas, centerX, centerY, radius);
        drawCells(canvas, centerX, centerY, radius);
        drawCenter(canvas, centerX, centerY);
        drawLabels(canvas, centerX, centerY, radius);
    }

    private void drawGrid(Canvas canvas, float centerX, float centerY, float radius) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f);
        paint.setColor(gridColor);

        for (int i = 1; i <= 4; i++) {
            float r = radius * i / 4f;
            canvas.drawCircle(centerX, centerY, r, paint);
        }

        canvas.drawLine(centerX - radius, centerY, centerX + radius, centerY, paint);
        canvas.drawLine(centerX, centerY - radius, centerX, centerY + radius, paint);

        for (int degree = 45; degree < 360; degree += 45) {
            double radians = Math.toRadians(degree - 90);
            float x = centerX + (float) Math.cos(radians) * radius;
            float y = centerY + (float) Math.sin(radians) * radius;
            canvas.drawLine(centerX, centerY, x, y, paint);
        }
    }

    private void drawRadarSweep(Canvas canvas, float centerX, float centerY, float radius) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5f);
        paint.setColor(0x99D6A530);
        RectF oval = new RectF(centerX - radius, centerY - radius, centerX + radius, centerY + radius);
        float sweepStart = (System.currentTimeMillis() % 6000L) / 6000f * 360f - 90f;
        canvas.drawArc(oval, sweepStart, 42f, false, paint);
        postInvalidateDelayed(120L);
    }

    private void drawCells(Canvas canvas, float centerX, float centerY, float radius) {
        if (cells.isEmpty()) return;

        List<TerrainCell> drawable = new ArrayList<>(cells);
        Collections.sort(drawable, new Comparator<TerrainCell>() {
            @Override
            public int compare(TerrainCell a, TerrainCell b) {
                return Double.compare(a.goldSupportPercent, b.goldSupportPercent);
            }
        });

        int drawn = 0;
        for (TerrainCell cell : drawable) {
            if (drawn >= 120) break;
            if (Double.isNaN(cell.distanceMetersFromUser) || Double.isNaN(cell.bearingDegreesFromUser)) {
                continue;
            }
            if (cell.distanceMetersFromUser > displayRadiusMeters) {
                continue;
            }

            double distanceRatio = GoldIndicatorModel.clamp(cell.distanceMetersFromUser / displayRadiusMeters, 0.0, 1.0);
            double radians = Math.toRadians(cell.bearingDegreesFromUser - 90.0);
            float x = centerX + (float) Math.cos(radians) * radius * (float) distanceRatio;
            float y = centerY + (float) Math.sin(radians) * radius * (float) distanceRatio;
            float dotRadius = cell == selectedCell ? 13f : 7f + (float) (cell.goldSupportPercent / 100.0 * 6.0);

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(colorFor(cell.goldSupportPercent));
            canvas.drawCircle(x, y, dotRadius, paint);

            if (cell == selectedCell) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(4f);
                paint.setColor(0xFFFFFFFF);
                canvas.drawCircle(x, y, dotRadius + 7f, paint);
            }
            drawn++;
        }
    }

    private void drawCenter(Canvas canvas, float centerX, float centerY) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFFFFFFFF);
        canvas.drawCircle(centerX, centerY, 8f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        paint.setColor(goldColor);
        canvas.drawCircle(centerX, centerY, 18f, paint);
    }

    private void drawLabels(Canvas canvas, float centerX, float centerY, float radius) {
        paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setFakeBoldText(true);
        paint.setTextSize(28f);
        paint.setColor(textColor);
        canvas.drawText("N", centerX, centerY - radius - 12f, paint);
        canvas.drawText("S", centerX, centerY + radius + 34f, paint);
        canvas.drawText("W", centerX - radius - 24f, centerY + 10f, paint);
        canvas.drawText("E", centerX + radius + 24f, centerY + 10f, paint);

        paint.setFakeBoldText(false);
        paint.setTextSize(23f);
        paint.setColor(0xFFB8C7B8);
        String radiusText = String.format(Locale.US, "radius %.1f km", displayRadiusMeters / 1000.0);
        canvas.drawText(radiusText, centerX, centerY + radius - 18f, paint);

        if (userLocation == null) {
            paint.setColor(0xFFFFD166);
            canvas.drawText("Enable GPS to turn candidates into radar bearings", centerX, 36f, paint);
        }
    }

    private int colorFor(double percent) {
        if (percent >= 90.0) return redGoldColor;
        if (percent >= 80.0) return goldColor;
        if (percent >= 70.0) return orangeColor;
        if (percent >= 60.0) return yellowColor;
        return grayColor;
    }
}
