package com.bouh.mapscout;

import java.util.Locale;

public final class TerrainCell {
    public final int rank;
    public final double latitude;
    public final double longitude;
    public final double utmEasting;
    public final double utmNorthing;
    public final double sourceScore;
    public final double feoxB2B1;
    public final double ndvi;
    public final int b1;
    public final int b2;
    public final int b3n;
    public final String classLabel;

    public double goldSupportPercent;
    public double feoxPercent;
    public double exposedGroundPercent;
    public double brightnessPercent;
    public double modelPercent;
    public double classPercent;
    public String priorityLabel;
    public String confidenceLabel;
    public String reasonText;
    public double distanceMetersFromUser = Double.NaN;
    public double bearingDegreesFromUser = Double.NaN;

    public TerrainCell(
            int rank,
            double latitude,
            double longitude,
            double utmEasting,
            double utmNorthing,
            double sourceScore,
            double feoxB2B1,
            double ndvi,
            int b1,
            int b2,
            int b3n,
            String classLabel
    ) {
        this.rank = rank;
        this.latitude = latitude;
        this.longitude = longitude;
        this.utmEasting = utmEasting;
        this.utmNorthing = utmNorthing;
        this.sourceScore = sourceScore;
        this.feoxB2B1 = feoxB2B1;
        this.ndvi = ndvi;
        this.b1 = b1;
        this.b2 = b2;
        this.b3n = b3n;
        this.classLabel = classLabel == null ? "" : classLabel.trim();
    }

    public String coordinateText() {
        return String.format(Locale.US, "%.6f, %.6f", latitude, longitude);
    }

    public String utmText() {
        return String.format(Locale.US, "E %.1f / N %.1f", utmEasting, utmNorthing);
    }

    public String distanceText() {
        if (Double.isNaN(distanceMetersFromUser)) {
            return "GPS distance unavailable";
        }
        if (distanceMetersFromUser >= 1000.0) {
            return String.format(Locale.US, "%.2f km", distanceMetersFromUser / 1000.0);
        }
        return String.format(Locale.US, "%.0f m", distanceMetersFromUser);
    }

    public String bearingText() {
        if (Double.isNaN(bearingDegreesFromUser)) {
            return "bearing unavailable";
        }
        return String.format(Locale.US, "%.0f° %s", bearingDegreesFromUser, compassDirection(bearingDegreesFromUser));
    }

    public String title() {
        return String.format(Locale.US, "#%d  %.1f%%  %s", rank, goldSupportPercent, classLabel);
    }

    public static String compassDirection(double degrees) {
        String[] names = {"N", "NE", "E", "SE", "S", "SW", "W", "NW", "N"};
        int index = (int) Math.round(((degrees % 360.0) / 45.0));
        return names[Math.max(0, Math.min(index, names.length - 1))];
    }
}
