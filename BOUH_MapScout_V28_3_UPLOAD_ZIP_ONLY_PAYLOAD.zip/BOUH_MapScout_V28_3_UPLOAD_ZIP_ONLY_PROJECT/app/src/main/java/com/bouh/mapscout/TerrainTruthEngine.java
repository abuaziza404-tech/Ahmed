package com.bouh.mapscout;

import android.content.Context;
import android.content.res.AssetManager;
import android.location.Location;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class TerrainTruthEngine {
    private static final String[] DATASET_CANDIDATES = {
            "bouh_truth_grid_v28.csv",
            "bouh_truth_grid_v27_156k.csv",
            "BOUH_ASTER_VNIR_candidate_points.csv"
    };

    private final List<TerrainCell> cells = new ArrayList<>();
    private String loadedDatasetName = "";
    private String loadSummary = "";

    public void load(Context context) throws IOException {
        cells.clear();
        AssetManager assets = context.getAssets();
        IOException lastError = null;

        for (String datasetName : DATASET_CANDIDATES) {
            try {
                InputStream stream = assets.open(datasetName);
                loadedDatasetName = datasetName;
                readCsv(stream);
                sortByGoldSupport();
                loadSummary = String.format(Locale.US, "%s loaded: %,d cells", datasetName, cells.size());
                return;
            } catch (IOException error) {
                lastError = error;
            }
        }

        if (lastError != null) {
            throw lastError;
        }
        throw new IOException("No terrain truth CSV dataset found in app assets.");
    }

    public List<TerrainCell> allCells() {
        return Collections.unmodifiableList(cells);
    }

    public List<TerrainCell> topCells(int limit) {
        int safeLimit = Math.max(0, Math.min(limit, cells.size()));
        return Collections.unmodifiableList(cells.subList(0, safeLimit));
    }

    public String getLoadedDatasetName() {
        return loadedDatasetName;
    }

    public String getLoadSummary() {
        return loadSummary;
    }

    public void updateDistances(Location userLocation) {
        if (userLocation == null) {
            return;
        }

        float[] results = new float[3];
        for (TerrainCell cell : cells) {
            Location.distanceBetween(
                    userLocation.getLatitude(),
                    userLocation.getLongitude(),
                    cell.latitude,
                    cell.longitude,
                    results
            );
            cell.distanceMetersFromUser = results[0];
            cell.bearingDegreesFromUser = normalizeBearing(results[1]);
        }

        Collections.sort(cells, new Comparator<TerrainCell>() {
            @Override
            public int compare(TerrainCell a, TerrainCell b) {
                boolean aHasDistance = !Double.isNaN(a.distanceMetersFromUser);
                boolean bHasDistance = !Double.isNaN(b.distanceMetersFromUser);
                if (aHasDistance && bHasDistance) {
                    int distanceCompare = Double.compare(a.distanceMetersFromUser, b.distanceMetersFromUser);
                    if (distanceCompare != 0) return distanceCompare;
                }
                if (aHasDistance) return -1;
                if (bHasDistance) return 1;
                return Double.compare(b.goldSupportPercent, a.goldSupportPercent);
            }
        });
    }

    public String exportAnalyzedCsv() {
        StringBuilder builder = new StringBuilder();
        builder.append("rank,lat,lon,utm_e,utm_n,source_score,feox_b2_b1,ndvi,b1,b2,b3n,class,gold_support_percent,feox_percent,exposed_ground_percent,brightness_percent,model_percent,class_percent,priority,confidence,distance_meters,bearing_degrees\n");
        for (TerrainCell cell : cells) {
            builder.append(cell.rank).append(',')
                    .append(format(cell.latitude)).append(',')
                    .append(format(cell.longitude)).append(',')
                    .append(format(cell.utmEasting)).append(',')
                    .append(format(cell.utmNorthing)).append(',')
                    .append(format(cell.sourceScore)).append(',')
                    .append(format(cell.feoxB2B1)).append(',')
                    .append(format(cell.ndvi)).append(',')
                    .append(cell.b1).append(',')
                    .append(cell.b2).append(',')
                    .append(cell.b3n).append(',')
                    .append(escapeCsv(cell.classLabel)).append(',')
                    .append(format(cell.goldSupportPercent)).append(',')
                    .append(format(cell.feoxPercent)).append(',')
                    .append(format(cell.exposedGroundPercent)).append(',')
                    .append(format(cell.brightnessPercent)).append(',')
                    .append(format(cell.modelPercent)).append(',')
                    .append(format(cell.classPercent)).append(',')
                    .append(escapeCsv(cell.priorityLabel)).append(',')
                    .append(escapeCsv(cell.confidenceLabel)).append(',')
                    .append(Double.isNaN(cell.distanceMetersFromUser) ? "" : format(cell.distanceMetersFromUser)).append(',')
                    .append(Double.isNaN(cell.bearingDegreesFromUser) ? "" : format(cell.bearingDegreesFromUser))
                    .append('\n');
        }
        return builder.toString();
    }

    private void readCsv(InputStream stream) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        String headerLine = reader.readLine();
        if (headerLine == null) {
            throw new IOException("CSV file is empty.");
        }

        String[] headers = splitCsvLine(headerLine);
        ColumnIndex index = new ColumnIndex(headers);
        index.require("rank", "lat", "lon", "utm_e", "utm_n", "score", "feox_b2_b1", "ndvi", "b1", "b2", "b3n", "class");

        String line;
        int lineNumber = 1;
        while ((line = reader.readLine()) != null) {
            lineNumber++;
            if (line.trim().isEmpty()) continue;
            String[] parts = splitCsvLine(line);
            try {
                TerrainCell cell = new TerrainCell(
                        parseInt(parts, index.of("rank")),
                        parseDouble(parts, index.of("lat")),
                        parseDouble(parts, index.of("lon")),
                        parseDouble(parts, index.of("utm_e")),
                        parseDouble(parts, index.of("utm_n")),
                        parseDouble(parts, index.of("score")),
                        parseDouble(parts, index.of("feox_b2_b1")),
                        parseDouble(parts, index.of("ndvi")),
                        parseInt(parts, index.of("b1")),
                        parseInt(parts, index.of("b2")),
                        parseInt(parts, index.of("b3n")),
                        get(parts, index.of("class"))
                );
                GoldIndicatorModel.analyze(cell);
                cells.add(cell);
            } catch (RuntimeException error) {
                throw new IOException("Bad CSV row at line " + lineNumber + ": " + error.getMessage(), error);
            }
        }

        if (cells.isEmpty()) {
            throw new IOException("CSV contained headers but no valid terrain cells.");
        }
    }

    private void sortByGoldSupport() {
        Collections.sort(cells, new Comparator<TerrainCell>() {
            @Override
            public int compare(TerrainCell a, TerrainCell b) {
                int support = Double.compare(b.goldSupportPercent, a.goldSupportPercent);
                if (support != 0) return support;
                return Integer.compare(a.rank, b.rank);
            }
        });
    }

    private static double normalizeBearing(double bearing) {
        double normalized = bearing % 360.0;
        if (normalized < 0) normalized += 360.0;
        return normalized;
    }

    private static String format(double value) {
        return String.format(Locale.US, "%.6f", value);
    }

    private static String get(String[] parts, int index) {
        if (index < 0 || index >= parts.length) {
            return "";
        }
        return parts[index].trim();
    }

    private static double parseDouble(String[] parts, int index) {
        String raw = get(parts, index);
        if (raw.isEmpty()) return 0.0;
        return Double.parseDouble(raw);
    }

    private static int parseInt(String[] parts, int index) {
        String raw = get(parts, index);
        if (raw.isEmpty()) return 0;
        return (int) Math.round(Double.parseDouble(raw));
    }

    private static String escapeCsv(String value) {
        if (value == null) return "";
        boolean needsEscape = value.contains(",") || value.contains("\"") || value.contains("\n");
        if (!needsEscape) return value;
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    private static String[] splitCsvLine(String line) {
        ArrayList<String> values = new ArrayList<>();
        StringBuilder token = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char character = line.charAt(i);
            if (character == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    token.append('"');
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (character == ',' && !inQuotes) {
                values.add(token.toString());
                token.setLength(0);
            } else {
                token.append(character);
            }
        }

        values.add(token.toString());
        return values.toArray(new String[0]);
    }

    private static final class ColumnIndex {
        private final String[] headers;

        private ColumnIndex(String[] headers) {
            this.headers = headers;
            for (int i = 0; i < this.headers.length; i++) {
                this.headers[i] = this.headers[i].trim().toLowerCase(Locale.US);
            }
        }

        int of(String name) {
            String normalized = name.toLowerCase(Locale.US);
            for (int i = 0; i < headers.length; i++) {
                if (normalized.equals(headers[i])) {
                    return i;
                }
            }
            return -1;
        }

        void require(String... requiredNames) throws IOException {
            for (String name : requiredNames) {
                if (of(name) < 0) {
                    throw new IOException("CSV is missing required column: " + name);
                }
            }
        }
    }
}
