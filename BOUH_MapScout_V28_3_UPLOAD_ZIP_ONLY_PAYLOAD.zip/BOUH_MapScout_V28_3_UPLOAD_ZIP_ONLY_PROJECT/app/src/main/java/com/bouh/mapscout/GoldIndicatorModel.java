package com.bouh.mapscout;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class GoldIndicatorModel {
    private GoldIndicatorModel() {}

    public static void analyze(TerrainCell cell) {
        double feoxScore = normalize(cell.feoxB2B1, 1.35, 1.55);
        double ndviScore = 1.0 - normalize(cell.ndvi, -0.05, 0.08);
        double brightness = (cell.b1 + cell.b2 + cell.b3n) / 3.0;
        double brightnessScore = normalize(brightness, 90.0, 380.0);
        double sourceScore = normalize(cell.sourceScore, 60.0, 85.0);
        double classScore = classScore(cell.classLabel);

        cell.feoxPercent = round1(feoxScore * 100.0);
        cell.exposedGroundPercent = round1(ndviScore * 100.0);
        cell.brightnessPercent = round1(brightnessScore * 100.0);
        cell.modelPercent = round1(sourceScore * 100.0);
        cell.classPercent = round1(classScore * 100.0);

        double weighted =
                feoxScore * 0.40 +
                ndviScore * 0.25 +
                brightnessScore * 0.15 +
                sourceScore * 0.15 +
                classScore * 0.05;

        cell.goldSupportPercent = round1(clamp(weighted * 100.0, 0.0, 100.0));
        cell.priorityLabel = priorityLabel(cell.goldSupportPercent);
        cell.confidenceLabel = confidenceLabel(cell);
        cell.reasonText = buildReasonText(cell, brightness);
    }

    public static double normalize(double value, double min, double max) {
        if (Double.isNaN(value) || Double.isInfinite(value) || max <= min) {
            return 0.0;
        }
        return clamp((value - min) / (max - min), 0.0, 1.0);
    }

    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private static double round1(double value) {
        return Math.round(value * 10.0) / 10.0;
    }

    private static double classScore(String label) {
        if (label == null) return 0.5;
        String normalized = label.trim().toUpperCase(Locale.US);
        if ("A+".equals(normalized)) return 1.0;
        if ("A".equals(normalized)) return 0.95;
        if ("B+".equals(normalized)) return 0.90;
        if ("B".equals(normalized)) return 0.75;
        if ("C".equals(normalized)) return 0.55;
        return 0.50;
    }

    private static String priorityLabel(double percent) {
        if (percent >= 90.0) return "Extreme priority";
        if (percent >= 80.0) return "Very high priority";
        if (percent >= 70.0) return "High priority";
        if (percent >= 60.0) return "Review priority";
        return "Low priority";
    }

    private static String confidenceLabel(TerrainCell cell) {
        int supportCount = 0;
        if (cell.feoxPercent >= 45.0) supportCount++;
        if (cell.exposedGroundPercent >= 60.0) supportCount++;
        if (cell.modelPercent >= 45.0) supportCount++;
        if (cell.classPercent >= 75.0) supportCount++;
        if (supportCount >= 4) return "Medium-high";
        if (supportCount == 3) return "Medium";
        if (supportCount == 2) return "Low-medium";
        return "Low";
    }

    private static String buildReasonText(TerrainCell cell, double brightness) {
        List<String> reasons = new ArrayList<>();

        if (cell.feoxB2B1 >= 1.48) {
            reasons.add("FeOx b2/b1 is very strong, suggesting intense iron-oxide surface response.");
        } else if (cell.feoxB2B1 >= 1.42) {
            reasons.add("FeOx b2/b1 is strong, supporting an alteration-style target.");
        } else if (cell.feoxB2B1 >= 1.38) {
            reasons.add("FeOx b2/b1 is moderate and worth field review.");
        } else {
            reasons.add("FeOx b2/b1 is weak compared with stronger candidates.");
        }

        if (cell.ndvi <= 0.0) {
            reasons.add("NDVI is at or below zero, indicating exposed ground with low vegetation masking.");
        } else if (cell.ndvi <= 0.03) {
            reasons.add("NDVI is low, so the surface response is likely less masked by vegetation.");
        } else if (cell.ndvi <= 0.06) {
            reasons.add("NDVI is acceptable but not ideal for clean surface interpretation.");
        } else {
            reasons.add("NDVI is elevated, so vegetation or surface cover may reduce confidence.");
        }

        if (brightness >= 300.0) {
            reasons.add("VNIR brightness is high; verify whether this is alteration, pale rock, sand, or glare.");
        } else if (brightness >= 210.0) {
            reasons.add("VNIR brightness is balanced and compatible with exposed terrain screening.");
        } else {
            reasons.add("VNIR brightness is low; inspect imagery before assigning field priority.");
        }

        if ("B+".equalsIgnoreCase(cell.classLabel)) {
            reasons.add("Class B+ adds field priority in the current candidate model.");
        } else if ("B".equalsIgnoreCase(cell.classLabel)) {
            reasons.add("Class B remains useful, but ranks below B+ targets.");
        } else {
            reasons.add("Class label is not a top-tier candidate class.");
        }

        return joinLines(reasons);
    }

    private static String joinLines(List<String> lines) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            builder.append("• ").append(lines.get(i));
            if (i < lines.size() - 1) builder.append("\n");
        }
        return builder.toString();
    }
}
