# BOUH MapScout V28.3 Upload-ZIP-Only Payload

هذا الملف مخصص للرفع إلى GitHub كما هو بدون فك ضغط المشروع محليًا.

الطريقة:
1. ضع ملف workflow bootstrap في المستودع مرة واحدة:
   `.github/workflows/build-uploaded-bouh-zip.yml`
2. ارفع هذا الملف:
   `BOUH_MapScout_V28_3_UPLOAD_ZIP_ONLY_PAYLOAD.zip`
   إلى جذر المستودع بدون فك ضغطه.
3. شغّل GitHub Actions:
   `Build BOUH MapScout from Uploaded ZIP Payload`
4. سيقوم GitHub Actions بفك الضغط داخل runner، ثم يبني APK ويرفع Artifact.

ملاحظة: GitHub لا يستطيع قراءة workflow موجود داخل ZIP. لذلك وجود workflow bootstrap خارج ZIP ضروري.
