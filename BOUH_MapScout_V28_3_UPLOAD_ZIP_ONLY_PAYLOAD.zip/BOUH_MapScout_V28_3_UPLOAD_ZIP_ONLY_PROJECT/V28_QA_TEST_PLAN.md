# BOUH MapScout V28.1 QA Test Plan

## Critical fixes included
- Removed `android:exported` from `<application>` in `AndroidManifest.xml`.
- Kept `android:exported="true"` only on `.MainActivity`, because it is the launcher activity.
- Added Java 17 compile options.
- Added dataset validation script for required CSV columns, coordinate ranges, indicator ranges, and `GoldSupport%` bounds.

## GitHub Actions checks
1. Validate the source ZIP exists.
2. Safely unzip and block path traversal.
3. Verify Android project structure.
4. Verify required Java radar classes.
5. Validate CSV headers and data rows.
6. Run `tools/validate_gold_radar_dataset.py`.
7. Build `assembleDebug`.
8. Export APK and build report as artifact.

## Manual field tests
1. Install APK on Android 8+.
2. Open app with GPS disabled; app must still show top targets.
3. Tap GPS; permission prompt must appear.
4. Grant location; radar must sort nearby cells by distance.
5. Tap any target; detail card must show FeOx, NDVI, brightness, priority, confidence, and reason text.
6. Tap Navigate; external map app must open selected coordinate.
7. Tap Export; analyzed CSV should copy/share without crashing.
8. Test airplane mode; local asset data must still load.
9. Replace `bouh_truth_grid_v28.csv` with full 156k grid using same columns; app must load it.
10. Confirm no screen crash on small mobile displays.

## Scientific QA rule
The displayed percentage is `GoldSupport%`: a surface-indicator support score for potential gold-hosting terrain. It is not a claim of confirmed gold.
