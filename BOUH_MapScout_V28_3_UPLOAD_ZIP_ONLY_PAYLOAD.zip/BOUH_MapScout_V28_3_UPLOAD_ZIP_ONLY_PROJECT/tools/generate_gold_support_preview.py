#!/usr/bin/env python3
import csv
import pathlib
import sys
from validate_gold_radar_dataset import load_rows, score_components

def main() -> None:
    root = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(".")
    output = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else pathlib.Path("qa_gold_support_preview.csv")
    source = root / "app/src/main/assets/bouh_truth_grid_v28.csv"
    if not source.exists():
        source = root / "app/src/main/assets/BOUH_ASTER_VNIR_candidate_points.csv"
    rows = load_rows(source)
    enriched = []
    for row in rows:
        components = score_components(row)
        enriched.append({**row, **components})
    enriched.sort(key=lambda item: item["gold_support_percent"], reverse=True)

    fieldnames = [
        "rank", "lat", "lon", "utm_e", "utm_n", "score", "feox_b2_b1", "ndvi",
        "b1", "b2", "b3n", "class", "gold_support_percent", "feox_percent",
        "exposed_ground_percent", "brightness_percent", "model_percent", "class_percent", "brightness"
    ]
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in enriched:
            writer.writerow({name: row.get(name, "") for name in fieldnames})
    print(f"Wrote {output} with {len(enriched)} rows")

if __name__ == "__main__":
    main()
