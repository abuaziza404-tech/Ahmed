#!/usr/bin/env python3
import argparse
import csv
import json
import math
import pathlib
import statistics
import sys
from typing import Dict, List, Tuple

REQUIRED = ["rank", "lat", "lon", "utm_e", "utm_n", "score", "feox_b2_b1", "ndvi", "b1", "b2", "b3n", "class"]

def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))

def normalize(value: float, low: float, high: float) -> float:
    if high <= low or not math.isfinite(value):
        return 0.0
    return clamp((value - low) / (high - low), 0.0, 1.0)

def class_score(label: str) -> float:
    label = (label or "").strip().upper()
    return {
        "A+": 1.00,
        "A": 0.95,
        "B+": 0.90,
        "B": 0.75,
        "C": 0.55,
    }.get(label, 0.50)

def score_components(row: Dict[str, str]) -> Dict[str, float]:
    source_score = float(row["score"])
    feox = float(row["feox_b2_b1"])
    ndvi = float(row["ndvi"])
    b1 = float(row["b1"])
    b2 = float(row["b2"])
    b3n = float(row["b3n"])
    brightness = (b1 + b2 + b3n) / 3.0

    feox_score = normalize(feox, 1.35, 1.55)
    exposed_score = 1.0 - normalize(ndvi, -0.05, 0.08)
    brightness_score = normalize(brightness, 90.0, 380.0)
    model_score = normalize(source_score, 60.0, 85.0)
    label_score = class_score(row["class"])

    support = clamp((
        feox_score * 0.40 +
        exposed_score * 0.25 +
        brightness_score * 0.15 +
        model_score * 0.15 +
        label_score * 0.05
    ) * 100.0, 0.0, 100.0)

    return {
        "gold_support_percent": round(support, 1),
        "feox_percent": round(feox_score * 100.0, 1),
        "exposed_ground_percent": round(exposed_score * 100.0, 1),
        "brightness_percent": round(brightness_score * 100.0, 1),
        "model_percent": round(model_score * 100.0, 1),
        "class_percent": round(label_score * 100.0, 1),
        "brightness": round(brightness, 2),
    }

def load_rows(path: pathlib.Path) -> List[Dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        missing = [name for name in REQUIRED if name not in (reader.fieldnames or [])]
        if missing:
            raise SystemExit(f"{path}: missing columns: {missing}")
        return list(reader)

def validate_file(path: pathlib.Path) -> Dict:
    rows = load_rows(path)
    if not rows:
        raise SystemExit(f"{path}: no data rows")

    analyzed: List[Tuple[float, Dict[str, str], Dict[str, float]]] = []
    warnings: List[str] = []
    latitudes: List[float] = []
    longitudes: List[float] = []
    supports: List[float] = []
    feox_values: List[float] = []
    ndvi_values: List[float] = []

    seen_locations = set()
    for index, row in enumerate(rows, start=2):
        try:
            lat = float(row["lat"])
            lon = float(row["lon"])
            score = float(row["score"])
            feox = float(row["feox_b2_b1"])
            ndvi = float(row["ndvi"])
            int(float(row["rank"]))
            float(row["utm_e"])
            float(row["utm_n"])
            float(row["b1"])
            float(row["b2"])
            float(row["b3n"])
        except ValueError as error:
            raise SystemExit(f"{path}:{index}: non-numeric required value: {error}") from error

        if not (-90.0 <= lat <= 90.0):
            raise SystemExit(f"{path}:{index}: invalid latitude {lat}")
        if not (-180.0 <= lon <= 180.0):
            raise SystemExit(f"{path}:{index}: invalid longitude {lon}")
        if not (0.0 <= score <= 100.0):
            raise SystemExit(f"{path}:{index}: invalid source score {score}")
        if not (0.5 <= feox <= 3.0):
            raise SystemExit(f"{path}:{index}: suspicious feox_b2_b1 {feox}")
        if not (-1.0 <= ndvi <= 1.0):
            raise SystemExit(f"{path}:{index}: invalid ndvi {ndvi}")

        key = (round(lat, 7), round(lon, 7))
        if key in seen_locations:
            warnings.append(f"duplicate coordinate near row {index}: {key}")
        seen_locations.add(key)

        components = score_components(row)
        support = components["gold_support_percent"]
        if not (0.0 <= support <= 100.0):
            raise SystemExit(f"{path}:{index}: invalid GoldSupport% {support}")

        analyzed.append((support, row, components))
        latitudes.append(lat)
        longitudes.append(lon)
        supports.append(support)
        feox_values.append(feox)
        ndvi_values.append(ndvi)

    analyzed.sort(key=lambda item: item[0], reverse=True)

    summary = {
        "file": str(path),
        "row_count": len(rows),
        "lat_range": [min(latitudes), max(latitudes)],
        "lon_range": [min(longitudes), max(longitudes)],
        "gold_support": {
            "min": min(supports),
            "mean": round(statistics.fmean(supports), 2),
            "max": max(supports),
        },
        "feox_b2_b1": {
            "min": min(feox_values),
            "mean": round(statistics.fmean(feox_values), 4),
            "max": max(feox_values),
        },
        "ndvi": {
            "min": min(ndvi_values),
            "mean": round(statistics.fmean(ndvi_values), 4),
            "max": max(ndvi_values),
        },
        "top_10": [
            {
                "rank": row["rank"],
                "lat": row["lat"],
                "lon": row["lon"],
                "class": row["class"],
                **components,
            }
            for support, row, components in analyzed[:10]
        ],
        "warnings": warnings[:20],
    }

    print(f"{path}: {len(rows)} rows OK")
    print(f"  GoldSupport% min/mean/max: {summary['gold_support']['min']} / {summary['gold_support']['mean']} / {summary['gold_support']['max']}")
    print("  Top 5:")
    for support, row, components in analyzed[:5]:
        print(f"    rank={row['rank']} lat={row['lat']} lon={row['lon']} support={support}% class={row['class']} feox={row['feox_b2_b1']} ndvi={row['ndvi']}")
    if warnings:
        print(f"  Warnings: {len(warnings)}")

    return summary

def main() -> None:
    parser = argparse.ArgumentParser(description="Validate BOUH Gold Support Radar CSV assets.")
    parser.add_argument("root", nargs="?", default=".", help="Android project root")
    parser.add_argument("--write-report", default="", help="Optional JSON report path")
    args = parser.parse_args()

    root = pathlib.Path(args.root)
    candidates = [
        root / "app/src/main/assets/bouh_truth_grid_v28.csv",
        root / "app/src/main/assets/bouh_truth_grid_v27_156k.csv",
        root / "app/src/main/assets/BOUH_ASTER_VNIR_candidate_points.csv",
    ]
    found = [path for path in candidates if path.exists()]
    if not found:
        raise SystemExit("No terrain CSV files found in app/src/main/assets")

    report = {
        "model": "BOUH MapScout V28.2 Gold Support Radar",
        "scientific_disclaimer": "GoldSupport% is an exploration-support ranking score, not proof of gold.",
        "required_columns": REQUIRED,
        "files": [validate_file(path) for path in found],
    }

    if args.write_report:
        pathlib.Path(args.write_report).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"Wrote {args.write_report}")

if __name__ == "__main__":
    main()
