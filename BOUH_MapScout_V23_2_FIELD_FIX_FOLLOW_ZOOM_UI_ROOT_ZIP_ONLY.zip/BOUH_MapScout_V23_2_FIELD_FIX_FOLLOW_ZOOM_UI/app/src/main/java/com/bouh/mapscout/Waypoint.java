
package com.bouh.mapscout;

public class Waypoint {
    public String time = "";
    public double lat, lon, alt, zoom;
    public String layer = "";
    public int score = 0;
    public String decision = "";
    public String report = "";
}
