
package com.bouh.mapscout;

import org.osmdroid.tileprovider.tilesource.XYTileSource;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.util.MapTileIndex;

public final class OverzoomTileSources {
    public static final int DISPLAY_MAX_ZOOM = 22;
    public static final int NATIVE_MAX_ZOOM = 17;

    private OverzoomTileSources() {}

    public static OnlineTileSourceBase esriSatellite() {
        return overzoom("Esri Satellite Overzoom",
                "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
                ".jpg");
    }

    public static OnlineTileSourceBase osmRoads() {
        return overzoom("OSM Roads Overzoom",
                "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
                ".png");
    }

    public static OnlineTileSourceBase openTopo() {
        return overzoom("OpenTopo Overzoom",
                "https://a.tile.opentopomap.org/{z}/{x}/{y}.png",
                ".png");
    }

    public static OnlineTileSourceBase custom(final String name, final String template) {
        return new XYTileSource(name, 0, DISPLAY_MAX_ZOOM, 256, ".png", new String[]{template}) {
            @Override public String getTileURLString(long index) {
                return url(template, index);
            }
        };
    }

    private static OnlineTileSourceBase overzoom(final String name, final String template, final String ext) {
        return new XYTileSource(name, 0, DISPLAY_MAX_ZOOM, 256, ext, new String[]{template}) {
            @Override public String getTileURLString(long index) {
                return url(template, index);
            }
        };
    }

    private static String url(String template, long index) {
        int requestedZ = MapTileIndex.getZoom(index);
        int requestedX = MapTileIndex.getX(index);
        int requestedY = MapTileIndex.getY(index);

        int z = Math.min(requestedZ, NATIVE_MAX_ZOOM);
        int shift = Math.max(0, requestedZ - z);
        int x = shift == 0 ? requestedX : (requestedX >> shift);
        int y = shift == 0 ? requestedY : (requestedY >> shift);

        return template.replace("{z}", String.valueOf(z))
                .replace("{x}", String.valueOf(x))
                .replace("{y}", String.valueOf(y));
    }
}
