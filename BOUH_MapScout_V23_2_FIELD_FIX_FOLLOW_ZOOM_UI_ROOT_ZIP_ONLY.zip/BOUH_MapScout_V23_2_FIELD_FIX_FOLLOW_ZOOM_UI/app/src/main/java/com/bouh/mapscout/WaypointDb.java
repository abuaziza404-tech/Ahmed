
package com.bouh.mapscout;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class WaypointDb extends SQLiteOpenHelper {
    public WaypointDb(Context c) { super(c, "bouh_v23.sqlite", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE waypoints(id INTEGER PRIMARY KEY AUTOINCREMENT,time TEXT,lat REAL,lon REAL,alt REAL,zoom REAL,layer TEXT,score INTEGER,decision TEXT,report TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public long insert(Waypoint w) {
        android.content.ContentValues v = new android.content.ContentValues();
        v.put("time", w.time); v.put("lat", w.lat); v.put("lon", w.lon); v.put("alt", w.alt);
        v.put("zoom", w.zoom); v.put("layer", w.layer); v.put("score", w.score);
        v.put("decision", w.decision); v.put("report", w.report);
        return getWritableDatabase().insert("waypoints", null, v);
    }

    public ArrayList<Waypoint> all() {
        ArrayList<Waypoint> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT * FROM waypoints ORDER BY id ASC", null);
        try {
            while(c.moveToNext()) {
                Waypoint w = new Waypoint();
                w.time = c.getString(c.getColumnIndexOrThrow("time"));
                w.lat = c.getDouble(c.getColumnIndexOrThrow("lat"));
                w.lon = c.getDouble(c.getColumnIndexOrThrow("lon"));
                w.alt = c.getDouble(c.getColumnIndexOrThrow("alt"));
                w.zoom = c.getDouble(c.getColumnIndexOrThrow("zoom"));
                w.layer = c.getString(c.getColumnIndexOrThrow("layer"));
                w.score = c.getInt(c.getColumnIndexOrThrow("score"));
                w.decision = c.getString(c.getColumnIndexOrThrow("decision"));
                w.report = c.getString(c.getColumnIndexOrThrow("report"));
                out.add(w);
            }
        } finally {
            c.close();
        }
        return out;
    }

    public String csv() {
        StringBuilder sb = new StringBuilder("time,lat,lon,alt,zoom,layer,score,decision\n");
        for(Waypoint w: all()) {
            sb.append(clean(w.time)).append(",").append(w.lat).append(",").append(w.lon).append(",")
                    .append(w.alt).append(",").append(w.zoom).append(",").append(clean(w.layer)).append(",")
                    .append(w.score).append(",").append(clean(w.decision)).append("\n");
        }
        return sb.toString();
    }

    public String kml() {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document><name>BOUH V23</name>");
        int i = 1;
        for(Waypoint w: all()) {
            sb.append("<Placemark><name>").append(clean(w.decision)).append(" ").append(i++).append("</name>")
                    .append("<description><![CDATA[Score ").append(w.score).append("<br>").append(clean(w.report)).append("]]></description>")
                    .append("<Point><coordinates>").append(w.lon).append(",").append(w.lat).append(",").append(w.alt).append("</coordinates></Point></Placemark>");
        }
        sb.append("</Document></kml>");
        return sb.toString();
    }

    private String clean(String s) {
        if (s == null) return "";
        return s.replace(",", " ").replace("\n", " ").replace("&", "and");
    }
}
