
package com.bouh.mapscout;

import java.util.Locale;

public class RadarEngine {
    public static class Report {
        public double bedrock;
        public int gpr;
        public int paleo;
        public int drainage;
        public String summary;
    }

    public Report analyze(double lat, double lon, boolean structure, boolean carrier, boolean trap, boolean feox) {
        double s = Math.abs(Math.sin(lat * 12.9898 + lon * 78.233) * 43758.5453);
        double a = frac(s);
        double b = frac(s * 1.618);
        double c = frac(s * 2.414);
        Report r = new Report();
        r.bedrock = 0.7 + (1.0 - a) * 4.0 + (trap ? 0.8 : 0.0);
        r.gpr = clamp((int)Math.round(35 + a * 45 + (structure ? 10 : 0)), 0, 100);
        r.paleo = clamp((int)Math.round(20 + b * 55 + (trap ? 15 : 0)), 0, 100);
        r.drainage = clamp((int)Math.round(18 + c * 60 + (trap ? 18 : 0)), 0, 100);
        r.summary = String.format(Locale.US, "Bedrock %.1fm | GPR %d%% | Paleo %d%% | Drainage %d%%", r.bedrock, r.gpr, r.paleo, r.drainage);
        return r;
    }

    private double frac(double v) { return v - Math.floor(v); }
    private int clamp(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }
}
