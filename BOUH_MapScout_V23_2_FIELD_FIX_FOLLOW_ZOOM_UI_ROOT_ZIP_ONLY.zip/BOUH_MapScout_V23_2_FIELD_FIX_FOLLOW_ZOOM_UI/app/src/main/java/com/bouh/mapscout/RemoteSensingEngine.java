
package com.bouh.mapscout;

public class RemoteSensingEngine {
    public enum Mode { NATURAL, CLAY, IRON, PROSPECTING }

    public static String label(Mode m) {
        if (m == Mode.CLAY) return "Quartz/Clay visual mode";
        if (m == Mode.IRON) return "Iron Oxide visual mode";
        if (m == Mode.PROSPECTING) return "Prospecting Radar visual mode";
        return "Natural mode";
    }
}
