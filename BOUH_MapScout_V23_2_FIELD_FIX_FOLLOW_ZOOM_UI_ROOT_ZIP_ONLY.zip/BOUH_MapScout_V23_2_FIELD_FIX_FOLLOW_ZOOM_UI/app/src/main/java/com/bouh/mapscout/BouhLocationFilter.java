
package com.bouh.mapscout;

import android.location.Location;
import org.osmdroid.util.GeoPoint;

public class BouhLocationFilter {
    private double lat = Double.NaN;
    private double lon = Double.NaN;
    private float accuracy = -1f;
    private long lastTime = 0L;

    public boolean accept(Location loc) {
        if (loc == null) return false;
        if (Double.isNaN(lat)) return true;
        double d = distance(lat, lon, loc.getLatitude(), loc.getLongitude());
        boolean stale = System.currentTimeMillis() - lastTime > 10000L;
        boolean better = loc.hasAccuracy() && accuracy > 0 && loc.getAccuracy() + 4f < accuracy;
        return d >= 2.0 || stale || better;
    }

    public GeoPoint update(Location loc) {
        if (Double.isNaN(lat)) {
            lat = loc.getLatitude();
            lon = loc.getLongitude();
        } else {
            lat = lat + 0.25 * (loc.getLatitude() - lat);
            lon = lon + 0.25 * (loc.getLongitude() - lon);
        }
        accuracy = loc.hasAccuracy() ? loc.getAccuracy() : accuracy;
        lastTime = System.currentTimeMillis();
        return new GeoPoint(lat, lon);
    }

    public float getAccuracy() {
        return accuracy;
    }

    private double distance(double a, double b, double c, double d) {
        double R = 6371000.0;
        double p1 = Math.toRadians(a), p2 = Math.toRadians(c);
        double dp = Math.toRadians(c - a), dl = Math.toRadians(d - b);
        double x = Math.sin(dp/2)*Math.sin(dp/2) + Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
        return 2 * R * Math.atan2(Math.sqrt(x), Math.sqrt(1-x));
    }
}
