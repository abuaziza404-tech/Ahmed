# BOUH MapScout V23.2 Field Fix Follow Zoom UI

إصلاحات ميدانية بناءً على اختبار المستخدم:
- حل رجوع الدبوس/الخريطة إلى موقع GPS:
  follow=false افتراضيًا.
  أي لمس أو سحب للخريطة يوقف التتبع.
  زر GPS فقط يعيد التتبع للموقع.
- تحسين ثبات الطبقات:
  Display zoom مضبوط إلى Z22 بدل Z24 لتجنب اختفاء مزود البلاطات على بعض الأجهزة/المناطق.
  Native clamp يبقى Z17.
- توضيح الأزرار:
  بنية = Structure
  كوارتز = Carrier/Quartz-Clay
  مصيدة = Trap
  حديد = FeOx
  رادار = Prospecting radar mode
- الإبقاء على:
  osmdroid native map
  GPS jitter filter 2m
  Pin radar proxy
  GPR/Paleo/Drain bars
  SQLite
  KML/CSV
