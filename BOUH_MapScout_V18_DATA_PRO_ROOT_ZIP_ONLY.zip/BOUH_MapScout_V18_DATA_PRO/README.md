# BOUH MapScout V18 DATA-PRO

تطوير V17:
- أخف من V16/V17 مع وضع Lite.
- واجهة عربية مختصرة.
- طبقات: Esri HD، OSM، Topo، Carto.
- طبقات NASA GIBS مؤرخة: TrueColor و Night VIIRS.
- ربط سحابي XYZ لأي خادم: Sentinel Hub / Google Earth Engine / خادم خاص.
- تكبير بالأصابع.
- حفظ أهداف وتصدير CSV/KML.
- قرار BOUH واقعي: بنية + حامل + مصيدة.
- قاعدة الصدق: لا نسب طيفية من البلاطات. استخدم GeoTIFF/RAW/DEM للأرقام.
