# BOUH MapScout V55.2 — GitHub Direct Android Repo

هذه الحزمة هي مشروع Android كامل جاهز للرفع مباشرة إلى جذر مستودع GitHub.

## لا تحتاج إلى Payload ZIP
## لا تحتاج إلى Self-contained Workflow
## لا تحتاج إلى فك ضغط داخل GitHub Actions

فقط ارفع محتويات هذه الحزمة إلى جذر المستودع.

## بنية الملفات المطلوبة في الجذر

```text
settings.gradle
build.gradle
gradle.properties
validate_project.py
app/
.github/workflows/build-android-apk.yml
README_UPLOAD_AR.md
```

## طريقة الرفع

1. افتح مستودع GitHub.
2. ارفع محتويات هذه الحزمة إلى جذر المستودع.
3. تأكد أن الملف التالي موجود:

```text
.github/workflows/build-android-apk.yml
```

4. افتح:

```text
GitHub → Actions → Build BOUH MapScout V55.2 APK → Run workflow
```

5. بعد النجاح، نزّل APK من:

```text
Artifacts → BOUH_MapScout_V55_2_debug_apk → app-debug.apk
```

## ملاحظة

واجهة V55.2 مدمجة داخل:

```text
app/src/main/assets/BOUH_V55_2_Pro_Field_Radar_App.html
```

والتطبيق يفتحها داخل Android WebView.
