package com.bouh.assistantpro

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("bouh_prefs", Context.MODE_PRIVATE)
    fun apiKey() = sp.getString("api_key", "") ?: ""
    fun baseUrl() = sp.getString("base_url", "https://api.openai.com/v1") ?: "https://api.openai.com/v1"
    fun model() = sp.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini"
    fun setApiKey(v: String) = sp.edit().putString("api_key", v).apply()
    fun setBaseUrl(v: String) = sp.edit().putString("base_url", v).apply()
    fun setModel(v: String) = sp.edit().putString("model", v).apply()
    fun addKnowledge(name: String, text: String) {
        val old = sp.getString("knowledge", "") ?: ""
        val item = "\n\n--- FILE: $name ---\n" + text.take(16000)
        sp.edit().putString("knowledge", (old + item).takeLast(80000)).apply()
    }
    fun knowledge() = sp.getString("knowledge", "") ?: ""
    fun clearKnowledge() = sp.edit().remove("knowledge").apply()
}
