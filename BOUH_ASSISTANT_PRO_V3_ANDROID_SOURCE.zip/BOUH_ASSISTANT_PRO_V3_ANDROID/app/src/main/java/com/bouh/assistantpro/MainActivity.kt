package com.bouh.assistantpro

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BouhApp() }
    }
}

enum class Tab(val ar: String) { Chat("المساعد"), Files("الملفات"), Radar("رادار الذهب"), Map("GPS"), Doctor("طبيب عام"), Poetry("الشعر"), Settings("الإعدادات") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BouhApp() {
    val context = LocalContext.current
    val prefs = remember { Prefs(context) }
    var tab by remember { mutableStateOf(Tab.Chat) }
    MaterialTheme(colorScheme = lightColorScheme()) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("مساعد منظومة أبوعزيزه Pro", fontWeight = FontWeight.Bold) }) },
            bottomBar = {
                NavigationBar {
                    val items = listOf(Tab.Chat to Icons.Default.Chat, Tab.Files to Icons.Default.Folder, Tab.Radar to Icons.Default.Radar, Tab.Map to Icons.Default.Map, Tab.Settings to Icons.Default.Settings)
                    items.forEach { (t, icon) -> NavigationBarItem(selected = tab == t, onClick = { tab = t }, icon = { Icon(icon, null) }, label = { Text(t.ar) }) }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    Tab.Chat -> ChatScreen(prefs)
                    Tab.Files -> FilesScreen(prefs)
                    Tab.Radar -> RadarScreen()
                    Tab.Map -> MapScreen()
                    Tab.Doctor -> DoctorScreen()
                    Tab.Poetry -> PoetryScreen()
                    Tab.Settings -> SettingsScreen(prefs)
                }
            }
        }
    }
}

@Composable
fun ChatScreen(prefs: Prefs) {
    val scope = rememberCoroutineScope()
    val ai = remember { AiClient(prefs) }
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("النظام: جاهز. يعمل محليًا بردود خفيفة، ومع API Key يعمل كسحابي.")) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            messages.forEach { ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(it, Modifier.padding(12.dp)) } }
        }
        OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth(), label = { Text("اكتب سؤالك") }, minLines = 2)
        Button(onClick = {
            val q = input.trim(); if (q.isBlank()) return@Button
            input = ""; messages = messages + "أنت: $q" + "المساعد: جاري التفكير..."
            scope.launch {
                val ans = ai.ask(q, prefs.knowledge())
                messages = messages.dropLast(1) + "المساعد: $ans"
            }
        }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("إرسال") }
    }
}

@Composable
fun FilesScreen(prefs: Prefs) {
    val context = LocalContext.current
    var status by remember { mutableStateOf("ارفع TXT/MD/CSV/JSON/XML/KML/GeoJSON. PDF/DOCX/GeoTIFF يتم حفظ اسمه كمعلومة، والتحليل العميق يحتاج مكتبات لاحقة.") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val name = uri.lastPathSegment ?: "uploaded_file"
            val text = runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: "" }.getOrDefault("")
            prefs.addKnowledge(name, if (text.isBlank()) "تم رفع ملف غير نصي: $name. يحتاج Parser متخصص." else text)
            status = "تمت إضافة الملف إلى المعرفة المحلية: $name / حجم النص: ${text.length} حرف"
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("مركز الملفات والمعرفة", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(status, Modifier.padding(vertical = 8.dp))
        Button(onClick = { picker.launch("*/*") }, modifier = Modifier.fillMaxWidth()) { Text("رفع ملف معرفة") }
        OutlinedButton(onClick = { prefs.clearKnowledge(); status = "تم مسح المعرفة المحلية." }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("مسح المعرفة") }
        Text("حجم المعرفة الحالي: ${prefs.knowledge().length} حرف", Modifier.padding(top = 16.dp))
        Text("النواقص المتعمدة بصدق: لا يوجد Parser عميق لـPDF/DOCX/GeoTIFF داخل هذه النسخة الخفيفة. أضفت البنية لاستقبالها لاحقًا.", Modifier.padding(top = 12.dp))
    }
}

@Composable
fun RadarScreen() {
    var structure by remember { mutableStateOf("0.70") }
    var pattern by remember { mutableStateOf("0.60") }
    var alteration by remember { mutableStateOf("0.55") }
    var quartz by remember { mutableStateOf("0.65") }
    var magnetic by remember { mutableStateOf("0.40") }
    val input = BouhInput(structure.toDoubleOrNull() ?: 0.0, pattern.toDoubleOrNull() ?: 0.0, alteration.toDoubleOrNull() ?: 0.0, 0.55, 0.50, 0.50, 0.50, magnetic.toDoubleOrNull() ?: 0.0, quartz.toDoubleOrNull() ?: 0.0, "")
    val d = BouhDecisionEngine.evaluate(input)
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("رادار الذهب - Decision Engine", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("أدخل قيماً ترجيحية من 0 إلى 1. هذه ليست حسابات بكسل ولا نسب طيفية حقيقية.", Modifier.padding(vertical = 8.dp))
        Row { NumField("Structure", structure) { structure = it }; Spacer(Modifier.width(8.dp)); NumField("Pattern", pattern) { pattern = it } }
        Row { NumField("Alteration", alteration) { alteration = it }; Spacer(Modifier.width(8.dp)); NumField("Quartz", quartz) { quartz = it } }
        NumField("Magnetic Risk", magnetic) { magnetic = it }
        ElevatedCard(Modifier.fillMaxWidth().padding(top = 14.dp)) {
            Column(Modifier.padding(14.dp)) {
                Text("H-Score: ${d.hScore}", fontWeight = FontWeight.Bold)
                Text("الأولوية: ${d.targetClass}")
                Text("البصمة: ${d.fingerprint}")
                Text("القرار: ${d.decision}", Modifier.padding(top = 8.dp))
                Text(d.gpzStrategy, Modifier.padding(top = 8.dp), fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun RowScope.NumField(label: String, value: String, set: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = set, label = { Text(label) }, modifier = Modifier.weight(1f).padding(vertical = 4.dp))
}

@Composable
fun MapScreen() {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPermission = it }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (hasPermission) "GPS مسموح" else "GPS غير مفعل", Modifier.weight(1f))
            Button(onClick = { launcher.launch(Manifest.permission.ACCESS_FINE_LOCATION) }) { Text("تفعيل GPS") }
        }
        AndroidView(modifier = Modifier.weight(1f).fillMaxWidth(), factory = { ctx ->
            WebView(ctx).apply {
                webViewClient = WebViewClient(); settings.javaScriptEnabled = true; settings.domStorageEnabled = true
                loadDataWithBaseURL("https://leafletjs.com", leafletHtml(), "text/html", "utf-8", null)
            }
        })
    }
}

fun leafletHtml(): String = """
<!doctype html><html><head><meta name='viewport' content='width=device-width, initial-scale=1.0'>
<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'/>
<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>
<style>html,body,#map{height:100%;margin:0}.box{position:absolute;z-index:999;top:8px;left:8px;background:white;padding:6px;border-radius:8px;font-family:sans-serif}</style></head>
<body><div id='map'></div><div class='box'>BOUH GPS / Online map. Offline MBTiles تحتاج تطوير لاحق.</div>
<script>var m=L.map('map').setView([19.5,36.2],8);L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(m);L.circle([19.5,36.2],{radius:5000}).addTo(m).bindPopup('BOUH study area');</script></body></html>
""".trimIndent()

@Composable
fun DoctorScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("طبيب عام - فرز أولي فقط", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("ليس تشخيصًا طبيًا. عند ألم صدر، ضيق نفس، إغماء، نزيف شديد، ألم بطن حاد، حرارة عالية مستمرة أو تسمم: توجه للطوارئ.", Modifier.padding(top = 8.dp))
    }
}

@Composable
fun PoetryScreen() {
    var topic by remember { mutableStateOf("الفخر") }
    val sample = "يا راكبٍ فوق السحاب المهابه\nسلّم على دارٍ تعلّي مناره\nوالطيب في فعل الرجال انتسابه\nوالشعر ميزان المعاني ووقاره"
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("الشاعر النبطي", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = topic, onValueChange = { topic = it }, label = { Text("الموضوع") }, modifier = Modifier.fillMaxWidth())
        ElevatedCard(Modifier.fillMaxWidth().padding(top = 12.dp)) { Text("مثال على موضوع $topic:\n\n$sample", Modifier.padding(12.dp)) }
    }
}

@Composable
fun SettingsScreen(prefs: Prefs) {
    var key by remember { mutableStateOf(prefs.apiKey()) }
    var base by remember { mutableStateOf(prefs.baseUrl()) }
    var model by remember { mutableStateOf(prefs.model()) }
    var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(key, { key = it; saved = false }, label = { Text("API Key") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(base, { base = it; saved = false }, label = { Text("Base URL") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(model, { model = it; saved = false }, label = { Text("Model") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { prefs.setApiKey(key); prefs.setBaseUrl(base); prefs.setModel(model); saved = true }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("حفظ") }
        if (saved) Text("تم الحفظ.", Modifier.padding(top = 8.dp))
        Text("ملاحظة: لا أضع مفتاح API داخل الكود. أدخله من هاتفك فقط.", Modifier.padding(top = 16.dp))
    }
}
