package com.bouh.assistantpro

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AiClient(private val prefs: Prefs) {
    suspend fun ask(userPrompt: String, knowledge: String): String = withContext(Dispatchers.IO) {
        val apiKey = prefs.apiKey()
        val base = prefs.baseUrl().trimEnd('/')
        val model = prefs.model()
        if (apiKey.isBlank()) return@withContext localAnswer(userPrompt, knowledge)
        runCatching {
            val url = URL("$base/chat/completions")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 30000
                readTimeout = 60000
                doOutput = true
                setRequestProperty("Authorization", "Bearer $apiKey")
                setRequestProperty("Content-Type", "application/json")
            }
            val sys = "أنت مساعد منظومة أبوعزيزه. لا تخترع أرقامًا جيولوجية. استخدم قاعدة Structure -> Pattern -> Alteration -> Confirmation -> Decision. إذا لا توجد بيانات خام قل لا أملك بيانات كافية لحساب هذا رقمياً."
            val body = JSONObject()
                .put("model", model)
                .put("temperature", 0.2)
                .put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", sys))
                    .put(JSONObject().put("role", "user").put("content", "معرفة محلية:\n$knowledge\n\nالسؤال:\n$userPrompt")))
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val text = conn.inputStream.bufferedReader().readText()
            JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }.getOrElse { "تعذر الاتصال بالـAPI. الرد المحلي:\n\n${localAnswer(userPrompt, knowledge)}\n\nسبب الخطأ: ${it.message}" }
    }

    private fun localAnswer(q: String, knowledge: String): String {
        val lower = q.lowercase()
        return when {
            lower.contains("gpz") || lower.contains("7000") -> "إعداد GPZ يعتمد على الخطر المغناطيسي: إذا laterite/basalt عالي استخدم Severe/Difficult + High Yield + Sensitivity 8-11. إذا الأرض هادئة والكوارتز قوي استخدم Normal + General/Deep + Sensitivity 12-16. لا أملك بيانات كافية لحساب ذلك رقمياً من هذا السؤال وحده."
            lower.contains("ذهب") || lower.contains("gold") -> "القرار في بوح يبدأ بالبنية لا بالحديد: Structure ثم Pattern ثم Alteration ثم Confirmation. FeOx وحده غير كافٍ. ارفع KML/CSV/ملاحظات أو GeoTIFF خام حتى يمكن ترجيح الهدف."
            knowledge.isNotBlank() -> "تم العثور على معرفة محلية مرفوعة. أستطيع تلخيصها وربطها بقواعد بوح، لكن لا يوجد نموذج محلي GGUF مدمج داخل هذه النسخة.\n\nمقتطف معرفة:\n${knowledge.take(1200)}"
            else -> "أنا أعمل الآن في الوضع المحلي الخفيف. أضف API Key للذكاء السحابي أو ارفع ملفات معرفة. للوضع المحلي الكامل يلزم دمج llama.cpp وملف GGUF من الجهاز."
        }
    }
}
