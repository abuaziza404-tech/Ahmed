package com.bouh.assistantpro

import kotlin.math.max
import kotlin.math.min

data class BouhInput(
    val structure: Double,
    val pattern: Double,
    val alteration: Double,
    val carrier: Double,
    val cluster: Double,
    val terrain: Double,
    val context: Double,
    val magneticGroundRisk: Double,
    val quartzIndex: Double,
    val notes: String
)

data class BouhDecision(
    val hScore: Double,
    val targetClass: String,
    val decision: String,
    val gpzStrategy: String,
    val fingerprint: String
)

object BouhDecisionEngine {
    private fun c(v: Double) = min(1.0, max(0.0, v))

    fun evaluate(input: BouhInput): BouhDecision {
        val s = c(input.structure)
        val p = c(input.pattern)
        val a = c(input.alteration)
        val carrier = c(input.carrier)
        val cluster = c(input.cluster)
        val terrain = c(input.terrain)
        val context = c(input.context)
        val h = 0.30*s + 0.20*p + 0.15*a + 0.10*carrier + 0.10*cluster + 0.10*terrain + 0.05*context
        val klass = when {
            s < 0.35 -> "Reject: لا توجد بنية كافية"
            a < 0.25 && input.quartzIndex < 0.45 -> "Reject: لا طين/سيليكا داعمة"
            h >= 0.78 -> "Class A"
            h >= 0.58 -> "Class B"
            h >= 0.42 -> "Class C"
            else -> "Reject / Recon only"
        }
        val decision = when {
            klass.startsWith("Class A") -> "اختبار ميداني مباشر: مقطع مشي بطيء + عينة + GPZ حول الحواف البنيوية ومخارج الشعاب."
            klass.startsWith("Class B") -> "تحقق قبل الحفر: صور أرضية + عينة كوارتز/FeOx + مسح GPZ محدود."
            klass.startsWith("Class C") -> "استطلاع فقط: لا حفر قبل ظهور بنية أو سيليكا/طين أو دليل GPZ."
            else -> "رفض الهدف: لا تعتمد على FeOx وحده ولا تجعل الحفر القديمة هدف البحث."
        }
        val gpz = if (input.magneticGroundRisk > 0.75) {
            "GPZ 7000: Ground Type Severe/Difficult، Gold Mode High Yield، Sensitivity 8-11، Audio Smoothing Low/On، مشي بطيء جدًا وتكرار الإشارة من اتجاهين."
        } else if (input.magneticGroundRisk < 0.45 && input.quartzIndex > 0.60) {
            "GPZ 7000: Ground Type Normal، Gold Mode General/Deep، Sensitivity 12-16، Audio Smoothing Off، مناسب لجيوب bedrock ضحلة ومتوسطة."
        } else {
            "GPZ 7000: ابدأ Difficult + High Yield + Sensitivity 10-12، ثم ارفع الحساسية تدريجيًا إذا استقر الصوت."
        }
        val fingerprint = "Structure=${fmt(s)}, Pattern=${fmt(p)}, Alteration=${fmt(a)}, Quartz=${fmt(c(input.quartzIndex))}, MagneticRisk=${fmt(c(input.magneticGroundRisk))}"
        return BouhDecision(round(h), klass, decision, gpz, fingerprint)
    }

    private fun fmt(v: Double) = "%.2f".format(v)
    private fun round(v: Double) = "%.3f".format(v).toDouble()
}
