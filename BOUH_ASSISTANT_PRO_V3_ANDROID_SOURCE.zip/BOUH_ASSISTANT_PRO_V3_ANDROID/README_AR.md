# مساعد منظومة أبوعزيزه Pro V3 Android

هذه حزمة مصدر Android جاهزة للرفع دفعة واحدة على GitHub Actions.

## ما الذي تم تطويره فوق APK السابق؟

- تحويل الفكرة من مساعد دردشة فقط إلى تطبيق متعدد الوحدات.
- إضافة شاشة مساعد عربي مع API OpenAI-compatible ووضع محلي خفيف عند عدم وجود API Key.
- إضافة مركز ملفات/معرفة يستقبل TXT/MD/CSV/JSON/XML/KML/GeoJSON نصياً.
- إضافة BOUH Decision Engine: Structure → Pattern → Alteration → Confirmation → Decision.
- إضافة GPZ 7000 strategy حسب الخطر المغناطيسي ومؤشر الكوارتز.
- إضافة شاشة GPS/WebMap أولية.
- إضافة شاشة طبيب عام للفرز التحذيري، وليست تشخيصاً.
- إضافة شاشة شاعر نبطي أولية.
- إضافة GitHub Actions لبناء debug و release unsigned APK.
- تحسين Manifest: allowBackup=false، cleartext=false، release minify/shrink.

## الصدق التقني

هذه نسخة Pro Source عملية، لكنها ليست بعد نسخة Offline LLM كاملة، لأن النموذج GGUF ومحرك llama.cpp غير مدمجين داخل الحزمة للحفاظ على الحجم وقابلية البناء من الهاتف. لإكمال offline الحقيقي يلزم:

1. دمج llama.cpp Android JNI.
2. اختيار/تحميل ملف GGUF مناسب للجهاز.
3. إضافة RAG حقيقي: chunking + embeddings + SQLite FTS/vector.
4. إضافة parsers لـ PDF/DOCX/XLSX/GeoTIFF/KMZ.
5. إضافة خرائط Offline MBTiles/GeoPackage.
6. إضافة تصدير KMZ/CSV للأهداف.

## طريقة الرفع

ارفع محتويات هذا المجلد إلى جذر المستودع، أو ارفع ZIP ثم فكّه داخل GitHub.
بعدها افتح تبويب Actions وشغّل workflow باسم:

Android Build BOUH Pro V3

ستجد APK في Artifacts.
