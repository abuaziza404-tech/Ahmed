
package com.bouh.mapscout;

public class RemoteSensingEngine {
    public enum Mode { NATURAL, CLAY, IRON, PROSPECTING }

    public static String label(Mode m) {
        if (m == Mode.CLAY) return "تحول: Fe/Clay/Quartz";
        if (m == Mode.IRON) return "ضجيج: NDVI/vegetation risk";
        if (m == Mode.PROSPECTING) return "قرار بوح: Structure→Alteration→Field-check";
        return "BOUH Terrain Truth Core";
    }
}
