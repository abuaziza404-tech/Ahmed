
package com.bouh.mapscout;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;

public class SentinelDataGrid {
    public static class Cell {
        public double lat, lon, structure, alteration, iron, clay, quartz, traps, mountain, surface, vein, noise, ndvi, score;
        public String zone = "", coverage = "", top = "", decision = "";
    }

    public static class Result {
        public boolean inside;
        public Cell cell;
        public double distanceM;
        public double score;
        public int surfacePriority, veinPriority, wadiPriority, mountainPriority, noiseRisk;
        public String topIndicator = "غير محدد";
        public String decision = "NO DATA";
        public String report = "لا توجد بيانات.";
    }

    private final ArrayList<Cell> cells = new ArrayList<>();
    private boolean loaded = false;

    public void load(Context ctx) {
        if (loaded) return;
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(ctx.getAssets().open("bouh_truth_grid_v27_156k.csv"), "UTF-8"));
            br.readLine();
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split(",", -1);
                if (p.length < 18) continue;
                Cell c = new Cell();
                c.lat = d(p[0]); c.lon = d(p[1]); c.zone = p[2]; c.coverage = p[3];
                c.structure = d(p[4]); c.alteration = d(p[5]); c.iron = d(p[6]); c.clay = d(p[7]); c.quartz = d(p[8]);
                c.traps = d(p[9]); c.mountain = d(p[10]); c.surface = d(p[11]); c.vein = d(p[12]); c.noise = d(p[13]);
                c.ndvi = d(p[14]); c.score = d(p[15]); c.top = p[16]; c.decision = p[17];
                cells.add(c);
            }
            br.close();
        } catch(Exception ignored) {}
        loaded = true;
    }

    public Result nearest(double lat, double lon, boolean structureOn, boolean alterationOn, boolean trapsOn, boolean noiseCheck) {
        Result r = new Result();
        if (cells.isEmpty()) {
            r.inside = false;
            r.decision = "NO DATA";
            r.report = "لا توجد شبكة V27 داخل التطبيق.";
            return r;
        }
        Cell best = null;
        double bestM = Double.MAX_VALUE;
        for (Cell c: cells) {
            double dist = distance(lat, lon, c.lat, c.lon);
            if (dist < bestM) { bestM = dist; best = c; }
        }
        r.cell = best;
        r.distanceM = bestM;
        r.inside = best != null && bestM <= 1200.0; // denser V27 grid: stricter truth radius

        if (!r.inside) {
            r.decision = "OUTSIDE DATA";
            r.report = String.format(Locale.US,
                    "OUTSIDE DATA | أقرب خلية %.0fm\nالنقطة خارج تغطية شبكة V27 أو بعيدة عن أقرب بيكسل حقيقي.",
                    bestM);
            return r;
        }

        double surface = best.surface + (structureOn ? 3 : 0) + (alterationOn ? 4 : 0);
        double vein = best.vein + (structureOn ? 5 : 0) + (alterationOn ? 4 : 0);
        double wadi = best.traps + (trapsOn ? 6 : 0) + (structureOn ? 2 : 0);
        double mountain = best.mountain + (structureOn ? 4 : 0) + (alterationOn ? 3 : 0);

        if (noiseCheck && best.noise > 65) {
            surface *= 0.75; vein *= 0.75; wadi *= 0.75; mountain *= 0.75;
        }

        r.surfacePriority = ci(surface);
        r.veinPriority = ci(vein);
        r.wadiPriority = ci(wadi);
        r.mountainPriority = ci(mountain);
        r.noiseRisk = ci(best.noise);
        r.score = Math.max(Math.max(r.surfacePriority, r.veinPriority), Math.max(r.wadiPriority, r.mountainPriority));

        r.topIndicator = "سطحي";
        if (r.veinPriority >= r.surfacePriority && r.veinPriority >= r.wadiPriority && r.veinPriority >= r.mountainPriority) r.topIndicator = "عروق";
        if (r.wadiPriority >= r.surfacePriority && r.wadiPriority >= r.veinPriority && r.wadiPriority >= r.mountainPriority) r.topIndicator = "مصائد/وديان";
        if (r.mountainPriority >= r.surfacePriority && r.mountainPriority >= r.veinPriority && r.mountainPriority >= r.wadiPriority) r.topIndicator = "جبال/حواف";

        if (r.score >= 78) r.decision = "FIELD CHECK PRIORITY";
        else if (r.score >= 62) r.decision = "CHECK / HOLD+";
        else if (r.score >= 48) r.decision = "LOW CHECK";
        else r.decision = "REJECT / HOLD";

        r.report = String.format(Locale.US,
                "%s | %.0f%% | الأعلى: %s\nZone %s | cell %.0fm | pixels: 156k\nسطحي %d%% | عروق %d%% | مصائد %d%% | جبال %d%% | ضجيج %d%%\nبنية %.0f%% | تحول %.0f%% | Fe %.0f%% | Clay %.0f%% | Quartz %.0f%% | NDVI %.3f",
                r.decision, r.score, r.topIndicator,
                best.zone, bestM,
                r.surfacePriority, r.veinPriority, r.wadiPriority, r.mountainPriority, r.noiseRisk,
                best.structure, best.alteration, best.iron, best.clay, best.quartz, best.ndvi);
        return r;
    }

    private double d(String s) { try { return Double.parseDouble(s); } catch(Exception e) { return -1.0; } }
    private int ci(double v) { return (int)Math.round(Math.max(0, Math.min(100, v))); }

    private double distance(double lat1, double lon1, double lat2, double lon2) {
        double R = 6371000.0;
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2);
        double dp = Math.toRadians(lat2-lat1), dl = Math.toRadians(lon2-lon1);
        double a = Math.sin(dp/2)*Math.sin(dp/2) + Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
        return 2*R*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }
}
