# BOUH MapScout V27 BOUH Terrain Truth Radar

نسخة مبنية على ملفات Sentinel المرفوعة مع شبكة أكبر:

- عدد الخلايا: 156000
- مصدر الخلايا: North/Center/South uploaded zone GeoTIFF/TIFF bands
- الباندات: B02, B03, B04, B08, B11, B12
- لا يوجد GPR/Bedrock/Gold proof وهمي.
- الأزرار:
  - بنية = Structure / lineament
  - تحول = Alteration Fe/Clay/Quartz
  - مصائد = wadi/trap/slope-break priority
  - ضجيج = NDVI/noise risk
  - قرار = BOUH decision mode
- زر طبقات واضح.
- زر رادار واضح.
- وديان تم تغييرها إلى مصائد لأنها أدق ميدانيًا.

ملاحظة: هذه درجات أولوية ميدانية وليست إثبات ذهب. الإثبات عبر GPZ/عينة/assay.
