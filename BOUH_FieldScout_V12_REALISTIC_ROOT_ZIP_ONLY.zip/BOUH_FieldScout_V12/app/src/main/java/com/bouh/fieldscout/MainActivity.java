package com.bouh.fieldscout;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.text.TextUtils;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements LocationListener, SensorEventListener {
    private TextureView preview;
    private View boostOverlay;
    private TextView hud, decisionView, logView;
    private LinearLayout panel;
    private EditText noteBox;
    private RadioGroup rgStructure, rgAlteration, rgFeOx, rgTrap, rgNoise, rgGpz;
    private CheckBox cbQuartzVein, cbQuartzFloat, cbGossanTexture, cbOldWorkings, cbWadiJunction, cbHillFoot, cbDarkRegolith, cbBariteLateriteRisk, cbBasaltMagRisk, cbSampleTaken, cbPhotoOnly;
    private Button btnBoost, btnTorch;

    private CameraDevice camera;
    private CameraCaptureSession session;
    private CaptureRequest.Builder request;
    private HandlerThread camThread;
    private Handler camHandler;
    private CameraCharacteristics cameraChars;
    private String cameraId;
    private float zoom = 1f;
    private boolean torch = false;
    private boolean boostPreview = false;
    private long frames = 0;
    private long fpsStart = 0;
    private float fps = 0;

    private Location lastLocation;
    private float azimuth = 0f;
    private LocationManager locManager;
    private SensorManager sensorManager;
    private float[] gravityValues;
    private float[] magneticValues;
    private final ArrayList<TargetPoint> targets = new ArrayList<>();
    private final SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);

    static class TargetPoint {
        String time, note, decision, decisionClass, reason, gpz, fingerprint, sourceTag, photoPath;
        double lat, lon, alt;
        float heading, score;
        int structure, alteration, feox, trap, noise, gpzSignal;
        boolean quartzVein, quartzFloat, gossanTexture, oldWorkings, wadiJunction, hillFoot, darkRegolith, bariteLateriteRisk, basaltMagRisk, sampleTaken, photoOnly;
    }

    static class Result {
        float score;
        String cls, decision, reason, gpz, fingerprint, spectral;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        locManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        requestPermissionsIfNeeded();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        preview = new TextureView(this);
        root.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        boostOverlay = new View(this);
        boostOverlay.setBackgroundColor(Color.argb(35, 255, 235, 120));
        boostOverlay.setVisibility(View.GONE);
        root.addView(boostOverlay, new FrameLayout.LayoutParams(-1, -1));

        hud = new TextView(this);
        hud.setTextColor(Color.rgb(230, 205, 135));
        hud.setTextSize(13f);
        hud.setPadding(dp(12), dp(10), dp(12), dp(6));
        hud.setShadowLayer(5, 0, 0, Color.BLACK);
        root.addView(hud, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        TextView cross = new TextView(this);
        cross.setText("＋\nBOUH V12");
        cross.setGravity(Gravity.CENTER);
        cross.setTextColor(Color.argb(170, 230, 205, 135));
        cross.setTextSize(30f);
        cross.setShadowLayer(4, 0, 0, Color.BLACK);
        root.addView(cross, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        ScrollView scroll = new ScrollView(this);
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(8), dp(10), dp(18));
        panel.setBackgroundColor(Color.argb(172, 0, 0, 0));
        scroll.addView(panel);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, dp(330), Gravity.BOTTOM);
        root.addView(scroll, sp);

        decisionView = label("BOUH FieldScout V12 — ميداني واقعي: لا يحسب أطياف من الكاميرا؛ يسجل بصمة الأرض وقرار الفحص.", 12, Color.WHITE);
        panel.addView(decisionView);

        LinearLayout top = row();
        btnBoost = btn("RAW/BOOST", v -> { boostPreview = !boostPreview; applyPreviewMode(); });
        btnTorch = btn("TORCH", v -> { torch = !torch; updateCamera(); });
        top.addView(btnBoost); top.addView(btnTorch);
        top.addView(btn("ZOOM+", v -> { zoom = Math.min(10f, zoom + 0.5f); updateCamera(); }));
        top.addView(btn("ZOOM-", v -> { zoom = Math.max(1f, zoom - 0.5f); updateCamera(); }));
        panel.addView(top);

        panel.addView(label("1) البنية الحاكمة Structure", 13, Color.rgb(230,205,135)));
        rgStructure = radios(new String[]{"لا توجد", "ضعيفة", "واضحة", "Shear/Dilation قوي"}, 0); panel.addView(rgStructure);
        panel.addView(label("2) Alteration / Carrier", 13, Color.rgb(230,205,135)));
        rgAlteration = radios(new String[]{"لا يوجد", "Clay/Silica ضعيف", "Clay/Silica واضح", "Silica/Quartz + clay قوي"}, 0); panel.addView(rgAlteration);
        panel.addView(label("3) FeOx/Gossan — داعم فقط وليس هدف مستقل", 13, Color.rgb(230,205,135)));
        rgFeOx = radios(new String[]{"لا يوجد", "FeOx خفيف", "FeOx/Gossan واضح", "FeOx فقط/خطر Laterite"}, 0); panel.addView(rgFeOx);
        panel.addView(label("4) المصيدة الجيومورفولوجية", 13, Color.rgb(230,205,135)));
        rgTrap = radios(new String[]{"لا توجد", "Wadi/Pediment", "Hill-foot", "Wadi junction + feeder"}, 0); panel.addView(rgTrap);
        panel.addView(label("5) الضوضاء/المخاطر", 13, Color.rgb(230,205,135)));
        rgNoise = radios(new String[]{"منخفضة", "متوسطة", "عالية", "رفض/بارايت/لاترايت"}, 0); panel.addView(rgNoise);
        panel.addView(label("6) إشارة GPZ 7000", 13, Color.rgb(230,205,135)));
        rgGpz = radios(new String[]{"لم يفحص", "لا إشارة", "ضعيفة", "متكررة قوية"}, 0); panel.addView(rgGpz);

        LinearLayout checks1 = new LinearLayout(this); checks1.setOrientation(LinearLayout.VERTICAL);
        cbQuartzVein = cb("Quartz vein ظاهر"); cbQuartzFloat = cb("Quartz float/lag"); cbGossanTexture = cb("نسيج gossan/boxwork وليس لون فقط"); cbOldWorkings = cb("حفر قديمة/كشط لودر قريب");
        cbWadiJunction = cb("مخرج شعاب/ملتقى أودية"); cbHillFoot = cb("قدم جبل/حافة pediment"); cbDarkRegolith = cb("Regolith داكن/خشن"); cbBariteLateriteRisk = cb("خطر Barite/Laterite noise"); cbBasaltMagRisk = cb("Basalt/magnetic ground risk"); cbSampleTaken = cb("تم أخذ عينة/رقم كيس في الملاحظة"); cbPhotoOnly = cb("الصورة للفهم البصري فقط");
        for(CheckBox c: new CheckBox[]{cbQuartzVein, cbQuartzFloat, cbGossanTexture, cbOldWorkings, cbWadiJunction, cbHillFoot, cbDarkRegolith, cbBariteLateriteRisk, cbBasaltMagRisk, cbSampleTaken, cbPhotoOnly}) checks1.addView(c);
        panel.addView(checks1);

        noteBox = new EditText(this);
        noteBox.setHint("ملاحظة: لون السطح، roughness، عروق، micro-lineaments، GPZ response، رقم العينة...");
        noteBox.setHintTextColor(Color.LTGRAY);
        noteBox.setTextColor(Color.WHITE);
        noteBox.setMinLines(2);
        noteBox.setSingleLine(false);
        panel.addView(noteBox);

        LinearLayout row2 = row();
        row2.addView(btn("DECIDE", v -> showDecision()));
        row2.addView(btn("SAVE+PHOTO", v -> saveTarget(true)));
        row2.addView(btn("SAVE", v -> saveTarget(false)));
        row2.addView(btn("CLEAR", v -> clearInputs()));
        panel.addView(row2);

        LinearLayout row3 = row();
        row3.addView(btn("CSV", v -> exportCsv()));
        row3.addView(btn("KML", v -> exportKml()));
        row3.addView(btn("JSON", v -> exportJson()));
        row3.addView(btn("REPORT", v -> exportReport()));
        panel.addView(row3);

        logView = label("لا توجد أهداف محفوظة بعد.", 12, Color.LTGRAY);
        panel.addView(logView);

        root.setOnClickListener(v -> { if (panel.getVisibility()==View.VISIBLE) panel.setVisibility(View.GONE); else panel.setVisibility(View.VISIBLE); });
        setContentView(root);
        applyPreviewMode();

        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int h) { startCamera(); }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int h) { updateCamera(); }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s) { return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture s) { frames++; calcFps(); updateHud(); }
        });
    }

    private LinearLayout row(){ LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); return r; }
    private TextView label(String s, int size, int color){ TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); v.setPadding(dp(5),dp(3),dp(5),dp(3)); return v; }
    private Button btn(String s, View.OnClickListener l){ Button b = new Button(this); b.setText(s); b.setTextSize(10f); b.setAllCaps(false); b.setOnClickListener(l); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1); lp.setMargins(dp(3),dp(3),dp(3),dp(3)); b.setLayoutParams(lp); return b; }
    private CheckBox cb(String s){ CheckBox c = new CheckBox(this); c.setText(s); c.setTextColor(Color.WHITE); c.setTextSize(12f); c.setButtonTintList(ColorStateList.valueOf(Color.rgb(230,205,135))); return c; }
    private RadioGroup radios(String[] names, int checked){ RadioGroup g = new RadioGroup(this); g.setOrientation(RadioGroup.HORIZONTAL); for(int i=0;i<names.length;i++){ RadioButton r=new RadioButton(this); r.setText(names[i]); r.setTextColor(Color.WHITE); r.setTextSize(10f); r.setId(9000+i); r.setButtonTintList(ColorStateList.valueOf(Color.rgb(230,205,135))); g.addView(r, new RadioGroup.LayoutParams(0, dp(42), 1)); if(i==checked) r.setChecked(true);} return g; }
    private int radioIndex(RadioGroup g){ int id=g.getCheckedRadioButtonId(); if(id<9000) return 0; return Math.max(0, id-9000); }
    private int dp(int v){ return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s){ Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void requestPermissionsIfNeeded(){
        ArrayList<String> ps = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) ps.add(Manifest.permission.CAMERA);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) ps.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (!ps.isEmpty()) requestPermissions(ps.toArray(new String[0]), 12); else startServices();
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g){ super.onRequestPermissionsResult(r,p,g); startServices(); if(preview.isAvailable()) startCamera(); }

    private void startServices(){
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500, 1, this);
                locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000, 2, this);
                Location l = locManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (l != null) lastLocation = l;
            }
        } catch(Exception ignored) {}
        Sensor rot = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        Sensor acc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensor mag = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if (rot != null) sensorManager.registerListener(this, rot, SensorManager.SENSOR_DELAY_UI);
        else { if(acc!=null) sensorManager.registerListener(this, acc, SensorManager.SENSOR_DELAY_UI); if(mag!=null) sensorManager.registerListener(this, mag, SensorManager.SENSOR_DELAY_UI); }
    }

    private void startCamera(){
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        if (camThread == null) { camThread = new HandlerThread("BOUHCameraV12"); camThread.start(); camHandler = new Handler(camThread.getLooper()); }
        CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            for (String id: cm.getCameraIdList()) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) { cameraId = id; cameraChars = cc; break; }
            }
            if (cameraId == null) { cameraId = cm.getCameraIdList()[0]; cameraChars = cm.getCameraCharacteristics(cameraId); }
            cm.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) { camera = c; createSession(); }
                @Override public void onDisconnected(CameraDevice c) { c.close(); }
                @Override public void onError(CameraDevice c, int e) { decisionView.setText("Camera error: "+e+" — افتح الصلاحيات أو جرّب إعادة التشغيل."); c.close(); }
            }, camHandler);
        } catch(Exception e) { decisionView.setText("Camera start failed: " + e.getMessage()); }
    }

    private void createSession(){
        try {
            SurfaceTexture st = preview.getSurfaceTexture(); if (st == null) return;
            st.setDefaultBufferSize(1280, 720);
            Surface surface = new Surface(st);
            request = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            request.addTarget(surface);
            camera.createCaptureSession(Arrays.asList(surface), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession s) { session = s; updateCamera(); }
                @Override public void onConfigureFailed(CameraCaptureSession s) { decisionView.setText("Camera session failed"); }
            }, camHandler);
        } catch(Exception e) { decisionView.setText("Session failed: " + e.getMessage()); }
    }

    private void updateCamera(){
        if (session == null || request == null) return;
        try {
            request.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
            request.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            request.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            request.set(CaptureRequest.FLASH_MODE, torch ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            Rect crop = zoomCrop();
            if (crop != null) request.set(CaptureRequest.SCALER_CROP_REGION, crop);
            session.setRepeatingRequest(request.build(), null, camHandler);
            btnTorch.setText(torch ? "TORCH ON" : "TORCH");
        } catch(Exception e) { decisionView.setText("Camera update failed: " + e.getMessage()); }
    }

    private Rect zoomCrop(){
        try {
            if (cameraChars == null || zoom <= 1.01f) return null;
            Rect sensor = cameraChars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            if (sensor == null) return null;
            int cropW = (int)(sensor.width() / zoom);
            int cropH = (int)(sensor.height() / zoom);
            int left = sensor.left + (sensor.width() - cropW)/2;
            int top = sensor.top + (sensor.height() - cropH)/2;
            return new Rect(left, top, left+cropW, top+cropH);
        } catch(Exception e){ return null; }
    }

    private void applyPreviewMode(){
        if (boostPreview) {
            preview.setAlpha(1f);
            boostOverlay.setVisibility(View.VISIBLE);
            btnBoost.setText("BOOST ON");
        } else {
            boostOverlay.setVisibility(View.GONE);
            btnBoost.setText("RAW VIEW");
        }
    }

    private void calcFps(){ long now=System.currentTimeMillis(); if(fpsStart==0){fpsStart=now; frames=0;} if(now-fpsStart>=1000){ fps=frames*1000f/(now-fpsStart); fpsStart=now; frames=0; } }

    private Result evaluate(){
        int s = radioIndex(rgStructure), a = radioIndex(rgAlteration), f = radioIndex(rgFeOx), t = radioIndex(rgTrap), n = radioIndex(rgNoise), g = radioIndex(rgGpz);
        boolean quartz = cbQuartzVein.isChecked() || cbQuartzFloat.isChecked();
        boolean analog = cbOldWorkings.isChecked() || cbWadiJunction.isChecked() || cbHillFoot.isChecked() || cbDarkRegolith.isChecked();
        boolean highNoise = n >= 2 || cbBariteLateriteRisk.isChecked() || cbBasaltMagRisk.isChecked();

        float score = 0;
        score += s * 13;                 // max 39
        score += a * 11;                 // max 33
        score += quartz ? 8 : 0;
        score += Math.min(f,2) * 4;       // FeOx capped; color only cannot dominate
        score += t * 5;
        score += analog ? 8 : 0;
        score += g == 3 ? 14 : (g == 2 ? 6 : 0);
        score -= highNoise ? 18 : (n == 1 ? 5 : 0);
        if (cbGossanTexture.isChecked()) score += 5;
        if (cbSampleTaken.isChecked()) score += 4;
        score = Math.max(0, Math.min(100, score));

        Result r = new Result(); r.score = score; r.spectral = "[FIELD OBSERVATION ONLY] لا توجد نسب طيفية محسوبة؛ الكاميرا/GPS ليست بديل GeoTIFF/ASTER/Sentinel/Landsat RAW.";
        ArrayList<String> fp = new ArrayList<>();
        if(s>0) fp.add("Structure="+level(s)); if(a>0) fp.add("Alteration="+level(a)); if(quartz) fp.add("Quartz"); if(f>0) fp.add("FeOx/Gossan="+level(f)); if(t>0) fp.add("Trap="+level(t)); if(analog) fp.add("BOUH analog"); if(highNoise) fp.add("Noise risk high"); if(g>1) fp.add("GPZ="+level(g));
        r.fingerprint = fp.isEmpty()?"No positive fingerprint": TextUtils.join(" + ", fp);

        if (s == 0 && a == 0) {
            r.cls = "REJECT"; r.decision = "REJECT — لا Structure ولا Clay/Silica/Quartz كافية"; r.reason = "لا تقييم على FeOx أو لون فقط. ابحث عن الأرض التي تشبه ما قبل الحفر: بنية + Alteration + pattern.";
        } else if (s == 0 && g < 3) {
            r.cls = "REJECT"; r.decision = "REJECT — لا توجد بنية حاكمة"; r.reason = "No Structure = لا هدف، إلا إذا وُجد دليل GPZ قوي متكرر مع analog واضح.";
        } else if (a == 0 && !quartz && g < 3) {
            r.cls = "REJECT"; r.decision = "REJECT — لا Clay/Silica/Quartz"; r.reason = "FeOx أو regolith وحده قد يكون laterite/barite/noise.";
        } else if (highNoise && score < 72) {
            r.cls = "CLASS C"; r.decision = "CLASS C — عينة وفحص ضوضاء قبل أي حفر"; r.reason = "خطر مغناطيسي/لاترايت/بارايت؛ لا تعتمد على اللون أو إشارة واحدة.";
        } else if (score >= 78) {
            r.cls = "CLASS A"; r.decision = "CLASS A — GPZ grid + sample + test pit فقط بعد تأكيد"; r.reason = "Structure + alteration + carrier/pattern متوافقة مع نموذج BOUH.";
        } else if (score >= 58) {
            r.cls = "CLASS B"; r.decision = "CLASS B — خط سير GPZ + عينات + مراجعة صور/DEM"; r.reason = "واعد لكنه يحتاج confirmation قبل الحفر.";
        } else {
            r.cls = "CLASS C"; r.decision = "CLASS C — Check only / لا حفر"; r.reason = "البصمة ناقصة أو الضوضاء عالية.";
        }
        r.gpz = gpzAdvice(highNoise, quartz, a, g);
        return r;
    }

    private String level(int v){ switch(v){ case 1:return"weak"; case 2:return"clear"; case 3:return"strong"; default:return"none"; } }
    private String gpzAdvice(boolean highNoise, boolean quartz, int alteration, int gpzSignal){
        if (highNoise) return "GPZ: Severe/Difficult | High Yield | Sens 8-11 | Smoothing Low/On | slow swing | repeat signal from 2 directions.";
        if (quartz && alteration >= 2) return "GPZ: Normal if stable else Difficult | General/Deep for depth | Sens 12-16 | Smoothing Off | coil control slow.";
        if (gpzSignal >= 2) return "GPZ: High Yield first, then General cross-check | Sens 10-13 | mark repeatability, scrape 5-10cm and retest.";
        return "GPZ: Difficult/Normal حسب الأرض | High Yield | Sens 10-13 | لا حفر بدون repeatable response.";
    }

    private void showDecision(){ Result r = evaluate(); decisionView.setText(r.decision + " | Score " + Math.round(r.score) + "/100\n" + r.reason + "\n" + r.fingerprint + "\n" + r.gpz + "\n" + r.spectral); }

    private void saveTarget(boolean withPhoto){
        TargetPoint t = new TargetPoint();
        Result r = evaluate();
        t.time = fmt.format(new Date()); t.note = noteBox.getText().toString(); t.decision = r.decision; t.decisionClass = r.cls; t.reason = r.reason; t.score = r.score; t.gpz = r.gpz; t.fingerprint = r.fingerprint; t.sourceTag = r.spectral; t.heading = azimuth;
        t.structure=radioIndex(rgStructure); t.alteration=radioIndex(rgAlteration); t.feox=radioIndex(rgFeOx); t.trap=radioIndex(rgTrap); t.noise=radioIndex(rgNoise); t.gpzSignal=radioIndex(rgGpz);
        t.quartzVein=cbQuartzVein.isChecked(); t.quartzFloat=cbQuartzFloat.isChecked(); t.gossanTexture=cbGossanTexture.isChecked(); t.oldWorkings=cbOldWorkings.isChecked(); t.wadiJunction=cbWadiJunction.isChecked(); t.hillFoot=cbHillFoot.isChecked(); t.darkRegolith=cbDarkRegolith.isChecked(); t.bariteLateriteRisk=cbBariteLateriteRisk.isChecked(); t.basaltMagRisk=cbBasaltMagRisk.isChecked(); t.sampleTaken=cbSampleTaken.isChecked(); t.photoOnly=cbPhotoOnly.isChecked();
        if (lastLocation != null) { t.lat=lastLocation.getLatitude(); t.lon=lastLocation.getLongitude(); t.alt=lastLocation.hasAltitude()?lastLocation.getAltitude():0; }
        if (withPhoto) t.photoPath = savePreviewPhoto(t.time);
        targets.add(t); updateLog(); showDecision(); toast("Saved target " + targets.size());
    }

    private String savePreviewPhoto(String time){
        try {
            Bitmap bmp = preview.getBitmap(); if (bmp == null) return "";
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "BOUH_FieldScout_V12"); if(!dir.exists()) dir.mkdirs();
            String name = "BOUH_V12_" + time.replace(":","-").replace(" ","_") + ".jpg";
            File f = new File(dir, name);
            FileOutputStream out = new FileOutputStream(f); bmp.compress(Bitmap.CompressFormat.JPEG, 92, out); out.close();
            return f.getAbsolutePath();
        } catch(Exception e){ return "PHOTO_FAILED: " + e.getMessage(); }
    }

    private void clearInputs(){
        rgStructure.check(9000); rgAlteration.check(9000); rgFeOx.check(9000); rgTrap.check(9000); rgNoise.check(9000); rgGpz.check(9000);
        for(CheckBox c: new CheckBox[]{cbQuartzVein, cbQuartzFloat, cbGossanTexture, cbOldWorkings, cbWadiJunction, cbHillFoot, cbDarkRegolith, cbBariteLateriteRisk, cbBasaltMagRisk, cbSampleTaken, cbPhotoOnly}) c.setChecked(false);
        noteBox.setText(""); decisionView.setText("Cleared. ابدأ من Structure ثم Alteration ثم Confirmation.");
    }

    private void updateLog(){
        StringBuilder sb = new StringBuilder();
        for (int i=Math.max(0, targets.size()-6); i<targets.size(); i++) {
            TargetPoint t=targets.get(i);
            sb.append(i+1).append(") ").append(t.decisionClass).append(" ").append(Math.round(t.score)).append("/100 — ").append(t.time).append("\n");
            sb.append(String.format(Locale.US,"%.6f, %.6f | %.0fm | %.0f°\n", t.lat,t.lon,t.alt,t.heading));
            sb.append(t.fingerprint).append("\n");
        }
        logView.setText(sb.toString());
    }

    private void exportCsv(){
        StringBuilder sb = new StringBuilder("time,lat,lon,alt,heading,class,score,decision,fingerprint,gpz,source_tag,photo,note\n");
        for(TargetPoint t: targets) sb.append(csv(t.time)).append(',').append(t.lat).append(',').append(t.lon).append(',').append(t.alt).append(',').append(t.heading).append(',').append(csv(t.decisionClass)).append(',').append(t.score).append(',').append(csv(t.decision)).append(',').append(csv(t.fingerprint)).append(',').append(csv(t.gpz)).append(',').append(csv(t.sourceTag)).append(',').append(csv(t.photoPath)).append(',').append(csv(t.note)).append('\n');
        writeFile("BOUH_FieldScout_V12_Targets.csv", sb.toString());
    }
    private void exportKml(){
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document><name>BOUH FieldScout V12 Targets</name>");
        for(int i=0;i<targets.size();i++){ TargetPoint t=targets.get(i); sb.append("<Placemark><name>BOUH-V12-").append(i+1).append(" ").append(escape(t.decisionClass)).append(" ").append(Math.round(t.score)).append("</name><description>").append(escape(t.decision+"\n"+t.reason+"\n"+t.fingerprint+"\n"+t.gpz+"\n"+t.sourceTag+"\nPhoto: "+t.photoPath+"\n"+t.note)).append("</description><Point><coordinates>").append(t.lon).append(',').append(t.lat).append(',').append(t.alt).append("</coordinates></Point></Placemark>"); }
        sb.append("</Document></kml>"); writeFile("BOUH_FieldScout_V12_Targets.kml", sb.toString());
    }
    private void exportJson(){
        StringBuilder sb = new StringBuilder("{\n  \"system\": \"BOUH FieldScout V12\",\n  \"truth\": \"field observation only; no spectral ratios without RAW bands\",\n  \"targets\": [\n");
        for(int i=0;i<targets.size();i++){ TargetPoint t=targets.get(i); if(i>0) sb.append(",\n"); sb.append("    {\"time\":").append(json(t.time)).append(",\"lat\":").append(t.lat).append(",\"lon\":").append(t.lon).append(",\"alt\":").append(t.alt).append(",\"heading\":").append(t.heading).append(",\"class\":").append(json(t.decisionClass)).append(",\"score\":").append(t.score).append(",\"decision\":").append(json(t.decision)).append(",\"fingerprint\":").append(json(t.fingerprint)).append(",\"gpz\":").append(json(t.gpz)).append(",\"photo\":").append(json(t.photoPath)).append(",\"note\":").append(json(t.note)).append("}"); }
        sb.append("\n  ]\n}\n"); writeFile("BOUH_FieldScout_V12_Targets.json", sb.toString());
    }
    private void exportReport(){
        StringBuilder sb = new StringBuilder();
        sb.append("BOUH FieldScout V12 Field Report\n=================================\n");
        sb.append("Truth: This report is field-observation only. Spectral ratios require raw GeoTIFF/JP2/HDF/MTL/QA/DEM.\n");
        sb.append("Rule: Structure -> Pattern -> Alteration -> Confirmation -> Decision. FeOx alone is not a target.\n\n");
        for(int i=0;i<targets.size();i++){ TargetPoint t=targets.get(i); sb.append("#").append(i+1).append(" ").append(t.decisionClass).append(" ").append(Math.round(t.score)).append("/100\n"); sb.append(t.time).append(" | ").append(String.format(Locale.US,"%.6f, %.6f | %.0fm | %.0f°\n", t.lat,t.lon,t.alt,t.heading)); sb.append(t.decision).append("\n").append(t.reason).append("\n").append(t.fingerprint).append("\n").append(t.gpz).append("\nNote: ").append(t.note).append("\nPhoto: ").append(t.photoPath).append("\n\n"); }
        writeFile("BOUH_FieldScout_V12_Report.txt", sb.toString());
    }
    private String csv(String s){ if(s==null)s=""; return '"' + s.replace("\"","'").replace("\n"," ") + '"'; }
    private String json(String s){ if(s==null)s=""; return '"' + s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n") + '"'; }
    private String escape(String s){ if(s==null)return""; return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"); }
    private void writeFile(String name, String content){
        try { File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "BOUH_FieldScout_V12"); if(!dir.exists()) dir.mkdirs(); File f = new File(dir, name); FileOutputStream out = new FileOutputStream(f); out.write(content.getBytes(StandardCharsets.UTF_8)); out.close(); decisionView.setText("Export OK: " + f.getAbsolutePath()); toast("Export OK"); }
        catch(Exception e){ decisionView.setText("Export failed: " + e.getMessage()); }
    }

    private void updateHud(){
        String loc = "GPS searching";
        if(lastLocation!=null) loc = String.format(Locale.US,"%.6f, %.6f | alt %.0fm", lastLocation.getLatitude(), lastLocation.getLongitude(), lastLocation.hasAltitude()?lastLocation.getAltitude():0);
        hud.setText("BOUH FIELDSCOUT V12 REALISTIC • Ahmed Abu Aziza\n" + "FPS " + String.format(Locale.US,"%.0f", fps) + " | RAW/BOOST " + (boostPreview?"BOOST":"RAW") + " | Z " + String.format(Locale.US,"%.1fx", zoom) + " | Torch " + (torch?"ON":"OFF") + " | Head " + String.format(Locale.US,"%.0f°", azimuth) + "\n" + loc + "\n[Field observation only — no spectral ratios from camera]");
    }

    @Override public void onLocationChanged(Location l){ lastLocation = l; updateHud(); }
    @Override public void onSensorChanged(SensorEvent e){
        if(e.sensor.getType()==Sensor.TYPE_ROTATION_VECTOR){ float[] rot=new float[9]; float[] orient=new float[3]; SensorManager.getRotationMatrixFromVector(rot, e.values); SensorManager.getOrientation(rot, orient); azimuth=(float)((Math.toDegrees(orient[0])+360)%360); }
        else if(e.sensor.getType()==Sensor.TYPE_ACCELEROMETER) gravityValues=e.values.clone();
        else if(e.sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD) magneticValues=e.values.clone();
        if(gravityValues!=null && magneticValues!=null){ float[] R=new float[9]; float[] I=new float[9]; if(SensorManager.getRotationMatrix(R,I,gravityValues,magneticValues)){ float[] o=new float[3]; SensorManager.getOrientation(R,o); azimuth=(float)((Math.toDegrees(o[0])+360)%360); } }
        updateHud();
    }
    @Override public void onAccuracyChanged(Sensor s, int a) {}
    @Override protected void onDestroy(){ super.onDestroy(); try{ if(session!=null) session.close(); if(camera!=null) camera.close(); if(camThread!=null) camThread.quitSafely(); }catch(Exception ignored){} try{ sensorManager.unregisterListener(this); locManager.removeUpdates(this);}catch(Exception ignored){} }
}
