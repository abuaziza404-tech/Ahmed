# BOUH FieldScout V12 Realistic

تطبيق Android ميداني يخدم مشروع BOUH للاستكشاف الحقلي: كاميرا RealView + GPS + بوصلة + سجل هدف + قرار Class A/B/C/Reject + توصية GPZ 7000 + تصدير CSV/KML/JSON/Report.

## الصدق الفني
- لا يحسب نسب طيفية من الكاميرا.
- الصور وGPS والملاحظات = Field Observation Only.
- التحليل الطيفي الرقمي الحقيقي يحتاج GeoTIFF/JP2/HDF/MTL/QA/DEM أو مصدر خارجي موثق.
- FeOx alone لا يكفي؛ لا Structure + لا Clay/Silica/Quartz = Reject.

## ما هو أكثر واقعية في V12
- قرار مبني على بوابات جيولوجية لا على لون الشاشة.
- Structure -> Pattern -> Alteration -> Confirmation -> Decision.
- فصل FeOx كدليل داعم فقط.
- نموذج GPZ 7000 ميداني حسب الضوضاء/الكوارتز/المغناطيسية.
- حفظ صورة المعاينة مع الهدف عند الضغط SAVE+PHOTO.
- تصدير KML للألباين/Google Earth/QGIS.
