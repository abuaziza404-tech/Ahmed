
package com.bouh.mapscout;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;
import android.text.InputType;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.ScaleBarOverlay;
import org.osmdroid.views.overlay.MapEventsOverlay;
import org.osmdroid.events.MapEventsReceiver;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity implements MapEventsReceiver {
    private MapView map;
    private FrameLayout root;
    private TextView hud, mode, sheetText, sheetTitle;
    private LinearLayout layerPanel, floatingTools, modeTools, gprBars;
    private FrameLayout bottomSheet;
    private View visualOverlay, sheetHandle;
    private LocationManager locationManager;
    private BouhLocationFilter locationFilter = new BouhLocationFilter();

    private GeoPoint gpsPoint = new GeoPoint(19.024271, 37.321768);
    private GeoPoint pinPoint = gpsPoint;
    private Marker pinMarker;
    private double altitude = 0;
    private float accuracy = -1;
    private float smoothBearing = -1;
    private String currentLayer = "Esri Satellite Overzoom";
    private boolean follow = true, powerSave = false;
    private boolean structure = false, carrier = false, trap = false, feox = false;
    private int clarity = 1, sharpness = 1, contrast = 1;
    private RemoteSensingEngine.Mode rsMode = RemoteSensingEngine.Mode.NATURAL;

    private WaypointDb db;
    private RadarEngine radar = new RadarEngine();
    private SafetyEngine safety = new SafetyEngine();
    private VeinTracker vein = new VeinTracker();

    private Button bStructure, bCarrier, bTrap, bFeox, bFollow, bPower, bClay, bIron, bProspect, bClarity, bSharp, bContrast;
    private TextView gprText, paleoText, drainageText;
    private View gprFill, paleoFill, drainageFill;
    private View gprFill, paleoFill, drainageFill;

    private final int GOLD = Color.rgb(246,216,143);
    private final int WHITE = Color.rgb(255,245,210);
    private final int PANEL = Color.argb(190, 8, 8, 8);
    private final int TOOL = Color.argb(170, 12, 12, 12);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Configuration.getInstance().setUserAgentValue("BOUH-MapScout-V22-4-Stable");
        Configuration.getInstance().setTileFileSystemCacheMaxBytes(640L * 1024L * 1024L);
        Configuration.getInstance().setTileFileSystemCacheTrimBytes(480L * 1024L * 1024L);
        db = new WaypointDb(this);
        root = new FrameLayout(this);
        setContentView(root);
        buildMap();
        buildUi();
        loadMarkers();
        requestLocation();
        dropPin(gpsPoint, false);
    }

    private void buildMap() {
        map = new MapView(this);
        map.setMultiTouchControls(true);
        map.getZoomController().setVisibility(CustomZoomButtonsController.Visibility.NEVER);
        map.setTilesScaledToDpi(true);
        map.setFlingEnabled(true);
        map.setMinZoomLevel(3.0);
        map.setMaxZoomLevel(OverzoomTileSources.DISPLAY_MAX_ZOOM);
        map.setTileSource(OverzoomTileSources.esriSatellite());
        map.getController().setZoom(18.0);
        map.getController().setCenter(gpsPoint);
        root.addView(map, new FrameLayout.LayoutParams(-1, -1));

        ScaleBarOverlay scale = new ScaleBarOverlay(map);
        scale.setCentred(false);
        scale.setScaleBarOffset(18, getResources().getDisplayMetrics().heightPixels - 250);
        map.getOverlays().add(scale);
        map.getOverlays().add(new MapEventsOverlay(this));

        visualOverlay = new View(this);
        visualOverlay.setClickable(false);
        visualOverlay.setFocusable(false);
        root.addView(visualOverlay, new FrameLayout.LayoutParams(-1, -1));

        View cross = new View(this);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(Color.TRANSPARENT);
        gd.setStroke(dp(2), Color.argb(205, 255, 224, 139));
        cross.setBackground(gd);
        root.addView(cross, new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER));
    }

    private void buildUi() {
        TextView title = label("BOUH V22.5", 14, true);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        tp.setMargins(dp(8), dp(7), dp(8), 0);
        root.addView(title, tp);

        hud = label("GPS...", 12, true);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        hp.setMargins(dp(8), dp(28), dp(8), 0);
        root.addView(hud, hp);

        mode = label("GPS Filter ON | Overzoom Z24 | Dynamic GPR | Stable", 11, true);
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        mp.setMargins(dp(8), dp(48), dp(8), 0);
        root.addView(mode, mp);

        buildFloatingToolbar();
        buildLayerPanel();
        buildBottomSheet();
        updateButtons();
    }

    private void buildFloatingToolbar() {
        floatingTools = new LinearLayout(this);
        floatingTools.setOrientation(LinearLayout.VERTICAL);
        floatingTools.setPadding(dp(4), dp(4), dp(4), dp(4));
        floatingTools.setBackground(roundBg(TOOL, Color.argb(90,246,216,143), 18));
        floatingTools.setElevation(dp(8));
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(dp(56), -2, Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        fp.setMargins(0, 0, dp(7), 0);
        root.addView(floatingTools, fp);

        floatingTools.addView(iconBtn("+", "تكبير", v -> smartZoomIn()));
        floatingTools.addView(iconBtn("−", "تصغير", v -> { map.getController().zoomOut(); updateHud(); }));
        bFollow = iconBtn("◎", "تتبع", v -> { follow = !follow; if(follow) centerGps(); updateButtons(); });
        floatingTools.addView(bFollow);
        floatingTools.addView(iconBtn("▣", "طبقات", v -> toggleLayerPanel()));
        floatingTools.addView(iconBtn("⌖", "Ultra", v -> ultraZoom()));

        modeTools = new LinearLayout(this);
        modeTools.setOrientation(LinearLayout.HORIZONTAL);
        modeTools.setPadding(dp(4), dp(4), dp(4), dp(4));
        modeTools.setBackground(roundBg(Color.argb(155,12,12,12), Color.argb(80,246,216,143), 18));
        modeTools.setElevation(dp(7));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, dp(52), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.setMargins(dp(6), dp(70), dp(6), 0);
        root.addView(modeTools, lp);

        bStructure = miniBtn("S", "بنية", v -> { structure = !structure; analyzeAndShow(); });
        bCarrier = miniBtn("Q", "Quartz/Clay", v -> { carrier = !carrier; rsMode = RemoteSensingEngine.Mode.CLAY; analyzeAndShow(); });
        bTrap = miniBtn("T", "مصيدة", v -> { trap = !trap; analyzeAndShow(); });
        bFeox = miniBtn("Fe", "Iron", v -> { feox = !feox; rsMode = RemoteSensingEngine.Mode.IRON; analyzeAndShow(); });
        bPower = miniBtn("P", "Prospecting Radar", v -> { powerSave = !powerSave; rsMode = RemoteSensingEngine.Mode.PROSPECTING_RADAR; requestLocation(); analyzeAndShow(); });
        modeTools.addView(bStructure); modeTools.addView(bCarrier); modeTools.addView(bTrap); modeTools.addView(bFeox); modeTools.addView(bPower);
    }

    private void buildLayerPanel() {
        layerPanel = new LinearLayout(this);
        layerPanel.setOrientation(LinearLayout.VERTICAL);
        layerPanel.setPadding(dp(10), dp(10), dp(10), dp(10));
        layerPanel.setBackground(roundBg(Color.argb(232,8,8,8), GOLD, 18));
        layerPanel.setElevation(dp(12));
        layerPanel.setVisibility(View.GONE);

        TextView head = label("Overzoom Layers + Styles", 15, true);
        head.setGravity(Gravity.RIGHT);
        layerPanel.addView(head);

        LinearLayout a = row();
        a.addView(btn("قمر ثابت", v -> setLayer(OverzoomTileSources.esriSatellite(), "Esri Satellite Overzoom")));
        a.addView(btn("طرق", v -> setLayer(OverzoomTileSources.osmRoads(), "OSM Roads Overzoom")));
        layerPanel.addView(a);

        LinearLayout b = row();
        b.addView(btn("تضاريس", v -> setLayer(OverzoomTileSources.openTopo(), "OpenTopo Overzoom")));
        b.addView(btn("فاتح", v -> setLayer(OverzoomTileSources.cartoLight(), "Carto Light Overzoom")));
        layerPanel.addView(b);

        LinearLayout c = row();
        bClay = btn("Quartz/Clay", v -> { rsMode = RemoteSensingEngine.Mode.CLAY; carrier = true; analyzeAndShow(); });
        bIron = btn("Iron Fe", v -> { rsMode = RemoteSensingEngine.Mode.IRON; feox = true; analyzeAndShow(); });
        c.addView(bClay); c.addView(bIron);
        layerPanel.addView(c);

        bProspect = btn("Prospecting Radar", v -> { rsMode = RemoteSensingEngine.Mode.PROSPECTING_RADAR; analyzeAndShow(); });
        layerPanel.addView(bProspect, new LinearLayout.LayoutParams(-1, dp(50)));

        LinearLayout q = row();
        bClarity = btn("وضوح 1", v -> { clarity = (clarity + 1) % 5; applyVisual(); });
        bSharp = btn("حدة 1", v -> { sharpness = (sharpness + 1) % 5; applyVisual(); });
        q.addView(bClarity); q.addView(bSharp);
        layerPanel.addView(q);

        bContrast = btn("تباين 1", v -> { contrast = (contrast + 1) % 5; applyVisual(); });
        layerPanel.addView(bContrast, new LinearLayout.LayoutParams(-1, dp(50)));

        final EditText custom = new EditText(this);
        custom.setHint("XYZ Overzoom: https://.../{z}/{x}/{y}.png");
        custom.setTextColor(Color.WHITE);
        custom.setHintTextColor(Color.rgb(210,190,140));
        custom.setSingleLine(false);
        custom.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        custom.setBackground(roundBg(Color.rgb(25,25,25), Color.argb(120,246,216,143), 12));
        custom.setPadding(dp(8), dp(8), dp(8), dp(8));
        layerPanel.addView(custom, new LinearLayout.LayoutParams(-1, dp(56)));

        LinearLayout d = row();
        d.addView(btn("ربط", v -> {
            String url = custom.getText().toString().trim();
            if(!url.contains("{z}") || !url.contains("{x}") || !url.contains("{y}")) {
                toast("الرابط يجب أن يحتوي {z}/{x}/{y}");
                return;
            }
            setLayer(OverzoomTileSources.customOverzoom("Cloud Infinite Overzoom", url, 17, 24), "Cloud Infinite Overzoom");
        }));
        d.addView(btn("إغلاق", v -> toggleLayerPanel()));
        layerPanel.addView(d);

        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, dp(420), Gravity.TOP);
        pp.setMargins(dp(8), dp(72), dp(70), 0);
        root.addView(layerPanel, pp);
    }

    private void buildBottomSheet() {
        bottomSheet = new FrameLayout(this);
        bottomSheet.setBackground(roundBg(PANEL, Color.argb(120,246,216,143), 22));
        bottomSheet.setElevation(dp(14));
        bottomSheet.setPadding(dp(10), dp(4), dp(10), dp(10));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        View sheetHandle = new View(this);
        sheetHandle.setBackground(roundBg(Color.argb(180,246,216,143), Color.TRANSPARENT, 8));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(dp(54), dp(5));
        hp.gravity = Gravity.CENTER_HORIZONTAL;
        hp.setMargins(0, dp(2), 0, dp(6));
        content.addView(sheetHandle, hp);

        sheetTitle = label("Radar Pin Report", 13, true);
        sheetTitle.setGravity(Gravity.RIGHT);
        content.addView(sheetTitle);

        gprBars = new LinearLayout(this);
        gprBars.setOrientation(LinearLayout.VERTICAL);
        gprText = addBar(gprBars, "GPR");
        paleoText = addBar(gprBars, "Paleo");
        drainageText = addBar(gprBars, "Drainage");
        content.addView(gprBars);

        ScrollView scroll = new ScrollView(this);
        sheetText = label("", 12, false);
        sheetText.setGravity(Gravity.RIGHT);
        sheetText.setPadding(dp(4), dp(4), dp(4), dp(16));
        scroll.addView(sheetText);
        content.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout actions = row();
        actions.addView(btn("حفظ", v -> saveWaypoint()));
        actions.addView(btn("KML", v -> exportFile("kml")));
        actions.addView(btn("CSV", v -> exportFile("csv")));
        content.addView(actions);

        bottomSheet.addView(content, new FrameLayout.LayoutParams(-1, -1));
        root.addView(bottomSheet);
        setSheetHeight(dp(215));

        sheetHandle.setOnTouchListener(new View.OnTouchListener() {
            float downY; int startH;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if(e.getAction() == MotionEvent.ACTION_DOWN) {
                    downY = e.getRawY();
                    startH = bottomSheet.getLayoutParams().height;
                    return true;
                } else if(e.getAction() == MotionEvent.ACTION_MOVE) {
                    int newH = (int)(startH + (downY - e.getRawY()));
                    setSheetHeight(Math.max(dp(96), Math.min(newH, getResources().getDisplayMetrics().heightPixels - dp(120))));
                    return true;
                } else if(e.getAction() == MotionEvent.ACTION_UP) {
                    int h = bottomSheet.getLayoutParams().height;
                    int screen = getResources().getDisplayMetrics().heightPixels;
                    if(h > screen * 0.52) expandSheet();
                    else if(h < screen * 0.22) collapseSheet();
                    else midSheet();
                    return true;
                }
                return false;
            }
        });
    }

    private TextView addBar(LinearLayout parent, String label) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = label(label + " 0%", 10, true);
        row.addView(t, new LinearLayout.LayoutParams(dp(82), dp(20)));

        FrameLayout track = new FrameLayout(this);
        track.setBackground(roundBg(Color.argb(120,30,30,30), Color.argb(50,246,216,143), 7));
        View fill = new View(this);
        fill.setBackground(roundBg(Color.argb(210,246,216,143), Color.TRANSPARENT, 7));
        track.addView(fill, new FrameLayout.LayoutParams(dp(1), dp(12), Gravity.LEFT | Gravity.CENTER_VERTICAL));
        row.addView(track, new LinearLayout.LayoutParams(0, dp(20), 1));
        parent.addView(row);

        if(label.equals("GPR")) gprFill = fill;
        if(label.equals("Paleo")) paleoFill = fill;
        if(label.equals("Drainage")) drainageFill = fill;
        return t;
    }

    private void setBar(TextView text, View fill, String name, int percent) {
        text.setText(name + " " + percent + "%");
        int maxW = Math.max(dp(2), getResources().getDisplayMetrics().widthPixels - dp(130));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.max(dp(2), maxW * percent / 100), dp(12), Gravity.LEFT | Gravity.CENTER_VERTICAL);
        fill.setLayoutParams(lp);
    }

    private void setSheetHeight(int h) {
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, h, Gravity.BOTTOM);
        sp.setMargins(dp(8), 0, dp(8), dp(8));
        bottomSheet.setLayoutParams(sp);
    }

    private void collapseSheet() { setSheetHeight(dp(96)); }
    private void midSheet() { setSheetHeight(dp(215)); }
    private void expandSheet() { setSheetHeight(getResources().getDisplayMetrics().heightPixels - dp(128)); }

    private void setLayer(OnlineTileSourceBase source, String name) {
        map.setTileSource(source);
        map.setMaxZoomLevel(OverzoomTileSources.DISPLAY_MAX_ZOOM);
        currentLayer = name;
        toggleLayerPanel();
        updateHud();
        toast("Infinite Overzoom: " + name);
    }

    private void toggleLayerPanel() {
        layerPanel.setVisibility(layerPanel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    private Button iconBtn(String text, String desc, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setContentDescription(desc);
        b.setTextSize(18);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setPadding(0,0,0,0);
        b.setBackground(roundBg(Color.argb(180,18,18,18), Color.argb(75,246,216,143), 16));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(46), dp(46));
        p.setMargins(dp(1), dp(3), dp(1), dp(3));
        b.setLayoutParams(p);
        return b;
    }

    private Button miniBtn(String text, String desc, View.OnClickListener l) {
        Button b = iconBtn(text, desc, l);
        b.setTextSize(12);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(44), dp(44));
        p.setMargins(dp(3), dp(0), dp(3), dp(0));
        b.setLayoutParams(p);
        return b;
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setPadding(1,1,1,1);
        b.setBackground(roundBg(Color.argb(205,16,16,16), Color.argb(120,246,216,143), 13));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(50), 1);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(p);
        return b;
    }

    private TextView label(String t, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(WHITE);
        v.setTextSize(size);
        v.setShadowLayer(4, 0, 1, Color.BLACK);
        if(bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private GradientDrawable roundBg(int fill, int stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radius));
        if(stroke != Color.TRANSPARENT) g.setStroke(dp(1), stroke);
        return g;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public boolean singleTapConfirmedHelper(GeoPoint p) {
        dropPin(p, true);
        return true;
    }

    @Override public boolean longPressHelper(GeoPoint p) {
        dropPin(p, true);
        return true;
    }

    private void dropPin(GeoPoint p, boolean center) {
        pinPoint = p;
        if(pinMarker == null) {
            pinMarker = new Marker(map);
            pinMarker.setTitle("BOUH Pin");
            pinMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            map.getOverlays().add(pinMarker);
        }
        pinMarker.setPosition(p);
        if(center) map.getController().animateTo(p);
        vein.push(p);
        map.invalidate();
        analyzeAndShow();
        midSheet();
    }

    private void analyzeAndShow() {
        RadarEngine.Report rr = radar.analyze(pinPoint.getLatitude(), pinPoint.getLongitude(), structure, carrier, trap, feox);
        int score = (structure?42:0) + (carrier?34:0) + (trap?14:0) + (feox?5:0) + (rr.paleochannel > 0.62 ? 5 : 0);
        String decision = (!structure || !carrier) ? "REJECT / HOLD" : score >= 82 ? "CLASS A" : score >= 62 ? "CLASS B" : "CLASS C";
        sheetTitle.setText(decision + " | Score " + score);

        setBar(gprText, gprFill, "GPR", rr.gprBar);
        setBar(paleoText, paleoFill, "Paleo", rr.paleoBar);
        setBar(drainageText, drainageFill, "Drain", rr.drainageBar);

        sheetText.setText(
                "Pin: " + String.format(Locale.US, "%.6f, %.6f", pinPoint.getLatitude(), pinPoint.getLongitude()) + "\n" +
                "Scale: " + String.format(Locale.US, "%.2f", groundMpx()) + " m/px | Z " + String.format(Locale.US, "%.1f", map.getZoomLevelDouble()) + "\n" +
                rr.text + "\n\n" +
                safety.warning(rr) + "\n" +
                vein.report() + "\n\n" +
                "Layer: " + currentLayer + "\n" +
                "Mode: " + rsMode + "\n" +
                "RS: " + RemoteSensingEngine.formula(rsMode) + "\n\n" +
                "GPS filter: لا تحديث دون حركة ≥2m، مع تنعيم للموقع والاتجاه.\n" +
                "Truth: Infinite Overzoom يثبت الطبقة بصرياً ولا يصنع دقة حقيقية أعلى."
        );
        updateButtons();
        updateHud();
    }

    private double groundMpx() {
        GeoPoint c = (GeoPoint) map.getMapCenter();
        return 156543.03392 * Math.cos(Math.toRadians(c.getLatitude())) / Math.pow(2, map.getZoomLevelDouble());
    }

    private void smartZoomIn() {
        map.getController().zoomIn();
        updateHud();
    }

    private void ultraZoom() {
        map.getController().animateTo((GeoPoint)map.getMapCenter(), OverzoomTileSources.DISPLAY_MAX_ZOOM, 450L);
        analyzeAndShow();
    }

    private void applyVisual() {
        int alpha = Math.min(145, contrast * 16 + clarity * 9);
        int color = Color.argb(alpha, 18, 12, 0);
        if(rsMode == RemoteSensingEngine.Mode.CLAY) color = Color.argb(Math.max(alpha, 65), 72, 38, 105);
        if(rsMode == RemoteSensingEngine.Mode.IRON) color = Color.argb(Math.max(alpha, 70), 130, 44, 8);
        if(rsMode == RemoteSensingEngine.Mode.PROSPECTING_RADAR) color = Color.argb(Math.max(alpha, 80), 16, 72, 55);
        visualOverlay.setBackgroundColor(color);
        // Keep MapView geometry stable; visual sharpness is represented by labels/overlay only.
        // Scaling MapView can shift touch coordinates and overlays on some Android devices.
        map.setScaleX(1.0f);
        map.setScaleY(1.0f);
        if(bClarity != null) bClarity.setText("وضوح " + clarity);
        if(bSharp != null) bSharp.setText("حدة " + sharpness);
        if(bContrast != null) bContrast.setText("تباين " + contrast);
    }

    private void updateButtons() {
        setOn(bStructure, structure);
        setOn(bCarrier, carrier || rsMode == RemoteSensingEngine.Mode.CLAY);
        setOn(bTrap, trap);
        setOn(bFeox, feox || rsMode == RemoteSensingEngine.Mode.IRON);
        setOn(bFollow, follow);
        setOn(bPower, powerSave || rsMode == RemoteSensingEngine.Mode.PROSPECTING_RADAR);
        setOn(bClay, rsMode == RemoteSensingEngine.Mode.CLAY);
        setOn(bIron, rsMode == RemoteSensingEngine.Mode.IRON);
        setOn(bProspect, rsMode == RemoteSensingEngine.Mode.PROSPECTING_RADAR);
        applyVisual();
    }

    private void setOn(Button b, boolean on) {
        if(b == null) return;
        b.setBackground(roundBg(on ? Color.argb(220,122,92,24) : Color.argb(180,18,18,18), Color.argb(110,246,216,143), 16));
    }

    private void centerGps() {
        map.getController().animateTo(gpsPoint);
        updateHud();
    }

    private void saveWaypoint() {
        RadarEngine.Report rr = radar.analyze(pinPoint.getLatitude(), pinPoint.getLongitude(), structure, carrier, trap, feox);
        Waypoint w = new Waypoint();
        w.time = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(new Date());
        w.name = "BOUH Pin";
        w.lat = pinPoint.getLatitude();
        w.lon = pinPoint.getLongitude();
        w.alt = altitude;
        w.acc = accuracy;
        w.zoom = map.getZoomLevelDouble();
        w.layer = currentLayer + " / " + rsMode;
        w.structure = structure; w.carrier = carrier; w.trap = trap; w.feox = feox;
        w.score = (structure?42:0) + (carrier?34:0) + (trap?14:0) + (feox?5:0) + (rr.paleochannel > 0.62 ? 5 : 0);
        w.decision = (!structure || !carrier) ? "REJECT/HOLD" : w.score >= 82 ? "CLASS A" : w.score >= 62 ? "CLASS B" : "CLASS C";
        w.report = rr.text + " | " + safety.warning(rr) + " | " + vein.report();
        db.insert(w);
        addMarker(w);
        toast("تم حفظ: " + w.decision);
    }

    private void loadMarkers() {
        for(Waypoint w: db.all()) addMarker(w);
    }

    private void addMarker(Waypoint w) {
        Marker m = new Marker(map);
        m.setPosition(new GeoPoint(w.lat, w.lon));
        m.setTitle(w.decision + " | " + w.score);
        m.setSubDescription(w.report);
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        map.getOverlays().add(m);
        map.invalidate();
    }

    private File outDir() {
        File d = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "BOUH_MapScout_V22_4");
        if(!d.exists()) d.mkdirs();
        return d;
    }

    private void exportFile(String type) {
        try {
            File f = new File(outDir(), type.equals("kml") ? "BOUH_MapScout_V22_4_waypoints.kml" : "BOUH_MapScout_V22_4_waypoints.csv");
            write(f, type.equals("kml") ? db.kml() : db.csv());
            toast(type.toUpperCase(Locale.US) + ": " + f.getAbsolutePath());
        } catch(Exception e) { toast("Export error: " + e.getMessage()); }
    }

    private void write(File f, String s) throws Exception {
        PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f), "UTF-8"));
        pw.print(s);
        pw.close();
    }

    private void requestLocation() {
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
        if(android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 77);
            return;
        }
        startGpsUpdates();
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(code, perms, grants);
        startGpsUpdates();
    }

    private void startGpsUpdates() {
        try {
            if(android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
            if(locationManager == null) locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
            try { locationManager.removeUpdates(listener); } catch(Exception ignored) {}
            long ms = powerSave ? 12000 : 1500;
            float meters = powerSave ? 8f : 2f;
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, ms, meters, listener);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, ms * 2, meters, listener);
            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location loc = gps != null ? gps : net;
            if(loc != null) onLoc(loc);
        } catch(Exception e) { toast("GPS: " + e.getMessage()); }
    }

    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location location) { onLoc(location); }
        @Override public void onProviderEnabled(String provider) {}
        @Override public void onProviderDisabled(String provider) {}
    };

    private void onLoc(Location loc) {
        if(!locationFilter.accept(loc)) {
            updateHud();
            return;
        }
        gpsPoint = locationFilter.update(loc);
        accuracy = locationFilter.getAccuracy();
        smoothBearing = locationFilter.getBearing();
        altitude = loc.hasAltitude() ? loc.getAltitude() : altitude;
        if(follow) map.getController().animateTo(gpsPoint);
        updateHud();
    }

    private void updateHud() {
        GeoPoint c = (GeoPoint) map.getMapCenter();
        hud.setText(String.format(Locale.US, "%.6f, %.6f | alt %.0fm | acc %s | Z %.1f | %.2fm/px",
                c.getLatitude(), c.getLongitude(), altitude,
                accuracy < 0 ? "?" : String.format(Locale.US, "%.0fm", accuracy),
                map.getZoomLevelDouble(), groundMpx()));
        mode.setText((powerSave ? "POWER" : "LIVE") + " | " + currentLayer + " | " + rsMode + " | bearing " + (smoothBearing < 0 ? "?" : String.format(Locale.US, "%.0f°", smoothBearing)));
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override protected void onResume() { super.onResume(); map.onResume(); }
    @Override protected void onPause() { map.onPause(); super.onPause(); }
}
