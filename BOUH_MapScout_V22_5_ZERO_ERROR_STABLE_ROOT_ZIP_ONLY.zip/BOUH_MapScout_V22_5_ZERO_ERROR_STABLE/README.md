# BOUH MapScout V22.5 Zero-Error Stable

إصلاح مباشر لفشل Build Debug APK في V22.4:
- إضافة الحقول المفقودة:
  gprFill
  paleoFill
  drainageFill
- نقل سحب البطاقة السفلية إلى المقبض فقط حتى لا يمنع أزرار حفظ/KML/CSV.
- تثبيت MapView بدون ScaleX/ScaleY لتجنب انحراف اللمس والإحداثيات.
- إبقاء كل ميزات V22.4:
  GPS jitter filter
  Infinite Overzoom Z24
  Native max Z17 parent tile fallback
  Floating UI
  Dynamic GPR/Paleo/Drainage bars
  Fe/Q/P modes
  Pin Drop
  SQLite
  KML/CSV
