
package com.bouh.mapscout;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.view.Gravity;
import android.view.View;
import android.view.MotionEvent;
import android.widget.*;
import android.text.InputType;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.ScaleBarOverlay;
import org.osmdroid.views.overlay.MapEventsOverlay;
import org.osmdroid.events.ScrollEvent;
import org.osmdroid.events.ZoomEvent;
import org.osmdroid.events.MapListener;
import org.osmdroid.events.MapEventsReceiver;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements MapEventsReceiver {
    private MapView map;
    private FrameLayout root;
    private TextView hud;
    private TextView info;
    private TextView title;
    private TextView gprText;
    private TextView paleoText;
    private TextView drainageText;
    private View gprFill;
    private View paleoFill;
    private View drainageFill;
    private LinearLayout layerPanel;
    private View overlay;
    private RadarCircleView radarCircle;
    private LocationManager locationManager;
    private final BouhLocationFilter filter = new BouhLocationFilter();

    private GeoPoint gpsPoint = new GeoPoint(19.024271, 37.321768);
    private GeoPoint pinPoint = gpsPoint;
    private Marker pinMarker;
    private double altitude = 0.0;
    private float accuracy = -1f;
    private boolean follow = false;
    private boolean structure = false;
    private boolean carrier = false;
    private boolean trap = false;
    private boolean feox = false;
    private String currentLayer = "Esri Satellite Overzoom";
    private RemoteSensingEngine.Mode mode = RemoteSensingEngine.Mode.NATURAL;

    private WaypointDb db;
    private final RadarEngine radar = new RadarEngine();
    private final SentinelDataGrid dataGrid = new SentinelDataGrid();

    private final int GOLD = Color.rgb(246,216,143);
    private final int WHITE = Color.rgb(255,245,210);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Configuration.getInstance().setUserAgentValue("BOUH-MapScout-V26-1-Stable");
        Configuration.getInstance().setTileFileSystemCacheMaxBytes(512L * 1024L * 1024L);
        Configuration.getInstance().setTileFileSystemCacheTrimBytes(380L * 1024L * 1024L);
        db = new WaypointDb(this);
        dataGrid.load(this);
        root = new FrameLayout(this);
        setContentView(root);
        buildMap();
        buildUi();
        loadMarkers();
        requestLocation();
        dropPin(gpsPoint, false);
    }

    private void buildMap() {
        map = new MapView(this);
        map.setMultiTouchControls(true);
        map.getZoomController().setVisibility(CustomZoomButtonsController.Visibility.NEVER);
        map.setTilesScaledToDpi(true);
        map.setFlingEnabled(true);
        map.setMinZoomLevel(3.0);
        map.setMaxZoomLevel((double) OverzoomTileSources.DISPLAY_MAX_ZOOM);
        map.setTileSource(OverzoomTileSources.esriSatellite());
        map.getController().setZoom(18.0);
        map.getController().setCenter(gpsPoint);
        root.addView(map, new FrameLayout.LayoutParams(-1, -1));

        ScaleBarOverlay scale = new ScaleBarOverlay(map);
        scale.setCentred(false);
        scale.setScaleBarOffset(18, getResources().getDisplayMetrics().heightPixels - 240);
        map.getOverlays().add(scale);
        map.getOverlays().add(new MapEventsOverlay(this));
        map.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
                follow = false;
                updateHud();
            }
            return false;
        });
        map.addMapListener(new MapListener() {
            @Override public boolean onScroll(ScrollEvent event) {
                follow = false;
                analyzeCenter();
                return false;
            }
            @Override public boolean onZoom(ZoomEvent event) {
                analyzeCenter();
                return false;
            }
        });

        overlay = new View(this);
        overlay.setClickable(false);
        overlay.setFocusable(false);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        radarCircle = new RadarCircleView(this);
        radarCircle.setClickable(false);
        radarCircle.setFocusable(false);
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(dp(170), dp(170), Gravity.CENTER);
        root.addView(radarCircle, rp);
    }

    private void buildUi() {
        title = label("BOUH V26.1 STABLE", 14, true);
        FrameLayout.LayoutParams titleParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        titleParams.setMargins(dp(8), dp(6), dp(8), 0);
        root.addView(title, titleParams);

        hud = label("", 12, true);
        FrameLayout.LayoutParams hudParams = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        hudParams.setMargins(dp(8), dp(28), dp(8), 0);
        root.addView(hud, hudParams);

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setBackground(bg(Color.argb(155, 10, 10, 10), Color.argb(90, 246, 216, 143), 18));
        right.setPadding(dp(4), dp(4), dp(4), dp(4));
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(dp(56), -2, Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        rp.setMargins(0, 0, dp(7), 0);
        root.addView(right, rp);
        right.addView(icon("+", v -> { map.getController().zoomIn(); updateHud(); }));
        right.addView(icon("−", v -> { map.getController().zoomOut(); updateHud(); }));
        right.addView(icon("GPS", v -> { follow = !follow; if (follow) map.getController().animateTo(gpsPoint); updateHud(); toast(follow ? "تتبع GPS مفعل" : "تحريك حر مفعل"); }));
        right.addView(icon("▣", v -> toggleLayerPanel()));
        right.addView(icon("5m", v -> { map.getController().setZoom((double) OverzoomTileSources.DISPLAY_MAX_ZOOM); analyzeCenter(); toast("زوم رقمي Z" + OverzoomTileSources.DISPLAY_MAX_ZOOM + " (بصري فقط)"); }));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER);
        top.setBackground(bg(Color.argb(145, 10, 10, 10), Color.argb(80, 246, 216, 143), 18));
        top.setPadding(dp(4), dp(4), dp(4), dp(4));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, dp(52), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        tp.setMargins(dp(6), dp(62), dp(6), 0);
        root.addView(top, tp);
        top.addView(small("بنية", v -> { structure = !structure; analyzeCenter(); }));
        top.addView(small("كوارتز", v -> { carrier = !carrier; mode = RemoteSensingEngine.Mode.CLAY; analyzeCenter(); }));
        top.addView(small("مصيدة", v -> { trap = !trap; analyzeCenter(); }));
        top.addView(small("حديد", v -> { feox = !feox; mode = RemoteSensingEngine.Mode.IRON; analyzeCenter(); }));
        top.addView(small("رادار", v -> { mode = RemoteSensingEngine.Mode.PROSPECTING; analyzeCenter(); }));

        buildLayerPanel();
        buildInfoPanel();
    }

    private void buildInfoPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(8), dp(10), dp(8));
        panel.setBackground(bg(Color.argb(190, 8, 8, 8), Color.argb(120, 246, 216, 143), 22));
        panel.setElevation(dp(10));

        info = label("", 12, false);
        panel.addView(info, new LinearLayout.LayoutParams(-1, dp(128)));

        gprText = addBar(panel, "سطحي");
        paleoText = addBar(panel, "عروق");
        drainageText = addBar(panel, "وديان");

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(button("حفظ", v -> saveWaypoint()));
        row.addView(button("KML", v -> export("kml")));
        row.addView(button("CSV", v -> export("csv")));
        panel.addView(row);

        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, dp(258), Gravity.BOTTOM);
        pp.setMargins(dp(8), 0, dp(8), dp(8));
        root.addView(panel, pp);
    }

    private TextView addBar(LinearLayout parent, String name) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView text = label(name + " 0%", 10, true);
        row.addView(text, new LinearLayout.LayoutParams(dp(78), dp(22)));

        FrameLayout track = new FrameLayout(this);
        track.setBackground(bg(Color.argb(120, 30, 30, 30), Color.argb(50, 246, 216, 143), 7));
        View fill = new View(this);
        fill.setBackground(bg(Color.argb(210, 246, 216, 143), Color.TRANSPARENT, 7));
        track.addView(fill, new FrameLayout.LayoutParams(dp(2), dp(12), Gravity.LEFT | Gravity.CENTER_VERTICAL));
        row.addView(track, new LinearLayout.LayoutParams(0, dp(22), 1));
        parent.addView(row);

        if ("GPR".equals(name)) gprFill = fill;
        if ("Paleo".equals(name)) paleoFill = fill;
        if ("Drain".equals(name)) drainageFill = fill;
        return text;
    }

    private void setBar(TextView text, View fill, String name, int value) {
        int width = Math.max(dp(2), (getResources().getDisplayMetrics().widthPixels - dp(130)) * value / 100);
        text.setText(name + " " + value + "%");
        fill.setLayoutParams(new FrameLayout.LayoutParams(width, dp(12), Gravity.LEFT | Gravity.CENTER_VERTICAL));
    }

    private void buildLayerPanel() {
        layerPanel = new LinearLayout(this);
        layerPanel.setOrientation(LinearLayout.VERTICAL);
        layerPanel.setPadding(dp(10), dp(10), dp(10), dp(10));
        layerPanel.setBackground(bg(Color.argb(230, 8, 8, 8), GOLD, 18));
        layerPanel.setVisibility(View.GONE);
        layerPanel.setElevation(dp(12));

        layerPanel.addView(button("قمر Overzoom", v -> setLayer(OverzoomTileSources.esriSatellite(), "Esri Satellite Overzoom")));
        layerPanel.addView(button("طرق Overzoom", v -> setLayer(OverzoomTileSources.osmRoads(), "OSM Roads Overzoom")));
        layerPanel.addView(button("تضاريس Overzoom", v -> setLayer(OverzoomTileSources.openTopo(), "OpenTopo Overzoom")));

        EditText custom = new EditText(this);
        custom.setHint("XYZ: https://.../{z}/{x}/{y}.png");
        custom.setTextColor(Color.WHITE);
        custom.setHintTextColor(Color.rgb(210,190,140));
        custom.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        layerPanel.addView(custom, new LinearLayout.LayoutParams(-1, dp(58)));

        layerPanel.addView(button("ربط XYZ", v -> {
            String u = custom.getText().toString().trim();
            if (u.contains("{z}") && u.contains("{x}") && u.contains("{y}")) {
                setLayer(OverzoomTileSources.custom("Cloud Overzoom", u), "Cloud Overzoom");
            } else {
                toast("الرابط يجب أن يحتوي {z}/{x}/{y}");
            }
        }));
        layerPanel.addView(button("إغلاق", v -> toggleLayerPanel()));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, dp(330), Gravity.TOP);
        lp.setMargins(dp(8), dp(70), dp(70), 0);
        root.addView(layerPanel, lp);
    }

    private void setLayer(OnlineTileSourceBase source, String name) {
        map.setTileSource(source);
        map.setMaxZoomLevel((double) OverzoomTileSources.DISPLAY_MAX_ZOOM);
        currentLayer = name;
        layerPanel.setVisibility(View.GONE);
        updateHud();
    }

    private void toggleLayerPanel() {
        layerPanel.setVisibility(layerPanel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    @Override public boolean singleTapConfirmedHelper(GeoPoint p) {
        dropPin(p, true);
        return true;
    }

    @Override public boolean longPressHelper(GeoPoint p) {
        dropPin(p, true);
        return true;
    }

    private void safeInfo(String message) {
        if (info != null) info.setText(message);
        updateHud();
    }

    private void analyzeCenter() {
        if (map == null || info == null || gprText == null || veinText == null || wadiText == null) return;
        GeoPoint center;
        try {
            center = (GeoPoint) map.getMapCenter();
        } catch (Exception e) {
            safeInfo("الخريطة لم تجهز بعد — انتظر ثواني.");
            return;
        }
        if (center == null) return;
        pinPoint = center;
        if (pinMarker != null) {
            pinMarker.setPosition(center);
            map.invalidate();
        }
        analyze();
    }

    private void dropPin(GeoPoint p, boolean center) {
        follow = false;
        pinPoint = p;
        if (pinMarker == null) {
            pinMarker = new Marker(map);
            pinMarker.setTitle("BOUH Pin");
            pinMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            map.getOverlays().add(pinMarker);
        }
        pinMarker.setPosition(p);
        if (center) map.getController().animateTo(p);
        map.invalidate();
        analyze();
    }

    private void analyze() {
        SentinelDataGrid.Result result = dataGrid.nearest(pinPoint.getLatitude(), pinPoint.getLongitude(), structure, carrier, trap, feox);

        setBar(gprText, gprFill, "سطحي", result.surfacePriority);
        setBar(paleoText, paleoFill, "عروق", result.veinPriority);
        setBar(drainageText, drainageFill, "وديان", result.wadiPriority);

        info.setText(result.report + "\n"
                + String.format(Locale.US, "%.6f, %.6f", pinPoint.getLatitude(), pinPoint.getLongitude()) + "\n"
                + RemoteSensingEngine.label(mode) + " | الرادار يحلل مركز الدائرة مباشرة");
        applyOverlay();
        updateHud();
    }

    private void applyOverlay() {
        int color = Color.argb(55, 18, 12, 0);
        if (mode == RemoteSensingEngine.Mode.CLAY) color = Color.argb(80, 72, 38, 105);
        if (mode == RemoteSensingEngine.Mode.IRON) color = Color.argb(90, 130, 44, 8);
        if (mode == RemoteSensingEngine.Mode.PROSPECTING) color = Color.argb(80, 16, 72, 55);
        overlay.setBackgroundColor(color);
        if (radarCircle != null) {
            int m = 0;
            if (mode == RemoteSensingEngine.Mode.CLAY) m = 1;
            if (mode == RemoteSensingEngine.Mode.IRON) m = 2;
            if (mode == RemoteSensingEngine.Mode.PROSPECTING) m = 3;
            radarCircle.setRadarMode(m);
        }
    }

    private void saveWaypoint() {
        SentinelDataGrid.Result result = dataGrid.nearest(pinPoint.getLatitude(), pinPoint.getLongitude(), structure, carrier, trap, feox);
        Waypoint w = new Waypoint();
        w.time = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(new Date());
        w.lat = pinPoint.getLatitude();
        w.lon = pinPoint.getLongitude();
        w.alt = altitude;
        w.zoom = map.getZoomLevelDouble();
        w.layer = currentLayer + " / " + mode;
        w.score = (int)Math.round(result.score);
        w.decision = result.decision == null ? "OUTSIDE DATA" : result.decision;
        w.report = result.report;
        db.insert(w);
        addMarker(w);
        toast("تم حفظ الهدف");
    }

    private void loadMarkers() {
        for (Waypoint w : db.all()) addMarker(w);
    }

    private void addMarker(Waypoint w) {
        Marker m = new Marker(map);
        m.setPosition(new GeoPoint(w.lat, w.lon));
        m.setTitle(w.decision + " | " + w.score);
        m.setSubDescription(w.report);
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        map.getOverlays().add(m);
        map.invalidate();
    }

    private void export(String type) {
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "BOUH_MapScout_V26");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "kml".equals(type) ? "targets.kml" : "targets.csv");
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
            pw.print("kml".equals(type) ? db.kml() : db.csv());
            pw.close();
            toast(file.getAbsolutePath());
        } catch (Exception e) {
            toast("Export error: " + e.getMessage());
        }
    }

    private void requestLocation() {
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 77);
            return;
        }
        startGps();
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        startGps();
    }

    private void startGps() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
            try { locationManager.removeUpdates(listener); } catch(Exception ignored) {}
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500, 2f, listener);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000, 2f, listener);
            Location last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null) last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null) onLocation(last);
        } catch (Exception e) {
            toast("GPS: " + e.getMessage());
        }
    }

    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location location) { onLocation(location); }
        @Override public void onProviderEnabled(String provider) {}
        @Override public void onProviderDisabled(String provider) {}
    };

    private void onLocation(Location location) {
        if (!filter.accept(location)) {
            updateHud();
            return;
        }
        gpsPoint = filter.update(location);
        accuracy = filter.getAccuracy();
        altitude = location.hasAltitude() ? location.getAltitude() : altitude;
        if (follow) {
            map.getController().animateTo(gpsPoint);
            analyzeCenter();
        } else {
            updateHud();
        }
    }

    private void updateHud() {
        GeoPoint center = (GeoPoint)map.getMapCenter();
        double mpx = 156543.03392 * Math.cos(Math.toRadians(center.getLatitude())) / Math.pow(2, map.getZoomLevelDouble());
        hud.setText(String.format(Locale.US, "%.6f, %.6f | Z %.1f | %.2fm/px | acc %s | %s",
                center.getLatitude(), center.getLongitude(), map.getZoomLevelDouble(), mpx,
                accuracy < 0 ? "?" : String.format(Locale.US, "%.0fm", accuracy),
                follow ? "GPS ON" : "FREE"));
    }

    private Button icon(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(WHITE);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setPadding(0,0,0,0);
        b.setBackground(bg(Color.argb(170,18,18,18), Color.argb(80,246,216,143), 16));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(46), dp(46));
        p.setMargins(dp(1), dp(3), dp(1), dp(3));
        b.setLayoutParams(p);
        return b;
    }

    private Button small(String text, View.OnClickListener l) {
        Button b = icon(text, l);
        b.setTextSize(12);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(62), dp(44)));
        return b;
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(WHITE);
        b.setTextSize(11);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackground(bg(Color.argb(190,16,16,16), Color.argb(100,246,216,143), 13));
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, dp(48), 1));
        return b;
    }

    private TextView label(String text, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(WHITE);
        v.setTextSize(size);
        v.setShadowLayer(4, 0, 1, Color.BLACK);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private GradientDrawable bg(int fill, int stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) g.setStroke(dp(1), stroke);
        return g;
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    @Override protected void onResume() {
        super.onResume();
        map.onResume();
    }

    @Override protected void onPause() {
        map.onPause();
        super.onPause();
    }
}
