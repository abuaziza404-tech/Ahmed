
package com.bouh.mapscout;

public class RemoteSensingEngine {
    public enum Mode { NATURAL, CLAY, IRON, PROSPECTING }

    public static String label(Mode m) {
        if (m == Mode.CLAY) return "Quartz/Clay mode: حامل كوارتز/طين";
        if (m == Mode.IRON) return "Iron Oxide mode: أكاسيد حديد";
        if (m == Mode.PROSPECTING) return "Live Radar mode: مسح مركز الدائرة";
        return "Natural data mode";
    }
}
