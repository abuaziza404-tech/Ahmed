
package com.bouh.mapscout;

import android.content.Context;
import android.graphics.*;
import android.view.View;

public class RadarCircleView extends View {
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sweep = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float angle = 0f;
    private int mode = 0;

    public RadarCircleView(Context c) {
        super(c);
        setWillNotDraw(false);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(3f);
        ring.setColor(Color.argb(210, 246, 216, 143));
        sweep.setStyle(Paint.Style.STROKE);
        sweep.setStrokeWidth(7f);
        text.setColor(Color.rgb(255, 245, 210));
        text.setTextSize(24f);
        text.setFakeBoldText(true);
        setAlpha(0.92f);
    }

    public void setRadarMode(int m) {
        mode = m;
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w = getWidth();
        int h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        float r = Math.min(w, h) * 0.44f;

        int base = Color.argb(220, 246, 216, 143);
        if (mode == 1) base = Color.argb(220, 185, 135, 255);       // clay/quartz
        if (mode == 2) base = Color.argb(230, 255, 135, 70);        // iron
        if (mode == 3) base = Color.argb(230, 85, 255, 190);        // radar
        ring.setColor(base);

        c.drawCircle(cx, cy, r, ring);
        c.drawCircle(cx, cy, r * 0.66f, ring);
        c.drawCircle(cx, cy, r * 0.33f, ring);
        c.drawLine(cx - r, cy, cx + r, cy, ring);
        c.drawLine(cx, cy - r, cx, cy + r, ring);

        sweep.setColor(base);
        RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);
        c.drawArc(oval, angle, 58f, false, sweep);

        Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        dot.setColor(base);
        dot.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, 7f, dot);
        c.drawText("SCAN", cx - 32f, cy + r + 30f, text);

        angle += 4.5f;
        if (angle >= 360f) angle -= 360f;
        postInvalidateDelayed(34);
    }
}
