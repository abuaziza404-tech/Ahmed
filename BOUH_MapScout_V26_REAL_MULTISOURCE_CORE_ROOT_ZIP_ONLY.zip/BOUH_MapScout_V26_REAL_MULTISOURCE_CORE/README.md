# BOUH MapScout V26 Real MultiSource Core

مبني على V25 العامل، مع استبدال محرك البيانات إلى V26:
- Grid: bouh_multisource_grid_v26.csv
- Current coverage: SENTINEL_ONLY
- Ready for DEM/Landsat/ASTER columns when raw rasters are physically processed.
- Live radar circle.
- Auto center analysis.
- OUTSIDE DATA outside coverage.
- No fake GPR/bedrock/gold proof.
