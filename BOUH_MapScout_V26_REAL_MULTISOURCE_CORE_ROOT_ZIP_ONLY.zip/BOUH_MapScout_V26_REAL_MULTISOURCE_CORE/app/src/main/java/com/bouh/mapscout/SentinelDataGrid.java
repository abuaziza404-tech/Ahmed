
package com.bouh.mapscout;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;

public class SentinelDataGrid {
    public static class Cell {
        public String zone, coverage, decision, confidence, lineage;
        public double lat, lon, score, structure, iron, clay, quartz, ndvi, noise;
        public double surface, vein, wadi, mountain;
    }

    public static class Result {
        public boolean inside;
        public Cell cell;
        public double distanceM;
        public double score;
        public int surfacePriority, veinPriority, wadiPriority, mountainPriority, noiseRisk;
        public String topIndicator, decision, report;
    }

    private final ArrayList<Cell> cells = new ArrayList<>();
    private boolean loaded = false;

    public void load(Context ctx) {
        if (loaded) return;
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(ctx.getAssets().open("bouh_multisource_grid_v26.csv"), "UTF-8"));
            br.readLine();
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split(",", -1);
                if (p.length < 26) continue;
                Cell c = new Cell();
                c.lat=d(p[0]); c.lon=d(p[1]); c.zone=p[2]; c.coverage=p[3];
                c.structure=d(p[4]); c.iron=d(p[5]); c.clay=d(p[6]); c.quartz=d(p[7]); c.ndvi=d(p[8]); c.noise=d(p[9]);
                c.surface=d(p[18]); c.vein=d(p[19]); c.wadi=d(p[20]); c.mountain=d(p[21]);
                c.score=Math.max(Math.max(c.surface,c.vein),Math.max(c.wadi,c.mountain));
                c.decision=p[23]; c.confidence=p[24]; c.lineage=p[25];
                cells.add(c);
            }
            br.close();
        } catch(Exception ignored) {}
        loaded = true;
    }

    public Result nearest(double lat, double lon, boolean fieldStructure, boolean fieldCarrier, boolean fieldTrap, boolean fieldFe) {
        Result r = new Result();
        if (cells.isEmpty()) {
            r.inside=false; r.decision="NO DATA"; r.report="لا توجد شبكة V26 داخل التطبيق."; return r;
        }
        Cell best=null; double bestM=Double.MAX_VALUE;
        for (Cell c: cells) {
            double dist=distance(lat,lon,c.lat,c.lon);
            if (dist<bestM) { bestM=dist; best=c; }
        }
        r.cell=best; r.distanceM=bestM; r.inside=best!=null && bestM<=4500.0;
        if (!r.inside) {
            r.decision="OUTSIDE DATA";
            r.report=String.format(Locale.US,"OUTSIDE DATA | أقرب خلية %.0fm\nالنقطة خارج تغطية شبكة V26. لا يوجد حساب.", bestM);
            return r;
        }

        double surface=best.surface+(fieldStructure?3:0)+(fieldCarrier?3:0)+(fieldFe?2:0);
        double vein=best.vein+(fieldStructure?5:0)+(fieldCarrier?4:0)+(fieldFe?2:0);
        double wadi=best.wadi+(fieldTrap?6:0)+(fieldCarrier?2:0);
        double mountain=best.mountain+(fieldStructure?4:0)+(fieldCarrier?3:0);
        r.surfacePriority=ci(surface); r.veinPriority=ci(vein); r.wadiPriority=ci(wadi); r.mountainPriority=ci(mountain); r.noiseRisk=ci(best.noise);
        r.score=Math.max(Math.max(r.surfacePriority,r.veinPriority),Math.max(r.wadiPriority,r.mountainPriority));
        r.topIndicator="سطحي";
        if (r.veinPriority>r.surfacePriority && r.veinPriority>=r.wadiPriority && r.veinPriority>=r.mountainPriority) r.topIndicator="عروق";
        if (r.wadiPriority>r.surfacePriority && r.wadiPriority>r.veinPriority && r.wadiPriority>=r.mountainPriority) r.topIndicator="وديان";
        if (r.mountainPriority>r.surfacePriority && r.mountainPriority>r.veinPriority && r.mountainPriority>r.wadiPriority) r.topIndicator="جبال/حواف";

        if ("SENTINEL_ONLY".equals(best.coverage)) {
            if (r.score>=78) r.decision="SENTINEL ONLY FIELD CHECK";
            else if (r.score>=62) r.decision="SENTINEL ONLY CHECK";
            else if (r.score>=48) r.decision="LOW CONFIDENCE CHECK";
            else r.decision="REJECT / HOLD";
        } else {
            if (r.score>=78) r.decision="MULTISOURCE FIELD CHECK";
            else if (r.score>=62) r.decision="MULTISOURCE CHECK";
            else if (r.score>=48) r.decision="LOW CONFIDENCE CHECK";
            else r.decision="REJECT / HOLD";
        }

        r.report=String.format(Locale.US,
            "%s | %.0f%% | أعلى مؤشر: %s\nCoverage: %s | %s | cell %.0fm\nسطحي %d%% | عروق %d%% | وديان %d%% | جبال %d%% | ضجيج %d%%\nStruct %.0f%% | Iron %.0f%% | Clay %.0f%% | Quartz %.0f%% | NDVI %.3f\nPending: DEM/Landsat/ASTER not present",
            r.decision,r.score,r.topIndicator,best.coverage,best.zone,bestM,
            r.surfacePriority,r.veinPriority,r.wadiPriority,r.mountainPriority,r.noiseRisk,
            best.structure,best.iron,best.clay,best.quartz,best.ndvi);
        return r;
    }

    private double d(String s){ try{return Double.parseDouble(s);}catch(Exception e){return -1.0;} }
    private int ci(double v){ return (int)Math.round(Math.max(0,Math.min(100,v))); }
    private double distance(double a,double b,double c,double d){
        double R=6371000.0,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);
        double x=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
        return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));
    }
}
