
package com.bouh.mapscout;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.io.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptoSync {
    private static final String PASSPHRASE = "BOUH-ABUAZIZA-FIELD-SYNC-V22";

    public File encryptedExport(Context ctx, String plain, File outDir) throws Exception {
        if(!outDir.exists()) outDir.mkdirs();
        byte[] key = sha256(PASSPHRASE.getBytes("UTF-8"));
        byte[] iv = new byte[12];
        new SecureRandom().nextBytes(iv);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, iv));
        byte[] enc = cipher.doFinal(plain.getBytes("UTF-8"));
        File f = new File(outDir, "BOUH_secure_sync_v22.bsync");
        FileOutputStream fos = new FileOutputStream(f);
        fos.write(iv);
        fos.write(enc);
        fos.close();
        return f;
    }

    public Intent shareIntent(File f) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(f));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return Intent.createChooser(i, "مشاركة مشفرة عبر Bluetooth / Wi-Fi Direct / Nearby");
    }

    private byte[] sha256(byte[] data) throws Exception {
        MessageDigest d = MessageDigest.getInstance("SHA-256");
        return d.digest(data);
    }
}
