
package com.bouh.mapscout;

import java.util.Locale;

public class SafetyEngine {
    public String topoWarning(RadarEngine.RadarReport r) {
        if (r.floodRisk > 0.72) {
            return String.format(Locale.US, "تحذير سيول مرتفع %.0f%%: تجنب بطن الوادي والمخارج الضيقة.", r.floodRisk * 100);
        }
        if (r.floodRisk > 0.45) {
            return String.format(Locale.US, "تنبيه تضاريس %.0f%%: افحص مخارج الشعاب واترك مسار رجعة.", r.floodRisk * 100);
        }
        return "خطر السيول منخفض حسب النموذج المحلي، لكن راقب السحب ومجاري الوادي.";
    }
}
