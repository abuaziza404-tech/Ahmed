
package com.bouh.mapscout;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.ScaleBarOverlay;
import org.osmdroid.views.overlay.MapEventsOverlay;
import org.osmdroid.events.MapEventsReceiver;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity implements MapEventsReceiver {
    private MapView map;
    private FrameLayout root;
    private TextView hud, mode, sheet;
    private LinearLayout layerPanel;
    private LocationManager locationManager;
    private GeoPoint gpsPoint = new GeoPoint(19.024271, 37.321768);
    private GeoPoint pinPoint = gpsPoint;
    private Marker pinMarker;
    private double altitude = 0;
    private float accuracy = -1;
    private String currentLayer = "Esri Satellite HD";
    private boolean follow = true, powerSave = false;
    private boolean structure = false, carrier = false, trap = false, feox = false;
    private int clarity = 1, sharpness = 1, contrast = 1;
    private RemoteSensingEngine.Mode rsMode = RemoteSensingEngine.Mode.NATURAL;

    private WaypointDb db;
    private RadarEngine radar = new RadarEngine();
    private SafetyEngine safety = new SafetyEngine();
    private VeinTracker vein = new VeinTracker();
    private CryptoSync crypto = new CryptoSync();

    private Button bStructure, bCarrier, bTrap, bFeox, bFollow, bPower, bClay, bIron, bClarity, bSharp, bContrast;
    private View visualOverlay;

    private final int GOLD = Color.rgb(246,216,143);
    private final int WHITE = Color.rgb(255,245,210);
    private final int PANEL = Color.argb(182, 0, 0, 0);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Configuration.getInstance().setUserAgentValue("BOUH-MapScout-V22-AllInOne");
        Configuration.getInstance().setTileFileSystemCacheMaxBytes(512L * 1024L * 1024L);
        Configuration.getInstance().setTileFileSystemCacheTrimBytes(380L * 1024L * 1024L);
        db = new WaypointDb(this);

        root = new FrameLayout(this);
        setContentView(root);
        buildMap();
        buildUi();
        loadExistingMarkers();
        requestLocation();
        dropPin(gpsPoint, false);
        analyzeAndShow();
    }

    private void buildMap() {
        map = new MapView(this);
        map.setMultiTouchControls(true);
        map.getZoomController().setVisibility(CustomZoomButtonsController.Visibility.NEVER);
        map.setTilesScaledToDpi(true);
        map.setFlingEnabled(true);
        map.setMinZoomLevel(3.0);
        map.setMaxZoomLevel(22.0);
        map.setTileSource(TileSources.esriSatellite(22));
        map.getController().setZoom(18.0);
        map.getController().setCenter(gpsPoint);
        root.addView(map, new FrameLayout.LayoutParams(-1, -1));

        ScaleBarOverlay scale = new ScaleBarOverlay(map);
        scale.setCentred(false);
        scale.setScaleBarOffset(18, getResources().getDisplayMetrics().heightPixels - 320);
        map.getOverlays().add(scale);
        map.getOverlays().add(new MapEventsOverlay(this));

        visualOverlay = new View(this);
        visualOverlay.setClickable(false);
        root.addView(visualOverlay, new FrameLayout.LayoutParams(-1, -1));

        View cross = new View(this);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(Color.TRANSPARENT);
        gd.setStroke(dp(2), Color.argb(205, 255, 224, 139));
        cross.setBackground(gd);
        root.addView(cross, new FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER));
    }

    private void buildUi() {
        TextView title = label("BOUH MAPSCOUT V22 ALL-IN-ONE", 14, true);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        tp.setMargins(dp(8), dp(7), dp(8), 0);
        root.addView(title, tp);

        hud = label("GPS...", 12, true);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        hp.setMargins(dp(8), dp(28), dp(8), 0);
        root.addView(hud, hp);

        mode = label("Long-press لإسقاط الدبوس | AUTO GPS | SAR/GPR افتراضي محلي", 11, true);
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        mp.setMargins(dp(8), dp(48), dp(8), 0);
        root.addView(mode, mp);

        sheet = label("", 12, false);
        sheet.setGravity(Gravity.RIGHT);
        sheet.setPadding(dp(10), dp(8), dp(10), dp(8));
        sheet.setBackground(roundBg(PANEL, GOLD));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, dp(158), Gravity.BOTTOM);
        sp.setMargins(dp(8), 0, dp(8), dp(144));
        root.addView(sheet, sp);

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(dp(84), -2, Gravity.RIGHT | Gravity.TOP);
        rp.setMargins(0, dp(75), dp(7), 0);
        root.addView(right, rp);
        right.addView(btn("تكبير", v -> smartZoomIn()));
        right.addView(btn("تصغير", v -> { map.getController().zoomOut(); updateHud(); }));
        bFollow = btn("تتبع", v -> { follow = !follow; if(follow) centerGps(); updateButtons(); });
        right.addView(bFollow);
        right.addView(btn("طبقات", v -> toggleLayerPanel()));

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(88), -2, Gravity.LEFT | Gravity.TOP);
        lp.setMargins(dp(7), dp(75), 0, 0);
        root.addView(left, lp);
        left.addView(btn("Ultra", v -> ultraZoom()));
        bClarity = btn("وضوح 1", v -> { clarity = (clarity + 1) % 5; applyVisual(); });
        bSharp = btn("حدة 1", v -> { sharpness = (sharpness + 1) % 5; applyVisual(); });
        bContrast = btn("تباين 1", v -> { contrast = (contrast + 1) % 5; applyVisual(); });
        left.addView(bClarity); left.addView(bSharp); left.addView(bContrast);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, dp(136), Gravity.BOTTOM);
        bp.setMargins(dp(7), 0, dp(7), dp(7));
        root.addView(bottom, bp);

        LinearLayout r1 = row();
        bStructure = btn("بنية", v -> { structure = !structure; analyzeAndShow(); });
        bCarrier = btn("حامل", v -> { carrier = !carrier; analyzeAndShow(); });
        bTrap = btn("مصيدة", v -> { trap = !trap; analyzeAndShow(); });
        bFeox = btn("FeOx", v -> { feox = !feox; analyzeAndShow(); });
        r1.addView(bStructure); r1.addView(bCarrier); r1.addView(bTrap); r1.addView(bFeox);

        LinearLayout r2 = row();
        r2.addView(btn("حفظ", v -> saveWaypoint()));
        r2.addView(btn("KML", v -> exportFile("kml")));
        r2.addView(btn("P2P", v -> secureShare()));
        bPower = btn("طاقة", v -> togglePower());
        r2.addView(bPower);

        bottom.addView(r1); bottom.addView(r2);

        buildLayerPanel();
        updateButtons();
    }

    private void buildLayerPanel() {
        layerPanel = new LinearLayout(this);
        layerPanel.setOrientation(LinearLayout.VERTICAL);
        layerPanel.setPadding(dp(10), dp(10), dp(10), dp(10));
        layerPanel.setBackground(roundBg(Color.argb(230,0,0,0), GOLD));
        layerPanel.setVisibility(View.GONE);

        TextView head = label("طبقات + مؤشرات + سحابي", 15, true);
        head.setGravity(Gravity.RIGHT);
        layerPanel.addView(head);

        LinearLayout a = row();
        a.addView(btn("قمر HD", v -> setLayer(TileSources.esriSatellite(22), 22, "Esri Satellite HD")));
        a.addView(btn("طرق", v -> setLayer(TileSources.osmRoads(), 19, "OSM Roads")));
        layerPanel.addView(a);

        LinearLayout b = row();
        b.addView(btn("تضاريس", v -> setLayer(TileSources.openTopo(), 17, "OpenTopo")));
        b.addView(btn("فاتح", v -> setLayer(TileSources.cartoLight(), 20, "Carto Light")));
        layerPanel.addView(b);

        LinearLayout c = row();
        bClay = btn("Clay", v -> { rsMode = RemoteSensingEngine.Mode.CLAY; applyVisual(); analyzeAndShow(); });
        bIron = btn("Iron", v -> { rsMode = RemoteSensingEngine.Mode.IRON; applyVisual(); analyzeAndShow(); });
        c.addView(bClay); c.addView(bIron);
        layerPanel.addView(c);

        final EditText custom = new EditText(this);
        custom.setHint("XYZ: https://.../{z}/{x}/{y}.png");
        custom.setTextColor(Color.WHITE);
        custom.setHintTextColor(Color.rgb(210,190,140));
        custom.setSingleLine(false);
        custom.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        custom.setBackground(roundBg(Color.rgb(25,25,25), Color.argb(130,246,216,143)));
        custom.setPadding(dp(8), dp(8), dp(8), dp(8));
        layerPanel.addView(custom, new LinearLayout.LayoutParams(-1, dp(60)));

        LinearLayout d = row();
        d.addView(btn("ربط Z22", v -> {
            String url = custom.getText().toString().trim();
            if(!url.contains("{z}") || !url.contains("{x}") || !url.contains("{y}")) {
                toast("الرابط يجب أن يحتوي {z}/{x}/{y}");
                return;
            }
            setLayer(TileSources.customXYZ("Cloud XYZ Z22", url, 22), 22, "Cloud XYZ Z22");
        }));
        d.addView(btn("إغلاق", v -> toggleLayerPanel()));
        layerPanel.addView(d);

        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, dp(332), Gravity.TOP);
        pp.setMargins(dp(8), dp(72), dp(8), 0);
        root.addView(layerPanel, pp);
    }

    private void setLayer(OnlineTileSourceBase source, double maxZoom, String name) {
        map.setTileSource(source);
        map.setMaxZoomLevel(maxZoom);
        currentLayer = name;
        if(map.getZoomLevelDouble() > maxZoom) map.getController().setZoom(maxZoom);
        toggleLayerPanel();
        updateHud();
        toast("تم اختيار " + name);
    }

    private void toggleLayerPanel() {
        layerPanel.setVisibility(layerPanel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setPadding(1,1,1,1);
        b.setBackground(roundBg(Color.argb(207,16,16,16), Color.argb(140,246,216,143)));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(58), 1);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(p);
        return b;
    }

    private TextView label(String t, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(WHITE);
        v.setTextSize(size);
        v.setShadowLayer(4, 0, 1, Color.BLACK);
        if(bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private GradientDrawable roundBg(int fill, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(12));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public boolean singleTapConfirmedHelper(GeoPoint p) {
        dropPin(p, true);
        return true;
    }

    @Override public boolean longPressHelper(GeoPoint p) {
        dropPin(p, true);
        return true;
    }

    private void dropPin(GeoPoint p, boolean center) {
        pinPoint = p;
        if(pinMarker == null) {
            pinMarker = new Marker(map);
            pinMarker.setTitle("BOUH Dynamic Pin");
            pinMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            map.getOverlays().add(pinMarker);
        }
        pinMarker.setPosition(p);
        if(center) map.getController().animateTo(p);
        vein.push(p);
        map.invalidate();
        analyzeAndShow();
    }

    private void analyzeAndShow() {
        RadarEngine.RadarReport rr = radar.analyze(pinPoint.getLatitude(), pinPoint.getLongitude(), altitude, structure, carrier, trap);
        int score = 0;
        if(structure) score += 42;
        if(carrier) score += 34;
        if(trap) score += 14;
        if(feox) score += 5;
        if(rr.paleochannelProbability > 0.62) score += 5;

        String decision = (!structure || !carrier) ? "REJECT / HOLD" : score >= 82 ? "CLASS A" : score >= 62 ? "CLASS B" : "CLASS C";
        String gpz = score >= 62 ? "GPZ: ضوضاء عالية Difficult/High Yield/Sens 8-11؛ أرض هادئة Normal/General-Deep/Sens 12-16." : "GPZ: لا تبدأ فحص عميق قبل Structure + Carrier.";
        String text = decision + " | Score " + score + " | " + String.format(Locale.US, "%.2f", groundMpx()) + " م/بكسل\n" +
                "Pin: " + String.format(Locale.US, "%.6f, %.6f", pinPoint.getLatitude(), pinPoint.getLongitude()) + "\n" +
                rr.summary + "\n" + safety.topoWarning(rr) + "\n" + vein.report() + "\n" +
                "RS: " + RemoteSensingEngine.formula(rsMode) + "\n" + gpz;
        sheet.setText(text);
        updateButtons();
        updateHud();
    }

    private double groundMpx() {
        GeoPoint c = (GeoPoint) map.getMapCenter();
        return 156543.03392 * Math.cos(Math.toRadians(c.getLatitude())) / Math.pow(2, map.getZoomLevelDouble());
    }

    private void smartZoomIn() {
        if(map.getZoomLevelDouble() >= map.getMaxZoomLevel()) {
            toast("وصلت حد زوم الطبقة. اربط Cloud XYZ Z22 لمصدر أعلى.");
            return;
        }
        map.getController().zoomIn();
        updateHud();
    }

    private void ultraZoom() {
        map.getController().animateTo((GeoPoint)map.getMapCenter(), map.getMaxZoomLevel(), 450L);
        toast("Ultra Zoom: " + currentLayer);
        analyzeAndShow();
    }

    private void applyVisual() {
        int alpha = Math.min(130, contrast * 16 + clarity * 9);
        int color = Color.argb(alpha, 18, 12, 0);
        if(rsMode == RemoteSensingEngine.Mode.CLAY) color = Color.argb(Math.max(alpha, 58), 72, 38, 105);
        if(rsMode == RemoteSensingEngine.Mode.IRON) color = Color.argb(Math.max(alpha, 58), 115, 42, 10);
        visualOverlay.setBackgroundColor(alpha == 0 && rsMode == RemoteSensingEngine.Mode.NATURAL ? Color.TRANSPARENT : color);
        float scale = 1.0f + sharpness * 0.004f;
        map.setScaleX(scale);
        map.setScaleY(scale);
        bClarity.setText("وضوح " + clarity);
        bSharp.setText("حدة " + sharpness);
        bContrast.setText("تباين " + contrast);
    }

    private void updateButtons() {
        setOn(bStructure, structure); setOn(bCarrier, carrier); setOn(bTrap, trap); setOn(bFeox, feox);
        setOn(bFollow, follow); setOn(bPower, powerSave);
        setOn(bClay, rsMode == RemoteSensingEngine.Mode.CLAY);
        setOn(bIron, rsMode == RemoteSensingEngine.Mode.IRON);
        applyVisual();
    }

    private void setOn(Button b, boolean on) {
        if(b == null) return;
        b.setBackground(roundBg(on ? Color.argb(230,122,92,24) : Color.argb(207,16,16,16), Color.argb(145,246,216,143)));
    }

    private void centerGps() {
        map.getController().animateTo(gpsPoint);
        updateHud();
    }

    private void togglePower() {
        powerSave = !powerSave;
        try {
            if(powerSave) startService(new Intent(this, TrackingService.class));
            else stopService(new Intent(this, TrackingService.class));
        } catch(Exception e) {
            toast("Power service: " + e.getMessage());
        }
        requestLocation();
        updateButtons();
    }

    private void saveWaypoint() {
        RadarEngine.RadarReport rr = radar.analyze(pinPoint.getLatitude(), pinPoint.getLongitude(), altitude, structure, carrier, trap);
        Waypoint w = new Waypoint();
        w.time = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(new Date());
        w.name = "BOUH Pin";
        w.lat = pinPoint.getLatitude();
        w.lon = pinPoint.getLongitude();
        w.alt = altitude;
        w.acc = accuracy;
        w.zoom = map.getZoomLevelDouble();
        w.layer = currentLayer + " / " + rsMode;
        w.structure = structure; w.carrier = carrier; w.trap = trap; w.feox = feox;
        w.score = (structure?42:0) + (carrier?34:0) + (trap?14:0) + (feox?5:0) + (rr.paleochannelProbability > 0.62 ? 5 : 0);
        w.decision = (!structure || !carrier) ? "REJECT/HOLD" : w.score >= 82 ? "CLASS A" : w.score >= 62 ? "CLASS B" : "CLASS C";
        w.report = rr.summary + " | " + safety.topoWarning(rr) + " | " + vein.report();
        db.insert(w);
        addMarker(w);
        toast("تم حفظ: " + w.decision);
    }

    private void loadExistingMarkers() {
        for(Waypoint w: db.all()) addMarker(w);
    }

    private void addMarker(Waypoint w) {
        Marker m = new Marker(map);
        m.setPosition(new GeoPoint(w.lat, w.lon));
        m.setTitle(w.decision + " | " + w.score);
        m.setSubDescription(w.report);
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        map.getOverlays().add(m);
        map.invalidate();
    }

    private File outDir() {
        File d = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "BOUH_MapScout_V22");
        if(!d.exists()) d.mkdirs();
        return d;
    }

    private void exportFile(String type) {
        try {
            File f;
            if("kml".equals(type)) {
                f = new File(outDir(), "BOUH_MapScout_V22_waypoints.kml");
                write(f, db.kml());
            } else {
                f = new File(outDir(), "BOUH_MapScout_V22_waypoints.csv");
                write(f, db.csv());
            }
            toast(type.toUpperCase(Locale.US) + ": " + f.getAbsolutePath());
        } catch(Exception e) { toast("Export error: " + e.getMessage()); }
    }

    private void secureShare() {
        try {
            File f = crypto.encryptedExport(this, db.csv() + "\n\n" + db.kml(), outDir());
            startActivity(crypto.shareIntent(f));
        } catch(Exception e) { toast("P2P error: " + e.getMessage()); }
    }

    private void write(File f, String s) throws Exception {
        PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f), "UTF-8"));
        pw.print(s);
        pw.close();
    }

    private void requestLocation() {
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
        if(android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 77);
            return;
        }
        startGpsUpdates();
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(code, perms, grants);
        startGpsUpdates();
    }

    private void startGpsUpdates() {
        try {
            if(android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
            if(locationManager == null) locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
            try { locationManager.removeUpdates(listener); } catch(Exception ignored) {}
            long ms = powerSave ? 12000 : 1200;
            float meters = powerSave ? 8f : 0f;
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, ms, meters, listener);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, ms * 2, meters, listener);
            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location loc = gps != null ? gps : net;
            if(loc != null) onLoc(loc);
        } catch(Exception e) { toast("GPS: " + e.getMessage()); }
    }

    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location location) { onLoc(location); }
        @Override public void onProviderEnabled(String provider) {}
        @Override public void onProviderDisabled(String provider) {}
    };

    private void onLoc(Location loc) {
        gpsPoint = new GeoPoint(loc.getLatitude(), loc.getLongitude());
        altitude = loc.hasAltitude() ? loc.getAltitude() : 0;
        accuracy = loc.hasAccuracy() ? loc.getAccuracy() : -1;
        if(follow) map.getController().animateTo(gpsPoint);
        updateHud();
    }

    private void updateHud() {
        GeoPoint c = (GeoPoint) map.getMapCenter();
        hud.setText(String.format(Locale.US, "%.6f, %.6f | alt %.0fm | acc %s | Z %.1f | %.2fm/px",
                c.getLatitude(), c.getLongitude(), altitude, accuracy < 0 ? "?" : String.format(Locale.US, "%.0fm", accuracy),
                map.getZoomLevelDouble(), groundMpx()));
        mode.setText((powerSave ? "POWER SAVE" : "FIELD LIVE") + " | " + currentLayer + " | " + rsMode + " | Pin Drop SAR/GPR");
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override protected void onResume() { super.onResume(); map.onResume(); }
    @Override protected void onPause() { map.onPause(); super.onPause(); }
}
