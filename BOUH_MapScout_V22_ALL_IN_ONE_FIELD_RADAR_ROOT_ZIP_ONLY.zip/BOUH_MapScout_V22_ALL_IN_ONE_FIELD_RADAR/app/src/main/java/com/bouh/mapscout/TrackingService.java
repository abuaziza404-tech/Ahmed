
package com.bouh.mapscout;

import android.Manifest;
import android.app.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;
import android.location.Location;

public class TrackingService extends Service {
    private static final String CH = "bouh_tracking";
    private LocationManager lm;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(22, notification());
        lm = (LocationManager)getSystemService(LOCATION_SERVICE);
        try {
            if (Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 15000, 10, listener);
            }
        } catch(Exception ignored) {}
        return START_STICKY;
    }

    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location location) {}
        @Override public void onProviderEnabled(String provider) {}
        @Override public void onProviderDisabled(String provider) {}
    };

    private Notification notification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "BOUH Field Tracking", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(ch);
            return new Notification.Builder(this, CH)
                    .setContentTitle("BOUH MapScout")
                    .setContentText("Ultra Power Saving GPS tracking")
                    .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                    .build();
        }
        return new Notification.Builder(this)
                .setContentTitle("BOUH MapScout")
                .setContentText("Ultra Power Saving GPS tracking")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build();
    }

    @Override public void onDestroy() {
        try { if(lm != null) lm.removeUpdates(listener); } catch(Exception ignored) {}
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
