
package com.bouh.mapscout;

public class Waypoint {
    public String time = "";
    public String name = "";
    public double lat, lon, alt, zoom;
    public float acc;
    public String layer = "";
    public boolean structure, carrier, trap, feox;
    public int score;
    public String decision = "";
    public String report = "";
}
