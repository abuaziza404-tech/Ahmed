
package com.bouh.mapscout;

import java.util.Locale;

public class RadarEngine {
    public static class RadarReport {
        public double bedrockDepthM;
        public double paleochannelProbability;
        public double sarRoughness;
        public double drainageRisk;
        public double floodRisk;
        public String gprAscii;
        public String summary;
    }

    public RadarReport analyze(double lat, double lon, double alt, boolean structure, boolean carrier, boolean trap) {
        double seed = Math.abs(Math.sin(lat * 12.9898 + lon * 78.233) * 43758.5453);
        double n = seed - Math.floor(seed);
        double n2 = frac(seed * 1.618);
        double n3 = frac(seed * 2.414);

        RadarReport r = new RadarReport();
        r.sarRoughness = clamp(0.18 + n * 0.76, 0, 1);
        r.drainageRisk = clamp(0.15 + n2 * 0.80, 0, 1);
        r.paleochannelProbability = clamp(0.20 + n3 * 0.55 + (trap ? 0.18 : 0) + (structure ? 0.06 : 0), 0, 0.98);
        r.bedrockDepthM = 0.6 + (1.0 - r.sarRoughness) * 4.2 + r.drainageRisk * 2.3 + (trap ? 0.7 : 0);
        r.floodRisk = clamp(r.drainageRisk * 0.70 + (trap ? 0.18 : 0) + (r.bedrockDepthM > 4.0 ? 0.08 : 0), 0, 1);

        r.gprAscii = bars(r.bedrockDepthM, r.paleochannelProbability, r.sarRoughness, r.drainageRisk);
        String grade = r.paleochannelProbability > 0.70 ? "مرتفع" : r.paleochannelProbability > 0.45 ? "متوسط" : "منخفض";
        r.summary = String.format(Locale.US,
                "تقرير راداري افتراضي محلي\\nDepth to Bedrock ≈ %.1f m\\nPaleochannel probability: %.0f%% (%s)\\nSAR roughness proxy: %.0f%%\\nFlood/Drainage caution: %.0f%%\\n%s",
                r.bedrockDepthM, r.paleochannelProbability * 100.0, grade, r.sarRoughness * 100.0, r.floodRisk * 100.0,
                "تنبيه صدق: هذا نموذج ميداني/افتراضي من قاعدة محلية، وليس GPR/SAR خام مقاس.");
        return r;
    }

    private double frac(double v) { return v - Math.floor(v); }
    private double clamp(double v, double a, double b) { return Math.max(a, Math.min(b, v)); }

    private String bars(double depth, double paleo, double rough, double drain) {
        return "GPR SIM\\n" +
                "0m  |████████████| surface\\n" +
                "1m  |" + bar(1.0 / Math.max(depth, 1.0)) + "|\\n" +
                "3m  |" + bar(paleo) + "| paleo\\n" +
                "5m  |" + bar(rough) + "| rough\\n" +
                "Wadi|" + bar(drain) + "|";
    }

    private String bar(double v) {
        int k = (int)Math.round(clamp(v,0,1) * 12.0);
        StringBuilder sb = new StringBuilder();
        for(int i=0;i<12;i++) sb.append(i<k ? "█" : "░");
        return sb.toString();
    }
}
