
package com.bouh.mapscout;

public class RemoteSensingEngine {
    public enum Mode { NATURAL, CLAY, IRON }

    public static String formula(Mode m) {
        if (m == Mode.CLAY) {
            return "Clay/Alteration proxy: Sentinel-2 SWIR ratios مثل B11/B12 أو ASTER SWIR. يحتاج باندات خام.";
        }
        if (m == Mode.IRON) {
            return "Iron Oxide proxy: Landsat/Sentinel red-blue/SWIR ratios. يحتاج Reflectance bands وليس خريطة JPG.";
        }
        return "Natural map view.";
    }

    public static String warning() {
        return "الطبقات المرئية لا تكفي لحساب نسب طيفية. استخدم GeoTIFF/JP2/MTL/QA/DEM للأرقام.";
    }
}
