# BOUH MapScout V22 All-in-One Field Radar

حزمة موحدة مبنية على V21 Native:

## Engine
- osmdroid Native MapView.
- زوم بالأصابع + سرعة جيدة + Tile cache.
- Ultra zoom حتى Z22 إذا كانت البلاطات تدعم ذلك.
- طبقات: Esri Satellite HD / OSM / OpenTopo / Carto / Custom XYZ.

## Dynamic Pin Dropper
- Long press أو tap على الخريطة لإسقاط الدبوس.
- يلتقط الإحداثيات فورًا.
- يشغل تقرير SAR/GPR افتراضي محلي offline.

## Local Radar / SAR-GPR Simulation
- RadarEngine.java يعطي:
  Depth to Bedrock proxy
  Paleochannel probability
  SAR roughness proxy
  Drainage/Flood risk
  GPR-like ASCII indicators
- تنبيه صدق مدمج: ليس قياس SAR/GPR حقيقي بدون بيانات خام.

## Remote Sensing UI
- Clay mode
- Iron mode
- المعادلات موثقة، لكن لا يعطي نسب رقمية بدون GeoTIFF/RAW bands/DEM.

## Offline GIS
- SQLite Waypoint DB.
- CSV/KML export.
- osmdroid tile cache.
- Custom XYZ ready for local/MBTiles-server or cloud tiles.

## Field Tools
- Vein Tracker يحسب اتجاه العرق من نقطتين.
- Safety Topo warning من نموذج التصريف المحلي.
- Ultra Power Saving GPS foreground service.
- Secure encrypted export for P2P sharing via Android share sheet.

## Truth Rule
Map tiles and virtual radar models are field aids only. Numeric spectral/SAR/GPR outputs require raw data.
