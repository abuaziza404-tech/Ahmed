
package com.bouh.mapscout;

import org.osmdroid.tileprovider.tilesource.XYTileSource;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.util.MapTileIndex;

public final class TileSources {
    private TileSources() {}

    public static OnlineTileSourceBase esriSatellite(final int maxZoom) {
        return new XYTileSource("Esri Satellite HD", 0, maxZoom, 256, ".jpg",
                new String[]{"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"}) {
            @Override public String getTileURLString(long idx) {
                return getBaseUrl() + MapTileIndex.getZoom(idx) + "/" + MapTileIndex.getY(idx) + "/" + MapTileIndex.getX(idx);
            }
        };
    }

    public static OnlineTileSourceBase osmRoads() {
        return new XYTileSource("OSM Roads", 0, 19, 256, ".png", new String[]{"https://tile.openstreetmap.org/"}) {
            @Override public String getTileURLString(long idx) {
                return getBaseUrl() + MapTileIndex.getZoom(idx) + "/" + MapTileIndex.getX(idx) + "/" + MapTileIndex.getY(idx) + ".png";
            }
        };
    }

    public static OnlineTileSourceBase openTopo() {
        return new XYTileSource("OpenTopo", 0, 17, 256, ".png", new String[]{"https://a.tile.opentopomap.org/"}) {
            @Override public String getTileURLString(long idx) {
                return getBaseUrl() + MapTileIndex.getZoom(idx) + "/" + MapTileIndex.getX(idx) + "/" + MapTileIndex.getY(idx) + ".png";
            }
        };
    }

    public static OnlineTileSourceBase cartoLight() {
        return new XYTileSource("Carto Light", 0, 20, 256, ".png", new String[]{"https://a.basemaps.cartocdn.com/light_all/"}) {
            @Override public String getTileURLString(long idx) {
                return getBaseUrl() + MapTileIndex.getZoom(idx) + "/" + MapTileIndex.getX(idx) + "/" + MapTileIndex.getY(idx) + ".png";
            }
        };
    }

    public static OnlineTileSourceBase customXYZ(final String name, final String template, final int maxZoom) {
        return new XYTileSource(name, 0, maxZoom, 256, ".png", new String[]{template}) {
            @Override public String getTileURLString(long idx) {
                return template
                        .replace("{z}", String.valueOf(MapTileIndex.getZoom(idx)))
                        .replace("{x}", String.valueOf(MapTileIndex.getX(idx)))
                        .replace("{y}", String.valueOf(MapTileIndex.getY(idx)));
            }
        };
    }
}
