# BOUH MapScout V22.2 Stable All-in-One

إصلاح جذري لمشكلة فشل البناء:
- إزالة ForegroundService و Bluetooth/Crypto sharing لتجنب أخطاء build/runtime.
- إبقاء جوهر المنظومة:
  Native osmdroid MapView
  Pin Drop
  Radar proxy
  Clay/Iron mode
  SQLite waypoints
  Vein Tracker
  Safety warning
  Power saving عبر تغيير معدل GPS فقط
  KML/CSV export
  Custom XYZ Z22
- هذه النسخة مصممة للبناء المستقر عبر GitHub Actions.
