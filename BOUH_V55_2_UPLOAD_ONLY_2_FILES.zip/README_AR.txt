# ارفع ملفين فقط

ارفع هذين الملفين إلى جذر المستودع:

1) BOUH_ANDROID_PROJECT.zip
2) build.yml

لكن ملف build.yml يجب أن يكون داخل:
.github/workflows/build.yml

يعني في GitHub:
- BOUH_ANDROID_PROJECT.zip في الجذر
- build.yml داخل .github/workflows/

لا ترفع باقي الملفات.
لا تفك ضغط BOUH_ANDROID_PROJECT.zip داخل GitHub.

GitHub Actions سيفك الضغط ويبني APK تلقائيًا.

بعد التشغيل:
Actions → Build BOUH MapScout V55.2 APK → Run workflow

ثم:
Artifacts → BOUH_MapScout_V55_2_debug_apk → app-debug.apk
