
package com.bouh.mapscout;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.view.View;
import android.widget.FrameLayout;
import android.provider.Settings;

public class MainActivity extends Activity {
    private WebView webView;
    private LocationManager locationManager;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Location lastLocation;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        setContentView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        requestPermsAndStart();
    }

    private void requestPermsAndStart() {
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 77);
        } else {
            startGps();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        startGps();
    }

    private void startGps() {
        try {
            LocationListener listener = new LocationListener() {
                @Override public void onLocationChanged(Location loc) {
                    lastLocation = loc;
                    injectLocation(loc);
                }
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) {}
            };
            if (checkSelfPermissionSafe()) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, listener);
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 0, listener);
                Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                Location net = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (gps != null) injectLocation(gps);
                else if (net != null) injectLocation(net);
            }
        } catch(Exception e) {
            final String msg = e.getMessage() == null ? "gps error" : e.getMessage().replace("'", "");
            webView.evaluateJavascript("window.nativeStatus && nativeStatus('GPS error: " + msg + "')", null);
        }
    }

    private boolean checkSelfPermissionSafe() {
        if (android.os.Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
               checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void injectLocation(Location loc) {
        final double lat = loc.getLatitude();
        final double lon = loc.getLongitude();
        final double alt = loc.hasAltitude() ? loc.getAltitude() : 0.0;
        final float acc = loc.hasAccuracy() ? loc.getAccuracy() : -1f;
        handler.post(() -> webView.evaluateJavascript(
            "window.updateGps && window.updateGps(" + lat + "," + lon + "," + alt + "," + acc + ");", null));
    }

    @Override
    protected void onResume() { super.onResume(); if(webView != null) webView.onResume(); }
    @Override
    protected void onPause() { if(webView != null) webView.onPause(); super.onPause(); }
}
