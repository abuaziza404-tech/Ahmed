# BOUH MapScout V14 HD-GPS

تطبيق خرائط GPS ميداني لمشروع BOUH:
- Satellite HD / OSM / Topo online tiles
- GPS + altitude + accuracy
- زوم قريب 18/19/20 حسب توفر البلاطات
- قرار ميداني Structure -> Carrier -> Trap -> FeOx
- حفظ CSV للأهداف
- قاعدة الصدق: لا يحسب نسب طيفية من خرائط أو كاميرا؛ التحليل الطيفي يحتاج GeoTIFF/RAW bands/DEM.

ارفع ZIP في جذر المستودع واستخدم YAML المرفق في المحادثة.
