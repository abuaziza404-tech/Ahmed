package com.bouh.darbeel;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.SurfaceTexture;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.Range;
import android.view.*;
import android.widget.*;
import android.location.*;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Semaphore;

public class MainActivity extends Activity implements TextureView.SurfaceTextureListener, SensorEventListener, LocationListener {
    private static final int REQ = 1107;
    private TextureView texture;
    private HudView hud;
    private HandlerThread camThread;
    private Handler camHandler;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private CaptureRequest.Builder requestBuilder;
    private ImageReader imageReader;
    private Surface previewSurface;
    private String cameraId;
    private CameraCharacteristics chars;
    private Rect activeArray;
    private final Semaphore lock = new Semaphore(1);

    private boolean enhancedView = false;       // false = raw camera preview always visible
    private boolean nightBoost = false;
    private boolean dayHdr = true;
    private boolean torch = false;
    private boolean manualSensor = false;       // default AUTO so the preview never starts black
    private boolean stackOn = false;
    private int mode = 0;                       // 0 Real, 1 Detail B/W, 2 Night, 3 Day HDR, 4 Edge, 5 Dust/Fog
    private int isoIndex = 2;
    private int expIndex = 1;
    private float zoom = 1.0f;
    private float gain = 1.10f;
    private float gamma = 0.82f;
    private float detail = 0.50f;
    private float lift = 8f;
    private float contrast = 1.12f;
    private float denoise = 0.18f;
    private Bitmap processed;
    private int[] previousY;
    private int[] stackY;
    private long lastNs = 0;
    private float fps = 0;
    private float heading = 0, altitude = 0;
    private double lat = 0, lon = 0;
    private boolean hasLocation = false;
    private String status = "RAW PREVIEW READY";
    private SensorManager sensorManager;
    private LocationManager locationManager;

    private final String[] modes = {"REAL VIEW", "DETAIL B/W", "NIGHT BREAKER", "DAY HDR", "EDGE DETAIL", "DUST/FOG CUT"};
    private final int[] isoSteps = {400, 800, 1600, 3200, 4800, 6400};
    private final long[] expNs = {33333333L, 66666666L, 100000000L, 166666666L, 250000000L, 333333333L};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildUi();
        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ);
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        texture = new TextureView(this);
        texture.setSurfaceTextureListener(this);
        root.addView(texture, new FrameLayout.LayoutParams(-1, -1));
        hud = new HudView(this);
        root.addView(hud, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setPadding(dp(6), dp(6), dp(6), dp(6));
        side.setAlpha(0.84f);
        String[] labels = {"RAW/BOOST", "MODE", "NIGHT", "DAY HDR", "TORCH", "ZOOM+", "ZOOM-", "ISO+", "ISO-", "EXP+", "EXP-", "STACK", "MANUAL", "DETAIL+", "DETAIL-", "CAPTURE"};
        for (String label: labels) {
            Button b = new Button(this);
            b.setText(label);
            b.setTextSize(10);
            b.setAllCaps(false);
            b.setPadding(2,1,2,1);
            b.setOnClickListener(v -> handle(((Button)v).getText().toString()));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(112), dp(32));
            lp.setMargins(0,0,0,dp(3));
            side.addView(b, lp);
        }
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(dp(124), -2, Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        slp.setMargins(0,0,dp(18),0);
        root.addView(side, slp);
        setContentView(root);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void handle(String s) {
        if (s.equals("RAW/BOOST")) enhancedView = !enhancedView;
        else if (s.equals("MODE")) mode = (mode + 1) % modes.length;
        else if (s.equals("NIGHT")) { nightBoost = !nightBoost; enhancedView = nightBoost; if(nightBoost){ mode = 2; manualSensor = true; isoIndex = Math.max(isoIndex,3); expIndex = Math.max(expIndex,2); gain = 2.8f; gamma = 0.42f; lift = 44f; contrast = 1.55f; detail = 0.82f; } else { manualSensor = false; gain = 1.10f; gamma = 0.82f; lift = 8f; contrast = 1.12f; } }
        else if (s.equals("DAY HDR")) { dayHdr = !dayHdr; mode = 3; nightBoost = false; manualSensor = false; enhancedView = dayHdr; gain = 1.0f; gamma = 0.95f; lift = 0f; contrast = 1.20f; detail = 0.70f; }
        else if (s.equals("TORCH")) { torch = !torch; }
        else if (s.equals("ZOOM+")) zoom = Math.min(10f, zoom + 0.35f);
        else if (s.equals("ZOOM-")) zoom = Math.max(1f, zoom - 0.35f);
        else if (s.equals("ISO+")) { isoIndex = Math.min(isoSteps.length-1, isoIndex+1); manualSensor = true; }
        else if (s.equals("ISO-")) { isoIndex = Math.max(0, isoIndex-1); manualSensor = true; }
        else if (s.equals("EXP+")) { expIndex = Math.min(expNs.length-1, expIndex+1); manualSensor = true; }
        else if (s.equals("EXP-")) { expIndex = Math.max(0, expIndex-1); manualSensor = true; }
        else if (s.equals("STACK")) { stackOn = !stackOn; stackY = null; }
        else if (s.equals("MANUAL")) manualSensor = !manualSensor;
        else if (s.equals("DETAIL+")) { detail = Math.min(1.50f, detail + 0.10f); contrast = Math.min(2.0f, contrast + 0.05f); }
        else if (s.equals("DETAIL-")) { detail = Math.max(0.05f, detail - 0.10f); contrast = Math.max(0.80f, contrast - 0.05f); }
        else if (s.equals("CAPTURE")) saveCapture();
        applyRepeating();
        hud.invalidate();
    }

    @Override public void onResume() {
        super.onResume();
        startThread();
        Sensor s = sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);
        if (s != null) sensorManager.registerListener(this, s, SensorManager.SENSOR_DELAY_UI);
        try { if (Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500, 1, this); } catch(Exception ignored) {}
        if (texture.isAvailable()) openCamera();
    }

    @Override public void onPause() {
        closeCamera();
        try { sensorManager.unregisterListener(this); locationManager.removeUpdates(this); } catch(Exception ignored) {}
        stopThread();
        super.onPause();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { super.onRequestPermissionsResult(r,p,g); if(texture.isAvailable()) openCamera(); }

    private void startThread(){ camThread = new HandlerThread("BOUH-V11-Camera"); camThread.start(); camHandler = new Handler(camThread.getLooper()); }
    private void stopThread(){ if(camThread!=null){ camThread.quitSafely(); try{camThread.join();}catch(Exception ignored){} camThread=null; camHandler=null; } }

    @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) { openCamera(); }
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) { return true; }
    @Override public void onSurfaceTextureUpdated(SurfaceTexture st) {}

    private void openCamera() {
        if (camHandler == null || !texture.isAvailable()) return;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        try {
            CameraManager cm = (CameraManager)getSystemService(CAMERA_SERVICE);
            cameraId = cm.getCameraIdList()[0];
            for (String id: cm.getCameraIdList()) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) { cameraId = id; break; }
            }
            chars = cm.getCameraCharacteristics(cameraId);
            activeArray = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            SurfaceTexture st = texture.getSurfaceTexture();
            st.setDefaultBufferSize(1280, 720);
            previewSurface = new Surface(st);
            imageReader = ImageReader.newInstance(640, 360, ImageFormat.YUV_420_888, 3);
            imageReader.setOnImageAvailableListener(this::onImage, camHandler);
            lock.acquire();
            cm.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) { lock.release(); camera = c; createSession(); }
                @Override public void onDisconnected(CameraDevice c) { lock.release(); c.close(); camera = null; status = "CAMERA DISCONNECTED"; }
                @Override public void onError(CameraDevice c, int err) { lock.release(); c.close(); camera = null; status = "CAMERA ERROR " + err; hud.postInvalidate(); }
            }, camHandler);
        } catch(Exception e) { status = "OPEN ERROR: " + e.getMessage(); Toast.makeText(this, status, Toast.LENGTH_LONG).show(); hud.invalidate(); }
    }

    private void createSession() {
        try {
            requestBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            requestBuilder.addTarget(previewSurface);
            requestBuilder.addTarget(imageReader.getSurface());
            applyControls(requestBuilder);
            List<Surface> surfaces = Arrays.asList(previewSurface, imageReader.getSurface());
            camera.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession s) { session = s; status = "LIVE PREVIEW"; applyRepeating(); }
                @Override public void onConfigureFailed(CameraCaptureSession s) { status = "SESSION CONFIG FAILED"; hud.postInvalidate(); }
            }, camHandler);
        } catch(Exception e) { status = "SESSION ERROR: " + e.getMessage(); hud.postInvalidate(); }
    }

    private void applyRepeating() {
        try {
            if (camera == null || session == null) return;
            requestBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            requestBuilder.addTarget(previewSurface);
            requestBuilder.addTarget(imageReader.getSurface());
            applyControls(requestBuilder);
            session.setRepeatingRequest(requestBuilder.build(), null, camHandler);
        } catch(Exception e) { status = "REQUEST ERROR: " + e.getMessage(); hud.postInvalidate(); }
    }

    private void applyControls(CaptureRequest.Builder b) {
        try {
            b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            b.set(CaptureRequest.FLASH_MODE, torch ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            if (activeArray != null && zoom > 1.01f) {
                int cropW = (int)(activeArray.width() / zoom);
                int cropH = (int)(activeArray.height() / zoom);
                int left = activeArray.left + (activeArray.width() - cropW) / 2;
                int top = activeArray.top + (activeArray.height() - cropH) / 2;
                b.set(CaptureRequest.SCALER_CROP_REGION, new Rect(left, top, left + cropW, top + cropH));
            }
            if (manualSensor) {
                b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
                int iso = isoSteps[Math.max(0, Math.min(isoSteps.length-1, isoIndex))];
                long exp = expNs[Math.max(0, Math.min(expNs.length-1, expIndex))];
                Range<Integer> sr = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
                Range<Long> er = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
                if (sr != null) iso = Math.max(sr.getLower(), Math.min(sr.getUpper(), iso));
                if (er != null) exp = Math.max(er.getLower(), Math.min(er.getUpper(), exp));
                b.set(CaptureRequest.SENSOR_SENSITIVITY, iso);
                b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp);
            } else {
                b.set(CaptureRequest.CONTROL_AE_MODE, torch ? CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH : CaptureRequest.CONTROL_AE_MODE_ON);
                b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, nightBoost ? 2 : 0);
            }
        } catch(Exception ignored) {}
    }

    private void closeCamera() {
        try { lock.acquire(); if(session!=null){session.close(); session=null;} if(camera!=null){camera.close(); camera=null;} if(imageReader!=null){imageReader.close(); imageReader=null;} if(previewSurface!=null){previewSurface.release(); previewSurface=null;} } catch(Exception ignored) {} finally { lock.release(); }
    }

    private void onImage(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            long now = System.nanoTime();
            if (lastNs > 0) fps = fps * 0.86f + (1_000_000_000f / Math.max(1, now-lastNs)) * 0.14f;
            lastNs = now;
            process(img);
        } catch(Exception e) { status = "FRAME ERROR: " + e.getMessage(); }
        finally { if (img != null) img.close(); }
    }

    private void process(Image img) {
        int w = img.getWidth(), h = img.getHeight();
        Image.Plane yp = img.getPlanes()[0];
        ByteBuffer yb = yp.getBuffer();
        int stride = yp.getRowStride();
        int[] y = new int[w*h];
        for (int yy=0; yy<h; yy++) for (int x=0; x<w; x++) y[yy*w+x] = yb.get(yy*stride + x) & 255;
        int[] st = percentile(y);
        int lo = st[0], hi = st[1];
        if (hi <= lo + 12) hi = lo + 36;
        autoTune(y, st);
        int[] out = new int[w*h];
        boolean usePrev = previousY != null && previousY.length == y.length;
        for (int yy=1; yy<h-1; yy++) {
            int off = yy*w;
            for (int x=1; x<w-1; x++) {
                int i = off+x;
                int v = (y[i] - lo) * 255 / (hi - lo);
                v = clamp((int)(v + lift));
                if (usePrev) v = (int)(v*(1f-denoise) + previousY[i]*denoise);
                if (stackOn && stackY != null && stackY.length == y.length) v = (v*5 + stackY[i]*5)/10;
                int lap = v*4 - y[i-1] - y[i+1] - y[i-w] - y[i+w];
                int local = (y[i-1]+y[i+1]+y[i-w]+y[i+w])/4;
                int l2 = clamp((local-lo)*255/(hi-lo));
                int dehaze = (mode==5) ? (int)((v-l2)*0.85f) : (int)((v-l2)*0.30f);
                int edge = (int)(Math.abs(lap) * detail);
                int vv = (int)((v - 128) * contrast + 128 + dehaze + (mode==4 ? edge*2 : edge));
                vv = (int)(Math.pow(Math.max(0, Math.min(255, vv)) / 255.0, gamma) * 255.0 * gain);
                if (nightBoost || mode==2) vv = clamp((int)(vv*1.22f + 28));
                if (dayHdr || mode==3) vv = clamp((int)(vv*0.96f + edge*0.25f));
                vv = clamp(vv);
                int color;
                if (mode == 1 || mode == 2 || mode == 4) color = Color.rgb(vv, vv, vv);
                else if (mode == 5) color = Color.rgb(clamp((int)(vv*0.96)), clamp((int)(vv*1.00)), clamp((int)(vv*1.08)));
                else color = Color.rgb(vv, vv, vv);
                out[i] = color;
            }
        }
        if (stackOn) {
            if (stackY == null || stackY.length != y.length) stackY = Arrays.copyOf(y, y.length);
            else for (int i=0; i<y.length; i++) stackY[i] = (stackY[i]*4 + y[i]) / 5;
        }
        previousY = new int[out.length];
        for (int i=0; i<out.length; i++) previousY[i] = out[i] & 255;
        processed = Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888);
        hud.postInvalidate();
    }

    private int[] percentile(int[] y) {
        int[] hist = new int[256];
        for (int i=0; i<y.length; i+=3) hist[y[i]&255]++;
        int total = Math.max(1, y.length/3), c=0, lo=0, hi=255;
        int loT = Math.max(1, total/200), hiT = Math.max(1, total*995/1000);
        for (int i=0; i<256; i++) { c += hist[i]; if (c >= loT) { lo=i; break; } }
        c=0; for (int i=0; i<256; i++) { c += hist[i]; if (c >= hiT) { hi=i; break; } }
        return new int[]{lo,hi};
    }

    private void autoTune(int[] y, int[] st) {
        long sum=0; for(int i=0;i<y.length;i+=8) sum += y[i];
        float mean = sum / (float)Math.max(1, y.length/8);
        if (!manualSensor && mean < 38) { nightBoost = true; enhancedView = true; mode = 2; gain = 3.2f; gamma = 0.38f; lift = 52f; contrast = 1.65f; detail = 0.90f; denoise = 0.38f; }
        else if (!manualSensor && mean > 120 && !nightBoost) { gain = 1.0f; gamma = 0.96f; lift = 0f; contrast = dayHdr ? 1.25f : 1.08f; detail = dayHdr ? 0.72f : 0.45f; denoise = 0.12f; }
    }

    private int clamp(int v) { return Math.max(0, Math.min(255, v)); }

    private void saveCapture() {
        try {
            Bitmap b = (enhancedView && processed != null) ? processed : texture.getBitmap();
            if (b == null) return;
            String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "BOUH_DARBEEL_V11_"+ts+".jpg");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/BOUH_Darbeel_V11_RealView");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            OutputStream os = getContentResolver().openOutputStream(uri);
            b.compress(Bitmap.CompressFormat.JPEG, 94, os);
            os.close();
            Toast.makeText(this, "Saved V11 capture", Toast.LENGTH_SHORT).show();
        } catch(Exception e) { Toast.makeText(this, "Save failed: "+e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    @Override public void onSensorChanged(SensorEvent e) { heading = e.values[0]; hud.invalidate(); }
    @Override public void onAccuracyChanged(Sensor s, int a) {}
    @Override public void onLocationChanged(Location l) { lat=l.getLatitude(); lon=l.getLongitude(); altitude=(float)l.getAltitude(); hasLocation=true; hud.invalidate(); }

    public class HudView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        public HudView(Context c){ super(c); setWillNotDraw(false); }
        @Override protected void onDraw(Canvas c) {
            int W=getWidth(), H=getHeight();
            if (enhancedView && processed != null) {
                Rect src = new Rect(0,0,processed.getWidth(),processed.getHeight());
                c.drawBitmap(processed, src, new Rect(0,0,W,H), null);
            }
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.argb(185, 255, 230, 145));
            float cx=W/2f, cy=H/2f, r=Math.min(W,H)*0.29f;
            c.drawCircle(cx,cy,r,p); c.drawLine(cx-r*0.72f,cy,cx-r*0.18f,cy,p); c.drawLine(cx+r*0.18f,cy,cx+r*0.72f,cy,p); c.drawLine(cx,cy-r*0.72f,cx,cy-r*0.18f,p); c.drawLine(cx,cy+r*0.18f,cx,cy+r*0.72f,p);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(230,255,235,185)); p.setTextSize(23); p.setShadowLayer(4,1,1,Color.BLACK);
            c.drawText("BOUH DARBEEL V11 REALVIEW  •  أحمد أبوعزيزة", 18, 32, p);
            p.setTextSize(19); c.drawText(String.format(Locale.US,"%s | FPS %.0f | %s | Z %.1fx | %s", enhancedView?"BOOST":"RAW", fps, modes[mode], zoom, status), 18, 58, p);
            c.drawText(String.format(Locale.US,"ISO %d EXP %dms | GAIN %.2f GAMMA %.2f DETAIL %.2f LIFT %.0f | SENSOR %s", isoSteps[isoIndex], expNs[expIndex]/1000000L, gain, gamma, detail, lift, manualSensor?"MANUAL":"AUTO"), 18, 84, p);
            p.setTextSize(16); String gps = hasLocation ? String.format(Locale.US,"GPS %.5f, %.5f ALT %.0fm",lat,lon,altitude) : "GPS searching";
            c.drawText(String.format(Locale.US,"HDG %.0f° | %s | TORCH %s | NIGHT %s | STACK %s", heading, gps, torch?"ON":"OFF", nightBoost?"ON":"OFF", stackOn?"ON":"OFF"), 18, H-24, p);
        }
    }
}
