# BOUH Darbeel V11 RealView

This version fixes the black-screen issue by rendering the real Camera2 TextureView preview directly, then applying optional enhanced processing as an overlay. If image analysis fails, the raw camera preview still remains visible.

Key features:
- Raw live camera preview always visible
- Optional BOOST processed view
- Day HDR and Night Breaker modes
- Manual/Auto sensor control
- ISO, exposure, torch, zoom, stack controls
- Save capture to Pictures/BOUH_Darbeel_V11_RealView
