# Abuaziza AI: keep default Android rules.
