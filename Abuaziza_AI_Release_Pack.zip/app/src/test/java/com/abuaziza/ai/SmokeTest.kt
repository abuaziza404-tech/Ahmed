package com.abuaziza.ai
import org.junit.Test
import org.junit.Assert.*
class SmokeTest {
 @Test fun packageIsStable() { assertEquals("com.abuaziza.ai", MainActivity::class.java.packageName) }
 @Test fun modelIdIsExpected() { assertTrue("gpt-5.6-terra".startsWith("gpt-5.6-")) }
}
