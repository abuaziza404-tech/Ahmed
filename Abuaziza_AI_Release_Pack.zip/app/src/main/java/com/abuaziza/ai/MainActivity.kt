package com.abuaziza.ai

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var keyBox: EditText
    private lateinit var prompt: EditText
    private lateinit var output: TextView
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS).build()

    private val prefs by lazy {
        val master = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        EncryptedSharedPreferences.create(
            "abuaziza_secure", master, this,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 16)
            setBackgroundColor(android.graphics.Color.rgb(16,17,20))
        }
        val title = TextView(this).apply {
            text = "أبو عزيزه AI"; textSize = 28f; gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(212,175,55))
        }
        keyBox = EditText(this).apply {
            hint = "OpenAI API Key"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key","") ?: "")
        }
        prompt = EditText(this).apply {
            hint = "اكتب مهمتك هنا..."; minLines = 4; gravity = Gravity.TOP
        }
        val send = Button(this).apply { text = "إرسال إلى أبو عزيزه AI" }
        output = TextView(this).apply { textSize = 16f; setTextColor(android.graphics.Color.WHITE); setPadding(8,16,8,8) }
        root.addView(title); root.addView(keyBox); root.addView(prompt)
        root.addView(send); root.addView(output)
        setContentView(root)
        send.setOnClickListener { callOpenAI() }
    }

    private fun callOpenAI() {
        val key = keyBox.text.toString().trim()
        val text = prompt.text.toString().trim()
        if (key.isEmpty() || text.isEmpty()) { output.text = "أدخل مفتاح API والطلب أولاً."; return }
        prefs.edit().putString("key", key).apply()
        output.text = "جارٍ التنفيذ..."
        val body = JSONObject().apply {
            put("model", "gpt-5.6-terra")
            put("store", false)
            put("input", JSONArray().put(JSONObject().apply {
                put("role","user"); put("content", JSONArray().put(JSONObject().apply {
                    put("type","input_text"); put("text", text)
                }))
            }))
        }.toString()
        val req = Request.Builder().url("https://api.openai.com/v1/responses")
            .addHeader("Authorization","Bearer $key")
            .addHeader("Content-Type","application/json")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) = runOnUiThread { output.text = "خطأ اتصال: ${e.message}" }
            override fun onResponse(call: Call, r: Response) {
                r.use {
                    val raw = it.body?.string().orEmpty()
                    if (!it.isSuccessful()) {
                        runOnUiThread { output.text = "خطأ API (${it.code}): $raw" }; return
                    }
                    val j = JSONObject(raw)
                    val textOut = j.optString("output_text", "")
                    runOnUiThread { output.text = if (textOut.isNotBlank()) textOut else raw }
                }
            }
        })
    }
}
