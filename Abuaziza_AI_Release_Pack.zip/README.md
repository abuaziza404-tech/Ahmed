# أبو عزيزه AI
مشروع Android مستقل + GitHub Actions.

رفع المشروع إلى GitHub ثم تشغيل:
Actions → Abuaziza AI - Build Release → Run workflow

المتطلبات: API key يضعه المستخدم داخل التطبيق. لا يوجد مفتاح API داخل المستودع.
