# BOUH MapScout V22.3 Overzoom UI Pro

تحديث واجهة ومحرك:
- OverzoomTileSources: يمنع اختفاء الطبقة بعد Z17.8/Z19 عبر جلب آخر مستوى أصلي متاح بدلاً من تركها فارغة.
- Floating Overlay Toolbar: أزرار صغيرة جانبية وعلوية بدل شريط سفلي ثقيل.
- Draggable Bottom Sheet: بطاقة رادار قابلة للسحب والتصغير/التكبير.
- Modern dark UI: زوايا مدورة، شفافية، Elevation/Shadow.
- تبقى الميزات الأساسية: Pin Drop, Radar proxy, Clay/Iron, SQLite, KML/CSV, Vein Tracker, Safety, XYZ.

ملاحظة: Overzoom يثبت الرؤية فقط، ولا يزيد الدقة الحقيقية لمصدر البلاطات.
