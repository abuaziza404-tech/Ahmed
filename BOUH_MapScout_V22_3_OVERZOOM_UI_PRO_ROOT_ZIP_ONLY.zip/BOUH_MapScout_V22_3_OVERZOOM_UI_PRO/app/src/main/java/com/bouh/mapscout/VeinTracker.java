
package com.bouh.mapscout;

import org.osmdroid.util.GeoPoint;
import java.util.Locale;

public class VeinTracker {
    private GeoPoint a, b;

    public void push(GeoPoint p) {
        if(a == null) a = p;
        else b = p;
    }

    public String report() {
        if(a == null || b == null) return "Vein: أسقط دبوسين لحساب امتداد العرق.";
        double br = bearing(a.getLatitude(), a.getLongitude(), b.getLatitude(), b.getLongitude());
        double d = distance(a.getLatitude(), a.getLongitude(), b.getLatitude(), b.getLongitude());
        return String.format(Locale.US, "Vein: اتجاه %.0f° | مسافة %.1fm.", br, d);
    }

    private double bearing(double lat1, double lon1, double lat2, double lon2) {
        double p1=Math.toRadians(lat1), p2=Math.toRadians(lat2), dl=Math.toRadians(lon2-lon1);
        double y=Math.sin(dl)*Math.cos(p2);
        double x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl);
        return (Math.toDegrees(Math.atan2(y,x))+360)%360;
    }

    private double distance(double lat1, double lon1, double lat2, double lon2) {
        double R=6371000, p1=Math.toRadians(lat1), p2=Math.toRadians(lat2);
        double dp=Math.toRadians(lat2-lat1), dl=Math.toRadians(lon2-lon1);
        double a=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
        return 2*R*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }
}
