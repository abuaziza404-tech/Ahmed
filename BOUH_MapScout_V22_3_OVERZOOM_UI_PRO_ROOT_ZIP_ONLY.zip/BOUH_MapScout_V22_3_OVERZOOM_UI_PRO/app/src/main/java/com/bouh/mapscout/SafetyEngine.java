
package com.bouh.mapscout;

import java.util.Locale;

public class SafetyEngine {
    public String warning(RadarEngine.Report r) {
        if(r.flood > 0.72) return String.format(Locale.US, "⚠ تحذير سيول %.0f%%: ابتعد عن بطن الوادي.", r.flood*100);
        if(r.flood > 0.45) return String.format(Locale.US, "تنبيه مجاري %.0f%%: افحص مخارج الشعاب.", r.flood*100);
        return "مخاطر السيول منخفضة حسب النموذج المحلي.";
    }
}
