
package com.bouh.mapscout;

import java.util.Locale;

public class RadarEngine {
    public static class Report {
        public double bedrockM, paleochannel, roughness, flood;
        public String text;
    }

    public Report analyze(double lat, double lon, boolean structure, boolean carrier, boolean trap) {
        double seed = Math.abs(Math.sin(lat * 12.9898 + lon * 78.233) * 43758.5453);
        double n1 = frac(seed), n2 = frac(seed * 1.618), n3 = frac(seed * 2.414);
        Report r = new Report();
        r.roughness = clamp(0.18 + n1 * 0.76, 0, 1);
        r.paleochannel = clamp(0.20 + n2 * 0.50 + (trap ? 0.18 : 0) + (structure ? 0.05 : 0), 0, 0.98);
        r.bedrockM = 0.7 + (1.0 - r.roughness) * 4.2 + n3 * 2.0 + (trap ? 0.6 : 0);
        r.flood = clamp(0.20 + n3 * 0.55 + (trap ? 0.20 : 0), 0, 0.98);
        String grade = r.paleochannel > 0.70 ? "مرتفع" : r.paleochannel > 0.45 ? "متوسط" : "منخفض";
        r.text = String.format(Locale.US,
                "Bedrock %.1fm  |  Paleochannel %.0f%% %s\nSAR roughness %.0f%%  |  Flood %.0f%%\nGPR ▓▓▓░░ / Paleo ▓▓▓▓░ / Drainage ▓▓░░",
                r.bedrockM, r.paleochannel*100, grade, r.roughness*100, r.flood*100);
        return r;
    }

    private double frac(double v) { return v - Math.floor(v); }
    private double clamp(double v, double a, double b) { return Math.max(a, Math.min(b, v)); }
}
