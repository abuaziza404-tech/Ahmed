
package com.bouh.mapscout;

public class RemoteSensingEngine {
    public enum Mode { NATURAL, CLAY, IRON }

    public static String formula(Mode m) {
        if(m == Mode.CLAY) return "Clay mode: SWIR clay/alteration proxy يحتاج GeoTIFF/JP2 باندات خام.";
        if(m == Mode.IRON) return "Iron mode: iron oxide proxy يحتاج Reflectance bands وليس صورة خريطة.";
        return "Natural mode.";
    }
}
