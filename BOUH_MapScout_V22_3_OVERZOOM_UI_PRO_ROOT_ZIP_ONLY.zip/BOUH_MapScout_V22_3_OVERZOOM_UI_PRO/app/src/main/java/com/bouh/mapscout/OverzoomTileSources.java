
package com.bouh.mapscout;

import org.osmdroid.tileprovider.tilesource.XYTileSource;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.util.MapTileIndex;

/**
 * Overzoom source:
 * - MapView may request z18..z22.
 * - URL request is clamped to nativeMaxZoom.
 * - x/y are shifted to the parent tile.
 * This prevents blank/disappearing layers when the server has no tiles above native max.
 * It is a visual fallback, not true higher-resolution data.
 */
public final class OverzoomTileSources {
    private OverzoomTileSources() {}

    public static OnlineTileSourceBase esriSatellite() {
        return overzoomXYZ(
                "Esri Satellite Overzoom",
                "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
                19,
                22,
                ".jpg"
        );
    }

    public static OnlineTileSourceBase osmRoads() {
        return overzoomXYZ(
                "OSM Roads Overzoom",
                "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
                19,
                22,
                ".png"
        );
    }

    public static OnlineTileSourceBase openTopo() {
        return overzoomXYZ(
                "OpenTopo Overzoom",
                "https://a.tile.opentopomap.org/{z}/{x}/{y}.png",
                17,
                22,
                ".png"
        );
    }

    public static OnlineTileSourceBase cartoLight() {
        return overzoomXYZ(
                "Carto Light Overzoom",
                "https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png",
                20,
                22,
                ".png"
        );
    }

    public static OnlineTileSourceBase customOverzoom(final String name, final String template, final int nativeMaxZoom, final int displayMaxZoom) {
        return overzoomXYZ(name, template, nativeMaxZoom, displayMaxZoom, ".png");
    }

    public static OnlineTileSourceBase overzoomXYZ(final String name, final String template, final int nativeMaxZoom, final int displayMaxZoom, final String ext) {
        return new XYTileSource(name, 0, displayMaxZoom, 256, ext, new String[]{template}) {
            @Override public String getTileURLString(long idx) {
                int reqZ = MapTileIndex.getZoom(idx);
                int reqX = MapTileIndex.getX(idx);
                int reqY = MapTileIndex.getY(idx);

                int z = Math.min(reqZ, nativeMaxZoom);
                int shift = Math.max(0, reqZ - nativeMaxZoom);
                int x = shift == 0 ? reqX : (reqX >> shift);
                int y = shift == 0 ? reqY : (reqY >> shift);

                return template
                        .replace("{z}", String.valueOf(z))
                        .replace("{x}", String.valueOf(x))
                        .replace("{y}", String.valueOf(y));
            }
        };
    }
}
