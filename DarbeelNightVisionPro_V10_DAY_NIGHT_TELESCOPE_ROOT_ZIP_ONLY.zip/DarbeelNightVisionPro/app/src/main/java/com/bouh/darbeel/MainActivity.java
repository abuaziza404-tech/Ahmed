package com.bouh.darbeel;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import android.location.*;
import android.util.Range;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Semaphore;

public class MainActivity extends Activity implements SensorEventListener, LocationListener {
    private static final int REQ = 4047;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private ImageReader reader;
    private HandlerThread camThread;
    private Handler camHandler;
    private ProcessingView view;
    private String cameraId;
    private CaptureRequest.Builder previewBuilder;
    private CameraCharacteristics cameraChars;
    private final Semaphore cameraLock = new Semaphore(1);
    private int mode = 0, range = 2, lens = 0;
    private boolean dayCore = false, hdrDay = true, heatShield = true, shadowReveal = true;
    private float zoom = 1.0f, gain = 1.35f, gamma = 0.72f, contrast = 1.20f, detail = 0.55f, denoise = 0.35f, dehaze = 0.25f, blackLift = 24f;
    private boolean tripod = false, torch = false, autoBrain = true, photonStack = true, superRange = true, manualSensor = true, hardLift = true;
    private int isoLevel = 2, exposureLevel = 2;
    private long lastFrameNs=0; private float fps=0;
    private Bitmap latestBitmap;
    private int[] prevY;
    private int[] stackY; private int stackCount=0;
    private float heading=0, altitude=0; private double lat=0, lon=0; private boolean hasLoc=false;
    private SensorManager sensorManager; private LocationManager locationManager;
    private final String[] modes = {"REAL DETAIL", "PHOTON STACK", "TELESCOPE FAR", "STARLIGHT LIFT", "DUST/FOG CUT", "DESERT NATURAL", "EDGE LOCK", "IR READY", "B/W HARD LIFT", "TRUE COLOR LIFT", "DAY TRUE HDR", "SUN GLARE CUT", "SHADOW REVEAL", "ROCK DETAIL", "HEAT HAZE CUT", "LONG DAY SCOPE"};
    private final String[] ranges = {"NEAR", "MID", "FAR", "EXTREME"};
    private final String[] lenses = {"PHONE", "CLIP 3X", "CLIP 5X", "SCOPE 10X"};

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); buildUi(); sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE); locationManager=(LocationManager)getSystemService(LOCATION_SERVICE); if(Build.VERSION.SDK_INT>=23 && (checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)){requestPermissions(new String[]{Manifest.permission.CAMERA,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION}, REQ);} }
    @Override public void onResume(){ super.onResume(); startThreads(); openCamera(); Sensor s=sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION); if(s!=null) sensorManager.registerListener(this,s,SensorManager.SENSOR_DELAY_UI); try{ if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1500,1,this);}catch(Exception ignored){} }
    @Override public void onPause(){ closeCamera(); if(sensorManager!=null) sensorManager.unregisterListener(this); try{locationManager.removeUpdates(this);}catch(Exception ignored){} stopThreads(); super.onPause(); }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g); openCamera();}

    private void buildUi(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK); view=new ProcessingView(this); root.addView(view,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout side=new LinearLayout(this); side.setOrientation(LinearLayout.VERTICAL); side.setPadding(12,12,12,12); side.setAlpha(0.88f);
        String[] labels={"MODE","DAY/NIGHT","HDR DAY","GLARE CUT","SHADOW","RANGE","LENS","ZOOM+","ZOOM-","ISO+","ISO-","EXP+","EXP-","LIFT+","LIFT-","DETAIL+","DETAIL-","DENOISE+","STACK","SUPER RANGE","MANUAL SENSOR","TRIPOD","TORCH","CAPTURE"};
        for(String l:labels){ Button bt=new Button(this); bt.setText(l); bt.setTextSize(10); bt.setAllCaps(false); bt.setPadding(6,3,6,3); bt.setOnClickListener(v->handleButton(((Button)v).getText().toString())); side.addView(bt,new LinearLayout.LayoutParams(dp(118),dp(34))); }
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(128),-2,Gravity.RIGHT|Gravity.CENTER_VERTICAL); root.addView(side,sp);
        TextView title=new TextView(this); title.setText("BOUH DARBEEL V10 DAY-NIGHT TELESCOPE PRO  •  Ahmed Abu Aziza"); title.setTextColor(Color.rgb(230,210,130)); title.setShadowLayer(3,1,1,Color.BLACK); title.setTextSize(13); title.setPadding(16,10,16,10); root.addView(title,new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT));
        TextView hint=new TextView(this); hint.setText("Day/Night Pro: dark-breaker night core + daylight HDR + glare cut + heat-haze/detail recovery."); hint.setTextColor(Color.LTGRAY); hint.setTextSize(10); hint.setPadding(16,0,16,16); root.addView(hint,new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.LEFT));
        setContentView(root);
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);} 
    private void handleButton(String l){ if(l.equals("MODE")) mode=(mode+1)%modes.length; else if(l.equals("DAY/NIGHT")){dayCore=!dayCore; if(dayCore){manualSensor=false; gain=1.0f; gamma=0.96f; contrast=1.08f; blackLift=0f; if(mode<10) mode=10;} else {manualSensor=true; if(mode>=10) mode=0;} applyCameraControls();} else if(l.equals("HDR DAY")){hdrDay=!hdrDay; if(hdrDay && mode<10) mode=10;} else if(l.equals("GLARE CUT")){heatShield=!heatShield; if(mode<10) mode=11;} else if(l.equals("SHADOW")){shadowReveal=!shadowReveal; if(mode<10) mode=12;} else if(l.equals("RANGE")) range=(range+1)%ranges.length; else if(l.equals("LENS")) lens=(lens+1)%lenses.length; else if(l.equals("ZOOM+")) zoom=Math.min(8f,zoom+0.35f); else if(l.equals("ZOOM-")) zoom=Math.max(1f,zoom-0.35f); else if(l.equals("GAIN+")) gain=Math.min(4.8f,gain+0.18f); else if(l.equals("GAIN-")) gain=Math.max(0.7f,gain-0.18f); else if(l.equals("ISO+")){isoLevel=Math.min(5,isoLevel+1); applyCameraControls();} else if(l.equals("ISO-")){isoLevel=Math.max(0,isoLevel-1); applyCameraControls();} else if(l.equals("EXP+")){exposureLevel=Math.min(5,exposureLevel+1); applyCameraControls();} else if(l.equals("EXP-")){exposureLevel=Math.max(0,exposureLevel-1); applyCameraControls();} else if(l.equals("LIFT+")) blackLift=Math.min(90f,blackLift+8f); else if(l.equals("LIFT-")) blackLift=Math.max(0f,blackLift-8f); else if(l.equals("DETAIL+")) detail=Math.min(1.4f,detail+0.12f); else if(l.equals("DENOISE+")) denoise=denoise>0.85f?0.1f:denoise+0.12f; else if(l.equals("DETAIL-")) detail=Math.max(0.05f,detail-0.12f); else if(l.equals("STACK")){photonStack=!photonStack; stackY=null; stackCount=0;} else if(l.equals("SUPER RANGE")) superRange=!superRange; else if(l.equals("MANUAL SENSOR")){manualSensor=!manualSensor; applyCameraControls();} else if(l.equals("TRIPOD")) tripod=!tripod; else if(l.equals("TORCH")){torch=!torch; applyTorch();} else if(l.equals("CAPTURE")) saveCapture(); view.invalidate(); }

    private void startThreads(){ camThread=new HandlerThread("BOUH-Camera"); camThread.start(); camHandler=new Handler(camThread.getLooper()); }
    private void stopThreads(){ if(camThread!=null){camThread.quitSafely(); try{camThread.join();}catch(Exception ignored){} camThread=null; camHandler=null;} }
    private void openCamera(){ if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) return; try{ CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE); cameraId=cm.getCameraIdList()[0]; for(String id:cm.getCameraIdList()){CameraCharacteristics cc=cm.getCameraCharacteristics(id); Integer facing=cc.get(CameraCharacteristics.LENS_FACING); if(facing!=null && facing==CameraCharacteristics.LENS_FACING_BACK){cameraId=id; break;}} reader=ImageReader.newInstance(960,540,ImageFormat.YUV_420_888,3); reader.setOnImageAvailableListener(this::onImage,camHandler); cameraLock.acquire(); cameraChars=cm.getCameraCharacteristics(cameraId); cm.openCamera(cameraId,new CameraDevice.StateCallback(){ public void onOpened(CameraDevice c){cameraLock.release(); camera=c; createSession();} public void onDisconnected(CameraDevice c){cameraLock.release(); c.close(); camera=null;} public void onError(CameraDevice c,int e){cameraLock.release(); c.close(); camera=null;}},camHandler);}catch(Exception e){Toast.makeText(this,"Camera error: "+e.getMessage(),Toast.LENGTH_LONG).show();} }
    private void closeCamera(){ try{cameraLock.acquire(); if(session!=null){session.close(); session=null;} if(camera!=null){camera.close(); camera=null;} if(reader!=null){reader.close(); reader=null;}}catch(Exception ignored){} finally{cameraLock.release();} }
    private void createSession(){ try{ previewBuilder=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW); previewBuilder.addTarget(reader.getSurface()); applyCameraControlsToBuilder(previewBuilder); camera.createCaptureSession(Collections.singletonList(reader.getSurface()),new CameraCaptureSession.StateCallback(){ public void onConfigured(CameraCaptureSession s){session=s; try{applyCameraControls();}catch(Exception ignored){}} public void onConfigureFailed(CameraCaptureSession s){}},camHandler);}catch(Exception ignored){} }
    private void applyTorch(){ applyCameraControls(); }
    private void applyCameraControls(){ try{ if(camera==null||session==null||reader==null) return; previewBuilder=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW); previewBuilder.addTarget(reader.getSurface()); applyCameraControlsToBuilder(previewBuilder); session.setRepeatingRequest(previewBuilder.build(),null,camHandler);}catch(Exception ignored){} }
    private void applyCameraControlsToBuilder(CaptureRequest.Builder b){ try{
            b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            b.set(CaptureRequest.FLASH_MODE, torch?CaptureRequest.FLASH_MODE_TORCH:CaptureRequest.FLASH_MODE_OFF);
            if(manualSensor){
                b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
                int[] isoSteps={400,800,1600,2400,3200,4800}; long[] expSteps={33333333L,66666666L,100000000L,125000000L,166666666L,250000000L};
                int iso=isoSteps[Math.max(0,Math.min(5,isoLevel))]; long exp=expSteps[Math.max(0,Math.min(5,exposureLevel))];
                if(cameraChars!=null){ Range<Integer> sr=cameraChars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE); if(sr!=null) iso=Math.max(sr.getLower(),Math.min(sr.getUpper(),iso)); Range<Long> er=cameraChars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE); if(er!=null) exp=Math.max(er.getLower(),Math.min(er.getUpper(),exp)); }
                b.set(CaptureRequest.SENSOR_SENSITIVITY, iso); b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp);
            } else { b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON); }
        }catch(Exception ignored){} }
    private int currentIso(){int[] isoSteps={400,800,1600,2400,3200,4800}; return isoSteps[Math.max(0,Math.min(5,isoLevel))];}
    private long currentExpMs(){long[] expSteps={33,66,100,125,166,250}; return expSteps[Math.max(0,Math.min(5,exposureLevel))];}

    private void onImage(ImageReader ir){ Image img=null; try{img=ir.acquireLatestImage(); if(img==null) return; long now=System.nanoTime(); if(lastFrameNs>0) fps=0.90f*fps+0.10f*(1_000_000_000f/(now-lastFrameNs)); lastFrameNs=now; processYuv(img); }catch(Exception ignored){} finally{ if(img!=null) img.close(); } }
    private void processYuv(Image img){ int w=img.getWidth(), h=img.getHeight(); Image.Plane yp=img.getPlanes()[0]; ByteBuffer yb=yp.getBuffer(); int stride=yp.getRowStride(); int[] out=new int[w*h]; int[] yarr=new int[w*h]; byte[] row=new byte[stride]; for(int yy=0;yy<h;yy++){ yb.position(yy*stride); yb.get(row,0,Math.min(stride,yb.remaining()+stride)); for(int x=0;x<w;x++){yarr[yy*w+x]=row[x]&255;} }
        int[] histStats=histogramStats(yarr); autoTune(yarr,w,h,histStats); int lo=histStats[0], hi=histStats[1]; if(hi<=lo+8){ hi=lo+32; } int den=(int)(denoise*100); boolean usePrev=prevY!=null && prevY.length==yarr.length; int rBoost = (range==3?18:range==2?10:0) + (lens==3?8:lens==2?5:0); for(int y=1;y<h-1;y++){ int off=y*w; for(int x=1;x<w-1;x++){ int i=off+x; int rawv=yarr[i]; int v=(rawv-lo)*255/(hi-lo); v=clamp((int)(v+blackLift)); if(usePrev){ v=(v*(100-den)+prevY[i]*den)/100; }
                if(photonStack || tripod || mode==1){
                    if(stackY!=null && stackY.length==yarr.length){
                        int oldStack=stackY[i];
                        int weight = tripod ? 7 : 4;
                        v = (v*weight + oldStack*(10-weight))/10;
                    }
                }
                int lap = (v*4 - yarr[i-1]-yarr[i+1]-yarr[i-w]-yarr[i+w]);
                int diag=(yarr[i-w-1]+yarr[i-w+1]+yarr[i+w-1]+yarr[i+w+1])/4;
                int localRaw=(yarr[i-1]+yarr[i+1]+yarr[i-w]+yarr[i+w]+diag)/5; int local=(localRaw-lo)*255/(hi-lo); local=clamp(local);
                float dx=(x-w*0.5f)/(w*0.5f), dy=(y-h*0.5f)/(h*0.5f);
                float centerWeight=1.0f - Math.min(0.55f,(dx*dx+dy*dy)*0.35f);
                int contrastLift=(int)((v-128)*(contrast + (superRange?0.12f:0f))*centerWeight+128);
                int deh=(int)(v + dehaze*(v-local));
                int farBoost = (superRange && (mode==2 || range>=2)) ? (int)(Math.abs(lap)*0.22f + (128-Math.abs(v-128))*0.03f) : 0;
                int vv=(int)(contrastLift*0.48 + deh*0.40 + lap*detail*centerWeight + farBoost);
                vv=(int)(Math.pow(Math.max(0,Math.min(255,vv))/255.0, gamma)*255.0*gain)+rBoost; if(mode==8){vv=clamp((int)(vv*1.32f+38));} if(mode==9){vv=clamp((int)(vv*1.18f+24));}
                vv=Math.max(0,Math.min(255,vv)); int color=mapModeColor(vv, v, lap); out[i]=color; } }
        if((photonStack||tripod||mode==1) && (stackY==null || stackY.length!=yarr.length)){ stackY=new int[yarr.length]; System.arraycopy(yarr,0,stackY,0,yarr.length); stackCount=1; }
        else if(photonStack||tripod||mode==1){ int keep=tripod?8:5; for(int i=0;i<yarr.length;i++){ stackY[i]=(stackY[i]*(keep-1)+yarr[i])/keep; } stackCount=Math.min(99,stackCount+1); }
        prevY=outToY(out); latestBitmap=Bitmap.createBitmap(out,w,h,Bitmap.Config.ARGB_8888); runOnUiThread(()->view.setFrame(latestBitmap)); }
    private int[] histogramStats(int[] y){ int[] hist=new int[256]; for(int i=0;i<y.length;i+=3) hist[y[i]&255]++; int total=y.length/3, c=0, lo=0, hi=255; int loTarget=Math.max(1,total/100), hiTarget=Math.max(1,total*985/1000); for(int i=0;i<256;i++){c+=hist[i]; if(c>=loTarget){lo=i;break;}} c=0; for(int i=0;i<256;i++){c+=hist[i]; if(c>=hiTarget){hi=i;break;}} return new int[]{lo,hi}; }
    private int[] outToY(int[] argb){ int[] y=new int[argb.length]; for(int i=0;i<argb.length;i++){ y[i]=argb[i]&255; } return y; }
    private void autoTune(int[] y,int w,int h,int[] st){ if(!autoBrain) return; long sum=0; int step=7; for(int i=0;i<y.length;i+=step) sum+=y[i]; float mean=sum/(float)(y.length/step); int spread=st[1]-st[0]; if(dayCore || mode>=10){
            manualSensor=false;
            gain=1.00f; gamma=0.98f; contrast=1.10f; denoise=0.18f; detail=0.62f; blackLift=0f; dehaze=heatShield?0.42f:0.18f;
            if(mean>175){ gamma=1.08f; contrast=1.22f; detail=0.70f; dehaze=0.62f; }
            if(mean<95 && shadowReveal){ gamma=0.78f; gain=1.18f; blackLift=12f; contrast=1.18f; }
            if(spread<55 && hdrDay){ contrast+=0.28f; detail+=0.22f; }
            if(mode==11){ dehaze=0.82f; contrast+=0.18f; gamma=1.12f; }
            if(mode==12){ gamma=0.70f; gain=1.25f; blackLift=22f; detail+=0.18f; }
            if(mode==13){ detail=0.98f; contrast=1.28f; dehaze=0.38f; }
            if(mode==14){ dehaze=0.90f; denoise=0.30f; detail=0.78f; }
            if(mode==15 || range>=2){ detail+=0.25f; dehaze+=0.18f; contrast+=0.10f; }
            return;
        }
        if(mean<22){gain=3.95f; gamma=0.34f; contrast=1.82f; denoise=tripod?0.68f:0.44f; detail=0.92f; blackLift=hardLift?62f:blackLift;} else if(mean<45){gain=3.15f; gamma=0.44f; contrast=1.62f; denoise=tripod?0.64f:0.40f; detail=0.82f; blackLift=hardLift?48f:blackLift;} else if(mean<75){gain=2.15f; gamma=0.58f; contrast=1.38f; detail=0.70f; blackLift=hardLift?30f:blackLift;} else {gain=1.18f; gamma=0.86f; contrast=1.12f; detail=0.48f; blackLift=hardLift?12f:blackLift;} if(spread<28){contrast+=0.22f; detail+=0.18f; dehaze=0.58f;} if(mode==1 || mode==2 || range>=2){dehaze=0.54f; detail+=0.24f; contrast+=0.10f;} if(mode==4){dehaze=0.86f; contrast+=0.24f;} if(superRange && range>=2){detail+=0.20f; gamma=Math.max(0.34f,gamma-0.06f);} }
    private int mapModeColor(int vv,int raw,int lap){ if(mode>=10){ int r=vv,g=vv,b=vv; if(mode==10){ r=clamp((int)(vv*1.04)); g=clamp((int)(vv*1.02)); b=clamp((int)(vv*0.96)); } else if(mode==11){ r=clamp((int)(vv*0.96)); g=clamp((int)(vv*1.02)); b=clamp((int)(vv*1.08)); } else if(mode==12){ r=clamp((int)(vv*1.10)); g=clamp((int)(vv*1.05)); b=clamp((int)(vv*0.92)); } else if(mode==13){ int e=clamp(vv+Math.abs(lap)); r=clamp((int)(e*1.08)); g=clamp((int)(e*1.02)); b=clamp((int)(e*0.88)); } else if(mode==14){ r=clamp((int)(vv*0.94)); g=clamp((int)(vv*1.00)); b=clamp((int)(vv*1.05)); } else if(mode==15){ int c=clamp((int)(vv*1.05+Math.abs(lap)*0.35)); r=c; g=c; b=c; } return Color.rgb(r,g,b); } if(mode==5){ return Color.rgb(clamp((int)(vv*1.08)),clamp((int)(vv*1.01)),clamp((int)(vv*0.84))); } if(mode==6){ int e=clamp(Math.abs(lap)*3); return Color.rgb(e,e,e); } if(mode==7){ return Color.rgb(clamp((int)(vv*1.15)),clamp((int)(vv*0.75)),clamp((int)(vv*0.55))); } if(mode==9){return Color.rgb(clamp((int)(vv*1.06)),clamp((int)(vv*1.02)),clamp((int)(vv*0.92)));} if(mode==3){ int c=clamp((int)(vv*1.15)); return Color.rgb(c,c,clamp((int)(c*0.92))); } return Color.rgb(vv,vv,vv); }
    private int clamp(int v){return Math.max(0,Math.min(255,v));}

    private void saveCapture(){ try{ if(latestBitmap==null) return; String ts=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date()); ContentValues cv=new ContentValues(); cv.put(MediaStore.Images.Media.DISPLAY_NAME,"BOUH_DARBEEL_V10_"+ts+".jpg"); cv.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg"); cv.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/BOUH_Darbeel_V10_DayNight"); Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv); OutputStream os=getContentResolver().openOutputStream(uri); latestBitmap.compress(Bitmap.CompressFormat.JPEG,94,os); os.close(); Toast.makeText(this,"Saved V10 Day-Night capture",Toast.LENGTH_SHORT).show(); }catch(Exception e){Toast.makeText(this,"Save failed: "+e.getMessage(),Toast.LENGTH_LONG).show();} }

    @Override public void onSensorChanged(SensorEvent e){ heading=e.values[0]; view.invalidate(); }
    @Override public void onAccuracyChanged(Sensor s,int a){}
    @Override public void onLocationChanged(Location l){ lat=l.getLatitude(); lon=l.getLongitude(); altitude=(float)l.getAltitude(); hasLoc=true; view.invalidate(); }

    public class ProcessingView extends View{ private Bitmap frame; private Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); public ProcessingView(Context c){super(c);} public void setFrame(Bitmap b){frame=b; invalidate();}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); int W=getWidth(),H=getHeight(); if(frame!=null){ Rect src=new Rect(0,0,frame.getWidth(),frame.getHeight()); float z=zoom*(lens==1?1.18f:lens==2?1.38f:lens==3?1.70f:1f); int dw=(int)(frame.getWidth()/z), dh=(int)(frame.getHeight()/z); src.set((frame.getWidth()-dw)/2,(frame.getHeight()-dh)/2,(frame.getWidth()+dw)/2,(frame.getHeight()+dh)/2); c.drawBitmap(frame,src,new Rect(0,0,W,H),null);} else {c.drawColor(Color.BLACK);} drawHud(c,W,H); }
        private void drawHud(Canvas c,int W,int H){ p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.argb(140,230,210,130)); float cx=W/2f, cy=H/2f, r=Math.min(W,H)*0.30f; c.drawCircle(cx,cy,r,p); c.drawLine(cx-r*0.72f,cy,cx-r*0.16f,cy,p); c.drawLine(cx+r*0.16f,cy,cx+r*0.72f,cy,p); c.drawLine(cx,cy-r*0.72f,cx,cy-r*0.16f,p); c.drawLine(cx,cy+r*0.16f,cx,cy+r*0.72f,p);
            p.setStyle(Paint.Style.FILL); p.setTextSize(24); p.setColor(Color.argb(225,245,235,180)); c.drawText(String.format(Locale.US,"FPS %.0f | %s | %s | %s | Z %.1fx",fps,modes[mode],ranges[range],lenses[lens],zoom),18,58,p); p.setTextSize(20); c.drawText(String.format(Locale.US,"ISO %d EXP %dms | GAIN %.2f GAMMA %.2f DETAIL %.2f LIFT %.0f",currentIso(),currentExpMs(),gain,gamma,detail,blackLift),18,88,p); p.setTextSize(18); String loc=hasLoc?String.format(Locale.US,"GPS %.5f, %.5f  ALT %.0fm",lat,lon,altitude):"GPS searching"; c.drawText(String.format(Locale.US,"HDG %.0f°  %s  CORE %s  HDR %s  GLARE %s  SENSOR %s",heading,loc,dayCore?"DAY":"NIGHT",hdrDay?"ON":"OFF",heatShield?"ON":"OFF",manualSensor?"MANUAL":"AUTO"),18,H-28,p); }
    }
}
