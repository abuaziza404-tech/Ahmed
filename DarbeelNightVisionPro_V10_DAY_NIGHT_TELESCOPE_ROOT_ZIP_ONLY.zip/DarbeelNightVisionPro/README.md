# BOUH Darbeel V10 Day-Night Telescope Pro

Android Camera2 telescope/night/day detail system.

## V10 additions
- Day/Night core switch
- Day TRUE HDR mode
- Sun glare cut
- Shadow reveal
- Rock detail / terrain detail
- Heat haze cut
- Long day scope
- Existing V9 dark-breaker: ISO/exposure/manual sensor, photon stack, telescope far, starlight lift.

Upload ZIP at repository root and run GitHub Actions workflow.
