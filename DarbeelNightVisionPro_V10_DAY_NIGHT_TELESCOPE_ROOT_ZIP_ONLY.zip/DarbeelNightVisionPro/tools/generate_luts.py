import json, math, pathlib
out = pathlib.Path('app/src/main/assets/bouh_v10_daynight_luts.json')
out.parent.mkdir(parents=True, exist_ok=True)
profiles = {}
for name, gamma, gain, lift in [
    ('night_real_detail',0.70,1.65,18), ('dark_breaker',0.38,3.20,56),
    ('starlight_lift',0.32,3.80,70), ('long_range_bw',0.55,2.20,34),
    ('day_true_hdr',0.98,1.00,0), ('sun_glare_cut',1.12,0.94,-4),
    ('shadow_reveal',0.72,1.18,16), ('rock_detail',0.92,1.08,2),
    ('heat_haze_cut',1.05,0.98,0), ('long_day_scope',0.96,1.04,0)]:
    lut=[max(0,min(255, int((math.pow(i/255.0,gamma)*255*gain)+lift))) for i in range(256)]
    profiles[name]={'gamma':gamma,'gain':gain,'lift':lift,'lut':lut}
out.write_text(json.dumps({'engine':'BOUH Darbeel V10 Day-Night Telescope Pro','profiles':profiles}, indent=2))
print(out)
