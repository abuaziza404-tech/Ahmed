import pathlib, numpy as np, cv2
root=pathlib.Path('build/vision-test'); root.mkdir(parents=True, exist_ok=True)
h,w=420,720
rng=np.random.default_rng(1447)
# Night dark recovery test
base=np.zeros((h,w),np.uint8)+8
cv2.putText(base,'BOUH NIGHT TEST',(45,100),cv2.FONT_HERSHEY_SIMPLEX,1.4,34,3)
cv2.circle(base,(530,250),70,22,-1)
cv2.line(base,(30,360),(690,300),28,2)
noise=rng.normal(0,9,(h,w)).astype(np.int16)
dark=np.clip(base.astype(np.int16)+noise,0,255).astype(np.uint8)
lo,hi=np.percentile(dark,[1,98.5])
stretch=np.clip((dark.astype(np.float32)-lo)*255/(hi-lo+1),0,255).astype(np.uint8)
stretch=np.clip((stretch.astype(np.float32)**0.42)/(255**0.42)*255*1.25+25,0,255).astype(np.uint8)
night=cv2.addWeighted(stretch,1.7,cv2.GaussianBlur(stretch,(0,0),2.2),-0.7,0)
# Day glare/shadow detail test
day=np.tile(np.linspace(35,235,w,dtype=np.uint8),(h,1))
cv2.rectangle(day,(35,160),(250,350),50,-1)   # shadow block
cv2.rectangle(day,(450,50),(700,220),245,-1)  # glare block
cv2.putText(day,'DAY ROCK DETAIL',(70,120),cv2.FONT_HERSHEY_SIMPLEX,1.15,120,3)
day=np.clip(day.astype(np.int16)+rng.normal(0,8,(h,w)).astype(np.int16),0,255).astype(np.uint8)
clahe=cv2.createCLAHE(clipLimit=2.2, tileGridSize=(8,8)).apply(day)
dayrec=cv2.addWeighted(clahe,1.45,cv2.GaussianBlur(clahe,(0,0),1.8),-0.45,0)
cv2.imwrite(str(root/'v10_night_input_dark.png'),dark)
cv2.imwrite(str(root/'v10_night_recovery.png'),night)
cv2.imwrite(str(root/'v10_day_input_glare_shadow.png'),day)
cv2.imwrite(str(root/'v10_day_hdr_recovery.png'),dayrec)
score_n=float(night.std())/(float(dark.std())+1e-6)
score_d=float(dayrec.std())/(float(day.std())+1e-6)
(root/'vision_score.txt').write_text(f'V10 night_contrast_gain={score_n:.3f}\nV10 day_detail_gain={score_d:.3f}\n')
print((root/'vision_score.txt').read_text())
