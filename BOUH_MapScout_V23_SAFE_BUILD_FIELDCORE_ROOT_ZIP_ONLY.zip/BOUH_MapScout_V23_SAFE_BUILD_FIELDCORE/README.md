# BOUH MapScout V23 Safe Build FieldCore

هذه نسخة إعادة بناء مستقرة من أساس V20/V21 الذي عمل بسرعة:
- Native osmdroid MapView.
- Infinite Overzoom Z24 with native Z17 clamp.
- GPS jitter filter 2m.
- Floating toolbar.
- Pin Drop.
- Radar proxy.
- Dynamic GPR/Paleo/Drainage bars.
- Fe/Q/P modes.
- SQLite waypoints.
- KML/CSV export.

تم تقليل التعقيد لتجنب أخطاء Java compile المتكررة في فروع V22.
