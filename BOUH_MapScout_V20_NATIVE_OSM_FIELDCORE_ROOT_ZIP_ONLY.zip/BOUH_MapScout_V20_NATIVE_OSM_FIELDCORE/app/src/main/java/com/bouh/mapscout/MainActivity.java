
package com.bouh.mapscout;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.view.Gravity;
import android.view.View;
import android.view.MotionEvent;
import android.widget.*;
import android.text.InputType;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.XYTileSource;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.MapTileIndex;
import org.osmdroid.views.MapView;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.ScaleBarOverlay;
import org.osmdroid.views.overlay.Polygon;
import org.osmdroid.views.overlay.Overlay;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private MapView map;
    private FrameLayout root;
    private TextView hud, card, title;
    private LocationManager locationManager;
    private GeoPoint gpsPoint = new GeoPoint(19.024271, 37.321768);
    private double altitude = 0;
    private float accuracy = -1;
    private boolean follow = false;

    private boolean structure = false, carrier = false, trap = false, feox = false;
    private int clarity = 0;
    private int sharpness = 0;
    private int contrast = 0;

    private ArrayList<Target> targets = new ArrayList<>();
    private ArrayList<Marker> targetMarkers = new ArrayList<>();

    private LinearLayout bottomBar, rightBar, layerPanel;
    private Button bStructure, bCarrier, bTrap, bFeox, bFollow, bClarity, bSharp, bContrast;
    private View clarityOverlay, crosshair;

    private final int GOLD = Color.rgb(246,216,143);
    private final int WHITE = Color.rgb(255,245,210);
    private final int PANEL = Color.argb(178, 0, 0, 0);

    static class Target {
        String time, decision, layer;
        double lat, lon, alt;
        float acc;
        double zoom;
        boolean structure, carrier, trap, feox;
        int score;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        Configuration.getInstance().setUserAgentValue("BOUH-MapScout-V20-Ahmed-Abu-Aziza");
        Configuration.getInstance().setTileFileSystemCacheMaxBytes(250L * 1024L * 1024L);
        Configuration.getInstance().setTileFileSystemCacheTrimBytes(180L * 1024L * 1024L);

        root = new FrameLayout(this);
        setContentView(root);

        buildMap();
        buildUi();
        requestLocation();

        analyze();
    }

    private void buildMap() {
        map = new MapView(this);
        map.setMultiTouchControls(true);
        map.getZoomController().setVisibility(CustomZoomButtonsController.Visibility.NEVER);
        map.setTilesScaledToDpi(true);
        map.setFlingEnabled(true);
        map.setMinZoomLevel(3.0);
        map.setMaxZoomLevel(19.0);
        map.setTileSource(esriSat());
        map.getController().setZoom(16.0);
        map.getController().setCenter(gpsPoint);
        root.addView(map, new FrameLayout.LayoutParams(-1, -1));

        ScaleBarOverlay scale = new ScaleBarOverlay(map);
        scale.setCentred(false);
        scale.setScaleBarOffset(18, getResources().getDisplayMetrics().heightPixels - 310);
        map.getOverlays().add(scale);

        crosshair = new View(this);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(Color.TRANSPARENT);
        gd.setStroke(dp(2), Color.argb(200, 255, 224, 139));
        crosshair.setBackground(gd);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER);
        root.addView(crosshair, cp);

        clarityOverlay = new View(this);
        clarityOverlay.setBackgroundColor(Color.TRANSPARENT);
        root.addView(clarityOverlay, new FrameLayout.LayoutParams(-1, -1));
        clarityOverlay.setClickable(false);
    }

    private OnlineTileSourceBase esriSat() {
        return new XYTileSource("Esri Satellite", 0, 19, 256, ".jpg",
            new String[]{"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"}) {
            @Override public String getTileURLString(long pMapTileIndex) {
                return getBaseUrl()
                    + MapTileIndex.getZoom(pMapTileIndex) + "/"
                    + MapTileIndex.getY(pMapTileIndex) + "/"
                    + MapTileIndex.getX(pMapTileIndex);
            }
        };
    }

    private OnlineTileSourceBase osmRoads() {
        return new XYTileSource("OSM Roads", 0, 19, 256, ".png",
            new String[]{"https://tile.openstreetmap.org/"}) {
            @Override public String getTileURLString(long pMapTileIndex) {
                return getBaseUrl()
                    + MapTileIndex.getZoom(pMapTileIndex) + "/"
                    + MapTileIndex.getX(pMapTileIndex) + "/"
                    + MapTileIndex.getY(pMapTileIndex) + ".png";
            }
        };
    }

    private OnlineTileSourceBase topo() {
        return new XYTileSource("OpenTopo", 0, 17, 256, ".png",
            new String[]{"https://a.tile.opentopomap.org/"}) {
            @Override public String getTileURLString(long pMapTileIndex) {
                return getBaseUrl()
                    + MapTileIndex.getZoom(pMapTileIndex) + "/"
                    + MapTileIndex.getX(pMapTileIndex) + "/"
                    + MapTileIndex.getY(pMapTileIndex) + ".png";
            }
        };
    }

    private OnlineTileSourceBase customXYZ(final String name, final String template, final int maxZoom) {
        return new XYTileSource(name, 0, maxZoom, 256, ".png", new String[]{template}) {
            @Override public String getTileURLString(long idx) {
                String z = String.valueOf(MapTileIndex.getZoom(idx));
                String x = String.valueOf(MapTileIndex.getX(idx));
                String y = String.valueOf(MapTileIndex.getY(idx));
                return template.replace("{z}", z).replace("{x}", x).replace("{y}", y);
            }
        };
    }

    private void buildUi() {
        title = label("BOUH MAPSCOUT V20  |  خرائط ميدانية سريعة", 14, true);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        tp.setMargins(dp(8), dp(7), dp(8), 0);
        root.addView(title, tp);

        hud = label("GPS...", 12, true);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        hp.setMargins(dp(8), dp(28), dp(8), 0);
        root.addView(hud, hp);

        card = label("محرك Native osmdroid: زوم بالأصابع + حركة أسرع + كاش بلاطات. فعّل بنية/حامل/مصيدة ثم تحليل.", 13, false);
        card.setBackground(roundBg(PANEL, GOLD));
        card.setPadding(dp(10), dp(8), dp(10), dp(8));
        card.setGravity(Gravity.RIGHT);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, dp(126), Gravity.BOTTOM);
        cp.setMargins(dp(8), 0, dp(8), dp(145));
        root.addView(card, cp);

        rightBar = new LinearLayout(this);
        rightBar.setOrientation(LinearLayout.VERTICAL);
        rightBar.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(dp(82), -2, Gravity.RIGHT | Gravity.TOP);
        rp.setMargins(0, dp(82), dp(7), 0);
        root.addView(rightBar, rp);
        rightBar.addView(btn("تكبير +", v -> map.getController().zoomIn()));
        rightBar.addView(btn("تصغير -", v -> map.getController().zoomOut()));
        bFollow = btn("تتبع", v -> toggleFollow());
        rightBar.addView(bFollow);
        rightBar.addView(btn("طبقات", v -> toggleLayerPanel()));

        LinearLayout leftBar = new LinearLayout(this);
        leftBar.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(86), -2, Gravity.LEFT | Gravity.TOP);
        lp.setMargins(dp(7), dp(82), 0, 0);
        root.addView(leftBar, lp);
        bClarity = btn("وضوح", v -> incClarity());
        bSharp = btn("حدة", v -> incSharpness());
        bContrast = btn("تباين", v -> incContrast());
        leftBar.addView(bClarity);
        leftBar.addView(bSharp);
        leftBar.addView(bContrast);
        leftBar.addView(btn("GPS", v -> centerGps()));

        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, dp(136), Gravity.BOTTOM);
        bp.setMargins(dp(7), 0, dp(7), dp(7));
        root.addView(bottomBar, bp);

        LinearLayout row1 = row();
        bStructure = btn("بنية", v -> { structure = !structure; analyze(); updateButtons(); });
        bCarrier = btn("حامل", v -> { carrier = !carrier; analyze(); updateButtons(); });
        bTrap = btn("مصيدة", v -> { trap = !trap; analyze(); updateButtons(); });
        bFeox = btn("FeOx", v -> { feox = !feox; analyze(); updateButtons(); });
        row1.addView(bStructure); row1.addView(bCarrier); row1.addView(bTrap); row1.addView(bFeox);

        LinearLayout row2 = row();
        row2.addView(btn("تحليل", v -> analyze()));
        row2.addView(btn("حفظ", v -> saveTarget()));
        row2.addView(btn("KML", v -> exportKml()));
        row2.addView(btn("CSV", v -> exportCsv()));

        bottomBar.addView(row1);
        bottomBar.addView(row2);

        buildLayerPanel();
        updateButtons();
        updateHud();
    }

    private void buildLayerPanel() {
        layerPanel = new LinearLayout(this);
        layerPanel.setOrientation(LinearLayout.VERTICAL);
        layerPanel.setPadding(dp(10), dp(10), dp(10), dp(10));
        layerPanel.setBackground(roundBg(Color.argb(225, 0,0,0), GOLD));
        layerPanel.setVisibility(View.GONE);

        TextView head = label("الطبقات والربط السحابي", 15, true);
        head.setGravity(Gravity.RIGHT);
        layerPanel.addView(head);

        LinearLayout r1 = row();
        r1.addView(btn("قمر HD", v -> { map.setTileSource(esriSat()); map.setMaxZoomLevel(19.0); toggleLayerPanel(); }));
        r1.addView(btn("طرق", v -> { map.setTileSource(osmRoads()); map.setMaxZoomLevel(19.0); toggleLayerPanel(); }));
        layerPanel.addView(r1);

        LinearLayout r2 = row();
        r2.addView(btn("تضاريس", v -> { map.setTileSource(topo()); map.setMaxZoomLevel(17.0); if(map.getZoomLevelDouble() > 17) map.getController().setZoom(17.0); toggleLayerPanel(); }));
        r2.addView(btn("كاش", v -> { Toast.makeText(this, "osmdroid cache enabled", Toast.LENGTH_SHORT).show(); }));
        layerPanel.addView(r2);

        final EditText custom = new EditText(this);
        custom.setHint("رابط XYZ: https://.../{z}/{x}/{y}.png");
        custom.setTextColor(Color.WHITE);
        custom.setHintTextColor(Color.rgb(210,190,140));
        custom.setSingleLine(false);
        custom.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        custom.setBackground(roundBg(Color.rgb(25,25,25), Color.argb(130,246,216,143)));
        custom.setPadding(dp(8), dp(8), dp(8), dp(8));
        layerPanel.addView(custom, new LinearLayout.LayoutParams(-1, dp(70)));

        LinearLayout r3 = row();
        r3.addView(btn("ربط XYZ", v -> {
            String url = custom.getText().toString().trim();
            if(!url.contains("{z}") || !url.contains("{x}") || !url.contains("{y}")) {
                Toast.makeText(this, "الرابط يجب أن يحتوي {z}/{x}/{y}", Toast.LENGTH_LONG).show();
                return;
            }
            map.setTileSource(customXYZ("BOUH Cloud XYZ", url, 20));
            map.setMaxZoomLevel(20.0);
            toggleLayerPanel();
        }));
        r3.addView(btn("إغلاق", v -> toggleLayerPanel()));
        layerPanel.addView(r3);

        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, dp(278), Gravity.TOP);
        pp.setMargins(dp(8), dp(82), dp(8), 0);
        root.addView(layerPanel, pp);
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        r.setWeightSum(4);
        return r;
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setPadding(1, 1, 1, 1);
        b.setBackground(roundBg(Color.argb(205, 16,16,16), Color.argb(135,246,216,143)));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(60), 1);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(p);
        return b;
    }

    private TextView label(String t, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(WHITE);
        v.setTextSize(size);
        v.setShadowLayer(4, 0, 1, Color.BLACK);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private GradientDrawable roundBg(int fill, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(12));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void toggleLayerPanel() {
        layerPanel.setVisibility(layerPanel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    private void toggleFollow() {
        follow = !follow;
        if (follow) centerGps();
        updateButtons();
    }

    private void centerGps() {
        map.getController().animateTo(gpsPoint);
        updateHud();
    }

    private void incClarity() {
        clarity = (clarity + 1) % 4;
        applyVisualEnhancement();
    }

    private void incSharpness() {
        sharpness = (sharpness + 1) % 4;
        applyVisualEnhancement();
    }

    private void incContrast() {
        contrast = (contrast + 1) % 4;
        applyVisualEnhancement();
    }

    private void applyVisualEnhancement() {
        // Lightweight visual enhancement: overlay changes perceived contrast without reprocessing map tiles.
        int alpha = Math.min(85, contrast * 18 + clarity * 10);
        if (alpha == 0) {
            clarityOverlay.setBackgroundColor(Color.TRANSPARENT);
        } else {
            // Very light warm dark overlay increases perceived terrain contrast on bright satellite imagery.
            clarityOverlay.setBackgroundColor(Color.argb(alpha, 20, 14, 0));
        }
        map.setAlpha(1.0f);
        map.setScaleX(1.0f + sharpness * 0.003f);
        map.setScaleY(1.0f + sharpness * 0.003f);

        bClarity.setText("وضوح " + clarity);
        bSharp.setText("حدة " + sharpness);
        bContrast.setText("تباين " + contrast);
    }

    private void updateButtons() {
        setOn(bStructure, structure);
        setOn(bCarrier, carrier);
        setOn(bTrap, trap);
        setOn(bFeox, feox);
        setOn(bFollow, follow);
        applyVisualEnhancement();
    }

    private void setOn(Button b, boolean on) {
        b.setBackground(roundBg(on ? Color.argb(230, 122, 92, 24) : Color.argb(205, 16,16,16), Color.argb(150,246,216,143)));
    }

    private void analyze() {
        int score = 0;
        ArrayList<String> notes = new ArrayList<>();
        if (structure) { score += 45; notes.add("✓ بنية/قص/خطية موجودة"); }
        else notes.add("✗ لا بنية: تعليق/رفض");
        if (carrier) { score += 35; notes.add("✓ حامل Quartz/Clay/Silica مثبت ميدانيًا أو ببيانات خام"); }
        else notes.add("✗ لا حامل: لا ترفع الهدف");
        if (trap) { score += 15; notes.add("✓ مصيدة وادي/قدم جبل/Pediment داعمة"); }
        if (feox) { score += 5; notes.add("FeOx داعم فقط وليس هدفًا مستقلًا"); }

        String cls;
        if (!structure || !carrier) cls = "REJECT / HOLD";
        else if (score >= 80) cls = "CLASS A";
        else if (score >= 60) cls = "CLASS B";
        else cls = "CLASS C";

        String gpz = score >= 60
            ? "GPZ: ضوضاء عالية = Difficult/High Yield/Sens 8-11. كوارتز وأرض هادئة = Normal/General-Deep/Sens 12-16."
            : "GPZ: لا تبدأ فحص عميق قبل Structure + Carrier.";

        card.setText(cls + " | Score " + score + "\n" + join(notes, "\n") + "\n" + gpz + "\nقاعدة الصدق: الخريطة للتوجيه؛ الطيف الرقمي يحتاج GeoTIFF/RAW/DEM.");
        updateButtons();
    }

    private String join(ArrayList<String> xs, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<xs.size(); i++) {
            if(i>0) sb.append(sep);
            sb.append(xs.get(i));
        }
        return sb.toString();
    }

    private void saveTarget() {
        GeoPoint c = (GeoPoint) map.getMapCenter();
        Target t = new Target();
        t.time = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(new Date());
        t.lat = c.getLatitude();
        t.lon = c.getLongitude();
        t.alt = altitude;
        t.acc = accuracy;
        t.zoom = map.getZoomLevelDouble();
        t.layer = map.getTileProvider().getTileSource().name();
        t.structure = structure;
        t.carrier = carrier;
        t.trap = trap;
        t.feox = feox;

        int score = 0;
        if(structure) score += 45;
        if(carrier) score += 35;
        if(trap) score += 15;
        if(feox) score += 5;
        t.score = score;
        if(!structure || !carrier) t.decision = "REJECT/HOLD";
        else if(score >= 80) t.decision = "CLASS A";
        else if(score >= 60) t.decision = "CLASS B";
        else t.decision = "CLASS C";

        targets.add(t);
        addTargetMarker(t);
        Toast.makeText(this, "تم حفظ الهدف: " + t.decision, Toast.LENGTH_SHORT).show();
    }

    private void addTargetMarker(Target t) {
        Marker m = new Marker(map);
        m.setPosition(new GeoPoint(t.lat, t.lon));
        m.setTitle(t.decision + " | Score " + t.score);
        m.setSubDescription(t.time + "\n" + t.layer);
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        map.getOverlays().add(m);
        targetMarkers.add(m);
        map.invalidate();
    }

    private File outDir() {
        File d = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "BOUH_MapScout_V20");
        if(!d.exists()) d.mkdirs();
        return d;
    }

    private void exportCsv() {
        try {
            File f = new File(outDir(), "BOUH_MapScout_V20_targets.csv");
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f), "UTF-8"));
            pw.println("time,lat,lon,alt,acc,zoom,layer,structure,carrier,trap,feox,score,decision");
            for(Target t: targets) {
                pw.println(t.time+","+t.lat+","+t.lon+","+t.alt+","+t.acc+","+t.zoom+","+safe(t.layer)+","+t.structure+","+t.carrier+","+t.trap+","+t.feox+","+t.score+","+t.decision);
            }
            pw.close();
            Toast.makeText(this, "CSV: " + f.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch(Exception e) {
            Toast.makeText(this, "CSV error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String safe(String s) { return s == null ? "" : s.replace(",", " "); }

    private void exportKml() {
        try {
            File f = new File(outDir(), "BOUH_MapScout_V20_targets.kml");
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f), "UTF-8"));
            pw.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            pw.println("<kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document><name>BOUH MapScout V20 Targets</name>");
            int i=1;
            for(Target t: targets) {
                pw.println("<Placemark><name>"+t.decision+" "+(i++)+"</name>");
                pw.println("<description><![CDATA[Score "+t.score+"<br>Layer "+safe(t.layer)+"<br>Structure "+t.structure+" Carrier "+t.carrier+" Trap "+t.trap+" FeOx "+t.feox+"]]></description>");
                pw.println("<Point><coordinates>"+t.lon+","+t.lat+","+t.alt+"</coordinates></Point></Placemark>");
            }
            pw.println("</Document></kml>");
            pw.close();
            Toast.makeText(this, "KML: " + f.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch(Exception e) {
            Toast.makeText(this, "KML error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void requestLocation() {
        locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        if(android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 77);
            return;
        }
        startGps();
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(code, perms, grants);
        startGps();
    }

    private void startGps() {
        try {
            if(android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;

            LocationListener listener = new LocationListener() {
                @Override public void onLocationChanged(Location loc) {
                    gpsPoint = new GeoPoint(loc.getLatitude(), loc.getLongitude());
                    altitude = loc.hasAltitude() ? loc.getAltitude() : 0;
                    accuracy = loc.hasAccuracy() ? loc.getAccuracy() : -1;
                    if(follow) map.getController().animateTo(gpsPoint);
                    updateHud();
                }
                @Override public void onProviderEnabled(String p) {}
                @Override public void onProviderDisabled(String p) {}
            };
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500, 0, listener);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000, 0, listener);

            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location loc = gps != null ? gps : net;
            if(loc != null) {
                gpsPoint = new GeoPoint(loc.getLatitude(), loc.getLongitude());
                altitude = loc.hasAltitude() ? loc.getAltitude() : 0;
                accuracy = loc.hasAccuracy() ? loc.getAccuracy() : -1;
                map.getController().setCenter(gpsPoint);
            }
            updateHud();
        } catch(Exception e) {
            Toast.makeText(this, "GPS: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void updateHud() {
        GeoPoint c = (GeoPoint) map.getMapCenter();
        hud.setText(String.format(Locale.US,
            "%.6f, %.6f | ارتفاع %.0fm | دقة %s | Zoom %.1f | %s",
            c.getLatitude(), c.getLongitude(), altitude, accuracy < 0 ? "?" : String.format(Locale.US, "%.0fm", accuracy),
            map.getZoomLevelDouble(), map.getTileProvider().getTileSource().name()));
    }

    @Override protected void onResume() {
        super.onResume();
        map.onResume();
    }

    @Override protected void onPause() {
        map.onPause();
        super.onPause();
    }
}
