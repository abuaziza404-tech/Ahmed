# BOUH MapScout V20 Native OSM FieldCore

قفزة V20:
- محرك خرائط Android حقيقي: osmdroid MapView.
- زوم بالأصابع طبيعي وسريع.
- حركة خريطة Native أسرع من WebView اليدوي.
- كاش بلاطات osmdroid.
- طبقات: Esri Satellite HD / OSM Roads / OpenTopo / Custom XYZ.
- تحكم وضوح/حدة/تباين كتحسين بصري خفيف فوق الخريطة.
- تحليل BOUH: بنية + حامل + مصيدة + FeOx داعم.
- حفظ أهداف وتصدير CSV/KML إلى Documents/BOUH_MapScout_V20.
- قاعدة الصدق: الخرائط بصرية وملاحية؛ لا نسب طيفية بدون GeoTIFF/RAW bands/DEM.

ملاحظة: osmdroid dependency تُحمّل من MavenCentral أثناء GitHub Actions.
