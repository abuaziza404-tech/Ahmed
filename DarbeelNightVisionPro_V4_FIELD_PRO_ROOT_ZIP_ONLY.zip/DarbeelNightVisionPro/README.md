# BOUH Darbeel Night Vision Pro V4 Field-Pro

نسخة Android ميدانية للدربيل الليلي الرقمي باسم BOUH DARBEEL V4 FIELD-PRO.

## قدرات V4
- واجهة Field-Pro منظمة لا تقص الأزرار أسفل الشاشة.
- أزرار جانبية شفافة + شريط تحكم سفلي آمن فوق شريط النظام.
- أوضاع رؤية: TRUE LOW LIGHT, GREEN FIELD, GREEN ULTRA, AMBER DESERT, WHITE BOOST, RED STEALTH, EDGE SCOUT, BLUE HAZE.
- تحكم مباشر: Zoom, Gain, Gamma, Contrast, Exposure, Torch.
- منظار Crosshair مع 4 أنماط Scope.
- GPS + Altitude + Compass داخل HUD.
- حفظ صورة معالجة داخل Pictures/BOUH_Darbeel_V4.
- يعمل بكاميرا الهاتف Camera2 ولا يحتاج إنترنت.

## ملاحظة تقنية
هذا تطبيق رؤية ليلية رقمية يعتمد على كاميرا الهاتف والمعالجة الرقمية والتعريض والفلاش. لا يحول الهاتف إلى كاميرا حرارية أو IR حقيقية ما لم يكن الجهاز يملك حساسًا خارجيًا مخصصًا.
