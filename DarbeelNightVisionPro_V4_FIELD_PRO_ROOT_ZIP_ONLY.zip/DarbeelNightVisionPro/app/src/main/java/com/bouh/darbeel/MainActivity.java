package com.bouh.darbeel;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.*;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener, LocationListener {
    private static final int REQ = 404;
    private TextureView preview;
    private FieldHud hud;
    private TextView topHud, bottomHud;
    private LinearLayout leftRail, rightRail, bottomRail;
    private CameraManager cameraManager;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private CaptureRequest.Builder request;
    private String cameraId;
    private Rect activeArray;
    private float maxZoom = 8f;

    private SensorManager sensorManager;
    private LocationManager locationManager;
    private final float[] gravityVals = new float[3];
    private final float[] magneticVals = new float[3];
    private boolean hasGravity = false, hasMagnetic = false;
    private float heading = 0f;
    private Location lastLocation;

    private boolean flashOn = false;
    private boolean ultra = true;
    private boolean cleanHud = false;
    private int scopeStyle = 0;
    private int mode = 0;
    private float zoom = 1.4f;
    private float gain = 2.2f;
    private float gamma = .72f;
    private float contrast = 1.22f;
    private int exposure = 0;
    private int fps = 0;
    private long frames = 0, lastFpsMs = 0;
    private int bottomInset = 0;

    private final String[] modes = {"TRUE LOW LIGHT", "GREEN FIELD", "GREEN ULTRA", "AMBER DESERT", "WHITE BOOST", "RED STEALTH", "EDGE SCOUT", "BLUE HAZE"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        buildUi();
        if (!hasCameraPermission()) requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ);
        else startAll();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        preview = new TextureView(this);
        root.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        hud = new FieldHud(this);
        root.addView(hud, new FrameLayout.LayoutParams(-1, -1));

        topHud = new TextView(this);
        topHud.setTextColor(Color.rgb(180,255,190));
        topHud.setTextSize(12.5f);
        topHud.setShadowLayer(7,0,0,Color.BLACK);
        topHud.setPadding(dp(12), dp(10), dp(12), dp(8));
        topHud.setBackgroundColor(Color.argb(70,0,0,0));
        root.addView(topHud, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        bottomHud = new TextView(this);
        bottomHud.setTextColor(Color.rgb(190,255,200));
        bottomHud.setTextSize(11.5f);
        bottomHud.setGravity(Gravity.CENTER);
        bottomHud.setShadowLayer(6,0,0,Color.BLACK);
        bottomHud.setPadding(dp(8), dp(5), dp(8), dp(5));
        bottomHud.setBackgroundColor(Color.argb(70,0,0,0));
        FrameLayout.LayoutParams bhp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        bhp.setMargins(dp(8),0,dp(8),dp(88));
        root.addView(bottomHud, bhp);

        leftRail = rail(true);
        addButton(leftRail, "CAP", "Capture");
        addButton(leftRail, "MODE", "Mode");
        addButton(leftRail, "ULTRA", "Ultra");
        addButton(leftRail, "LIGHT", "Torch");
        addButton(leftRail, "SCOPE", "Scope");
        FrameLayout.LayoutParams lrp = new FrameLayout.LayoutParams(dp(72), -2, Gravity.START | Gravity.CENTER_VERTICAL);
        lrp.setMargins(dp(6),0,0,0);
        root.addView(leftRail, lrp);

        rightRail = rail(true);
        addButton(rightRail, "Z+", "Zoom in");
        addButton(rightRail, "Z-", "Zoom out");
        addButton(rightRail, "G+", "Gain up");
        addButton(rightRail, "G-", "Gain down");
        addButton(rightRail, "HUD", "HUD");
        FrameLayout.LayoutParams rrp = new FrameLayout.LayoutParams(dp(72), -2, Gravity.END | Gravity.CENTER_VERTICAL);
        rrp.setMargins(0,0,dp(6),0);
        root.addView(rightRail, rrp);

        bottomRail = rail(false);
        addButton(bottomRail, "EXP-", "Exposure -");
        addButton(bottomRail, "EXP+", "Exposure +");
        addButton(bottomRail, "CON-", "Contrast -");
        addButton(bottomRail, "CON+", "Contrast +");
        addButton(bottomRail, "GAM-", "Gamma -");
        addButton(bottomRail, "GAM+", "Gamma +");
        addButton(bottomRail, "RESET", "Reset");
        FrameLayout.LayoutParams brp = new FrameLayout.LayoutParams(-1, dp(56), Gravity.BOTTOM);
        brp.setMargins(dp(6),0,dp(6),dp(18));
        root.addView(bottomRail, brp);

        root.setOnClickListener(v -> setCleanHud(!cleanHud));
        root.setOnApplyWindowInsetsListener((v, insets) -> { bottomInset = insets.getSystemWindowInsetBottom(); repositionBottom(); return insets; });
        setContentView(root);
        updateHudText();
    }

    private LinearLayout rail(boolean vertical) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(vertical ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        r.setPadding(dp(4), dp(4), dp(4), dp(4));
        r.setBackgroundColor(Color.argb(64, 0, 35, 8));
        return r;
    }

    private void addButton(LinearLayout parent, String label, String action) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(10.5f);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(0,0,0,0);
        b.setBackgroundColor(Color.argb(172, 28, 52, 32));
        b.setOnClickListener(v -> runAction(action));
        LinearLayout.LayoutParams lp;
        if (parent.getOrientation() == LinearLayout.VERTICAL) { lp = new LinearLayout.LayoutParams(-1, dp(42)); lp.setMargins(0, dp(4),0,dp(4)); }
        else { lp = new LinearLayout.LayoutParams(0, -1, 1f); lp.setMargins(dp(3),0,dp(3),0); }
        parent.addView(b, lp);
    }

    private void repositionBottom() {
        int safe = Math.max(dp(18), bottomInset + dp(10));
        FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) bottomRail.getLayoutParams();
        p.setMargins(dp(6),0,dp(6),safe);
        bottomRail.setLayoutParams(p);
        FrameLayout.LayoutParams hp = (FrameLayout.LayoutParams) bottomHud.getLayoutParams();
        hp.setMargins(dp(8),0,dp(8), safe + dp(62));
        bottomHud.setLayoutParams(hp);
    }

    private void setCleanHud(boolean enabled) {
        cleanHud = enabled;
        int v = enabled ? View.GONE : View.VISIBLE;
        leftRail.setVisibility(v); rightRail.setVisibility(v); bottomRail.setVisibility(v);
        bottomHud.setVisibility(enabled ? View.GONE : View.VISIBLE);
        topHud.setAlpha(enabled ? .72f : 1f);
        hud.invalidate();
    }

    private void runAction(String a) {
        switch(a) {
            case "Capture": saveCapture(); return;
            case "Mode": mode = (mode + 1) % modes.length; break;
            case "Ultra": ultra = !ultra; if (ultra) { gain = Math.max(2.4f, gain); gamma = Math.min(.65f, gamma); contrast = Math.max(1.30f, contrast); } break;
            case "Torch": flashOn = !flashOn; break;
            case "Scope": scopeStyle = (scopeStyle + 1) % 4; break;
            case "Zoom in": zoom = clamp(zoom + .35f, 1f, maxZoom); break;
            case "Zoom out": zoom = clamp(zoom - .35f, 1f, maxZoom); break;
            case "Gain up": gain = clamp(gain + .20f, .8f, 6.0f); break;
            case "Gain down": gain = clamp(gain - .20f, .8f, 6.0f); break;
            case "Exposure +": exposure = Math.min(6, exposure + 1); break;
            case "Exposure -": exposure = Math.max(-6, exposure - 1); break;
            case "Contrast +": contrast = clamp(contrast + .08f, .7f, 2.8f); break;
            case "Contrast -": contrast = clamp(contrast - .08f, .7f, 2.8f); break;
            case "Gamma +": gamma = clamp(gamma + .04f, .25f, 1.8f); break;
            case "Gamma -": gamma = clamp(gamma - .04f, .25f, 1.8f); break;
            case "Reset": zoom=1.4f; gain=2.2f; gamma=.72f; contrast=1.22f; exposure=0; flashOn=false; ultra=true; mode=0; scopeStyle=0; break;
            case "HUD": setCleanHud(!cleanHud); break;
        }
        applyCamera(); updateHudText(); hud.invalidate();
    }

    private void startAll() {
        startSensors(); startLocation(); openWhenReady();
    }

    private void startSensors() {
        try {
            Sensor acc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            Sensor mag = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
            if (acc != null) sensorManager.registerListener(this, acc, SensorManager.SENSOR_DELAY_UI);
            if (mag != null) sensorManager.registerListener(this, mag, SensorManager.SENSOR_DELAY_UI);
        } catch(Exception ignored) {}
    }

    private void startLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        try {
            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            lastLocation = gps != null ? gps : net;
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2500, 1f, this);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5f, this);
        } catch(Exception ignored) {}
    }

    private void openWhenReady() {
        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(android.graphics.SurfaceTexture st, int w, int h) { openCamera(); }
            @Override public void onSurfaceTextureSizeChanged(android.graphics.SurfaceTexture st, int w, int h) {}
            @Override public boolean onSurfaceTextureDestroyed(android.graphics.SurfaceTexture st) { return true; }
            @Override public void onSurfaceTextureUpdated(android.graphics.SurfaceTexture st) { tickFps(); }
        });
        if (preview.isAvailable()) openCamera();
    }

    private void openCamera() {
        try {
            for (String id : cameraManager.getCameraIdList()) {
                CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
                Integer f = c.get(CameraCharacteristics.LENS_FACING);
                if (f != null && f == CameraCharacteristics.LENS_FACING_BACK) { cameraId = id; break; }
            }
            if (cameraId == null) cameraId = cameraManager.getCameraIdList()[0];
            CameraCharacteristics ch = cameraManager.getCameraCharacteristics(cameraId);
            activeArray = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            Float mz = ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            if (mz != null) maxZoom = Math.min(12f, Math.max(2f, mz));
            if (hasCameraPermission()) cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) { camera = c; startPreview(); }
                @Override public void onDisconnected(CameraDevice c) { c.close(); camera = null; }
                @Override public void onError(CameraDevice c, int e) { Toast.makeText(MainActivity.this,"Camera error "+e,Toast.LENGTH_LONG).show(); c.close(); camera = null; }
            }, null);
        } catch(Exception e) { Toast.makeText(this, "Open camera failed: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void startPreview() {
        try {
            android.graphics.SurfaceTexture st = preview.getSurfaceTexture();
            st.setDefaultBufferSize(1280,720);
            Surface s = new Surface(st);
            request = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            request.addTarget(s);
            camera.createCaptureSession(Arrays.asList(s), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession cs) { session = cs; applyCamera(); }
                @Override public void onConfigureFailed(CameraCaptureSession cs) { Toast.makeText(MainActivity.this,"Preview failed",Toast.LENGTH_LONG).show(); }
            }, null);
        } catch(Exception e) { Toast.makeText(this, "Preview failed: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void applyCamera() {
        if (request == null || session == null) return;
        try {
            request.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
            request.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            request.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            request.set(CaptureRequest.FLASH_MODE, flashOn ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            request.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, exposure);
            if (activeArray != null) {
                int cx = activeArray.centerX(), cy = activeArray.centerY();
                int w = (int)(activeArray.width()/zoom), h = (int)(activeArray.height()/zoom);
                Rect crop = new Rect(cx-w/2, cy-h/2, cx+w/2, cy+h/2);
                request.set(CaptureRequest.SCALER_CROP_REGION, crop);
            }
            session.setRepeatingRequest(request.build(), null, null);
        } catch(Exception ignored) {}
    }

    private boolean hasCameraPermission() { return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED; }
    private float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private void tickFps() {
        frames++;
        long now = System.currentTimeMillis();
        if (lastFpsMs == 0) lastFpsMs = now;
        if (now - lastFpsMs >= 1000) { fps = (int) frames; frames = 0; lastFpsMs = now; updateHudText(); }
    }

    private void updateHudText() {
        String loc = "GPS --";
        String alt = "ALT --";
        if (lastLocation != null) {
            loc = String.format(Locale.US, "%.5f, %.5f", lastLocation.getLatitude(), lastLocation.getLongitude());
            if (lastLocation.hasAltitude()) alt = String.format(Locale.US, "ALT %.0fm", lastLocation.getAltitude());
        }
        topHud.setText("BOUH DARBEEL V4 FIELD-PRO | FPS " + fps + " | " + modes[mode] + " | Ultra " + (ultra?"ON":"OFF") + " | Torch " + (flashOn?"ON":"OFF") + "\n" +
                String.format(Locale.US, "Zoom %.1fx/%.1fx | Gain %.2f | Gamma %.2f | Contrast %.2f | EXP %+d", zoom, maxZoom, gain, gamma, contrast, exposure));
        bottomHud.setText(String.format(Locale.US, "GPS %s  |  %s  |  Compass %.0f°  |  Ahmed Abu Aziza Al-Rashidi", loc, alt, heading));
    }

    private void saveCapture() {
        try {
            Bitmap src = preview.getBitmap();
            if (src == null) { Toast.makeText(this, "No frame", Toast.LENGTH_SHORT).show(); return; }
            Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(out); c.drawBitmap(src,0,0,null); hud.drawFieldFilter(c, out.getWidth(), out.getHeight(), true); hud.drawFieldScope(c, out.getWidth(), out.getHeight());
            String name = "BOUH_Darbeel_V4_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/BOUH_Darbeel_V4");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri != null) { OutputStream os = getContentResolver().openOutputStream(uri); out.compress(Bitmap.CompressFormat.JPEG, 94, os); if (os != null) os.close(); Toast.makeText(this, "Saved: " + name, Toast.LENGTH_SHORT).show(); }
        } catch(Exception e) { Toast.makeText(this, "Capture failed: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) { System.arraycopy(event.values,0,gravityVals,0,3); hasGravity = true; }
        if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) { System.arraycopy(event.values,0,magneticVals,0,3); hasMagnetic = true; }
        if (hasGravity && hasMagnetic) {
            float[] r = new float[9], i = new float[9], o = new float[3];
            if (SensorManager.getRotationMatrix(r, i, gravityVals, magneticVals)) {
                SensorManager.getOrientation(r, o);
                heading = (float)Math.toDegrees(o[0]); if (heading < 0) heading += 360f;
                updateHudText(); hud.invalidate();
            }
        }
    }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    @Override public void onLocationChanged(Location location) { lastLocation = location; updateHudText(); }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { super.onRequestPermissionsResult(r,p,g); if (r == REQ && hasCameraPermission()) startAll(); else finish(); }
    @Override protected void onResume() { super.onResume(); if (hasCameraPermission() && preview != null && preview.isAvailable() && camera == null) openCamera(); startSensors(); startLocation(); }
    @Override protected void onPause() { super.onPause(); try { sensorManager.unregisterListener(this); locationManager.removeUpdates(this); if (session != null) session.close(); if (camera != null) camera.close(); } catch(Exception ignored) {} session = null; camera = null; }

    class FieldHud extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        FieldHud(Context c) { super(c); }
        @Override protected void onDraw(Canvas c) { super.onDraw(c); drawFieldFilter(c, getWidth(), getHeight(), false); drawFieldScope(c, getWidth(), getHeight()); }

        void drawFieldFilter(Canvas c, int w, int h, boolean capture) {
            int overlay;
            switch(mode) {
                case 0: overlay = Color.argb(24, 110, 170, 105); break;
                case 1: overlay = Color.argb(42, 35, 230, 70); break;
                case 2: overlay = Color.argb(66, 20, 255, 64); break;
                case 3: overlay = Color.argb(58, 255, 145, 30); break;
                case 4: overlay = Color.argb(38, 255, 255, 255); break;
                case 5: overlay = Color.argb(54, 255, 38, 38); break;
                case 6: overlay = Color.argb(36, 130, 255, 150); break;
                default: overlay = Color.argb(42, 70, 120, 255); break;
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(overlay); c.drawRect(0,0,w,h,p);
            if (ultra) { int a = Math.min(118, (int)(22 * gain)); p.setColor(Color.argb(a, 92, 255, 115)); c.drawRect(0,0,w,h,p); }
            // Tactical vignette: darkens edges but keeps middle clearer than V3.
            float cx = w/2f, cy = h/2f, outer = Math.min(w,h) * .48f;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(18, Math.min(w,h)*.038f)); p.setColor(Color.argb(95,0,0,0)); c.drawCircle(cx,cy,outer,p);
            p.setStrokeWidth(Math.max(2, Math.min(w,h)*.006f)); p.setColor(Color.argb(86, 185, 255, 185)); c.drawCircle(cx,cy,outer*.72f,p);
            if (capture) { p.setTextSize(Math.min(w,h)*.025f); p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(190,200,255,205)); c.drawText("BOUH DARBEEL V4 FIELD-PRO", dp(20), h-dp(28), p); }
        }

        void drawFieldScope(Canvas c, int w, int h) {
            float cx = w/2f, cy = h/2f;
            float r = Math.min(w,h) * (scopeStyle == 1 ? .18f : .13f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3); p.setColor(Color.argb(205, 195, 255, 195));
            if (scopeStyle == 2) {
                c.drawCircle(cx-r*.62f, cy, r, p); c.drawCircle(cx+r*.62f, cy, r, p);
            } else if (scopeStyle == 3) {
                c.drawRect(cx-r, cy-r*.62f, cx+r, cy+r*.62f, p);
            } else {
                c.drawCircle(cx, cy, r, p);
            }
            p.setStrokeWidth(2); p.setColor(Color.argb(185, 210, 255, 210));
            c.drawLine(cx-r*.9f, cy, cx-r*.25f, cy, p); c.drawLine(cx+r*.25f, cy, cx+r*.9f, cy, p);
            c.drawLine(cx, cy-r*.9f, cx, cy-r*.25f, p); c.drawLine(cx, cy+r*.25f, cx, cy+r*.9f, p);
            p.setStrokeWidth(1); p.setColor(Color.argb(120, 210,255,210));
            c.drawCircle(cx, cy, r*.42f, p);
            p.setStyle(Paint.Style.FILL); p.setTextSize(15); p.setColor(Color.argb(175, 200, 255, 200));
            c.drawText("BOUH V4", cx-r*.52f, cy+r+dp(20), p);
            // compass micro scale top center
            p.setTextSize(14); p.setColor(Color.argb(180, 190,255,190));
            String hd = String.format(Locale.US, "%.0f°", heading);
            c.drawText(hd, cx-dp(14), dp(92), p);
        }
    }
}
