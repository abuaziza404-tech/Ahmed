from pathlib import Path
import sys
base = Path(__file__).parent
required = [
    "settings.gradle",
    "build.gradle",
    "gradle.properties",
    "app/build.gradle",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/bouh/mapscout/MainActivity.java",
    "app/src/main/assets/BOUH_V47_Final_QA_336K_Preview.html",
    "app/src/main/assets/BOUH_V48_PACKAGED_V47_QA_REPORT.json",
]
missing = [p for p in required if not (base / p).exists()]
if missing:
    print("MISSING:", missing)
    sys.exit(1)
manifest = (base / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
if 'android:exported="true"' not in manifest:
    print("Manifest exported check failed")
    sys.exit(1)
html = (base / "app/src/main/assets/BOUH_V47_Final_QA_336K_Preview.html").read_text(encoding="utf-8")
if "BOUH MapScout V47" not in html:
    print("HTML signature check failed")
    sys.exit(1)
print("PAYLOAD_VALIDATION_PASS")
