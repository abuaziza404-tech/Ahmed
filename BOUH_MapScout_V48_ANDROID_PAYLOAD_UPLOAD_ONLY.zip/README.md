# BOUH MapScout V48 Android Payload

ZIP-only Android payload for GitHub Actions.

The workflow unzips this payload inside the runner and builds a debug APK.
The full 336,000-cell CSV is kept in the delivery bundle as QA data, not inside the APK.
