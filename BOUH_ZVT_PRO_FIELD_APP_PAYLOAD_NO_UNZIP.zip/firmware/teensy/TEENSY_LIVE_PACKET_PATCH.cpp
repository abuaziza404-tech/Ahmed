/*
Patch for immediate live BLE packet emission from Teensy through ESP32 bridge.
Call emitLiveBlePacket(f, result) after decisionEngine().
*/
uint32_t livePacketSeq = 0;
void emitLiveBlePacket(const DecayFeatures &f, const SniperResult &r) {
  if (r.decision != DIG_CONFIRMED && r.decision != SUSPECT_QUARTZ_POCKET) return;
  livePacketSeq++;
  Serial.print("decision=");
  Serial.print(r.decision == DIG_CONFIRMED ? "DIG" : "SUSPECT");
  Serial.print(",lat="); Serial.print(currentLat, 7);
  Serial.print(",lon="); Serial.print(currentLon, 7);
  Serial.print(",gps="); Serial.print(gpsHdop, 2);
  Serial.print(",mineralization="); Serial.print(activePreset.mineralizationLevel, 3);
  Serial.print(",geoBias="); Serial.print(nearestGeoBias, 4);
  Serial.print(",signal="); Serial.print(r.signalScore, 2);
  Serial.print(",weighted="); Serial.print(r.weightedDecision, 2);
  Serial.print(",tauLate="); Serial.print(f.tauLateUs, 2);
  Serial.print(",lateEarly="); Serial.print(f.lateEarlyRatio, 4);
  Serial.print(",lowFreq="); Serial.print(f.lowFrequencyNoise, 4);
  Serial.print(",iron="); Serial.print(f.ironScore, 2);
  Serial.print(",gold="); Serial.print(f.goldScore, 2);
  Serial.print(",largeMass="); Serial.print(r.largeMass ? 1 : 0);
  Serial.print(",temp="); Serial.print(currentTempC, 2);
  Serial.print(",preset="); Serial.print(activePreset.name);
  Serial.print(",seq="); Serial.println(livePacketSeq);
}
