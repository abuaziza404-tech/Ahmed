/*
  BOUH ZVT Sniper Geological Strategy Firmware
  Target: Teensy 4.1
  Purpose:
    - Sniper Decision Matrix for high-priority, large-mass / quartz-pocket targets only
    - Geo-aware GPS bias from priority.csv
    - Large Mass Logic: stable late decay > 3 seconds + low frequency noise
    - SD snapshot logging at each DIG decision
    - Audio alert only for sniper-grade large mass decision

  Important:
    This is a research ZVT-like / PI firmware architecture. It is not a clone of proprietary ZVT.
    DIG_NOW means "field verification priority" and does not prove gold without sampling.
*/

#include <Arduino.h>
#include <ADC.h>
#include <AnalogBufferDMA.h>
#include <SD.h>
#include <SPI.h>
#include <TinyGPSPlus.h>

// -----------------------------
// Pins
// -----------------------------
static constexpr uint8_t PIN_RX_ADC = A0;
static constexpr uint8_t PIN_TEMP = A1;
static constexpr uint8_t PIN_TX_GATE_A = 2;
static constexpr uint8_t PIN_TX_GATE_B = 3;
static constexpr uint8_t PIN_RX_BLANK = 4;
static constexpr uint8_t PIN_BUZZER = 5;
static constexpr uint8_t PIN_LED = 13;
static constexpr uint8_t PIN_SD_CS = BUILTIN_SDCARD;

// -----------------------------
// Sampling and buffers
// -----------------------------
static constexpr uint32_t ADC_SAMPLE_RATE_HZ = 100000UL;
static constexpr float SAMPLE_DT_US = 1000000.0f / static_cast<float>(ADC_SAMPLE_RATE_HZ);

static constexpr uint16_t DMA_BUFFER_SIZE = 512;
static constexpr uint16_t DECAY_LEN = 256;
static constexpr uint16_t ANALYSIS_START = 12;
static constexpr uint16_t ANALYSIS_END = 220;

// Sniper behavior
static constexpr float SNIPER_THRESHOLD = 82.0f;
static constexpr float SUSPECT_THRESHOLD = 64.0f;
static constexpr uint32_t LARGE_MASS_CONFIRM_MS = 3000;
static constexpr uint32_t SNAPSHOT_COOLDOWN_MS = 6000;

// Large mass stability thresholds
static constexpr float LATE_DECAY_STABILITY_TAU_STD_MAX = 45.0f;
static constexpr float LATE_RATIO_STABILITY_STD_MAX = 0.090f;
static constexpr float LOW_FREQ_NOISE_MAX = 0.34f;
static constexpr float MIN_LATE_EARLY_RATIO_LARGE = 0.48f;

// -----------------------------
// ADC / DMA
// -----------------------------
ADC *adc = new ADC();
DMAMEM static volatile uint16_t dma_adc_buff1[DMA_BUFFER_SIZE] __attribute__((aligned(32)));
DMAMEM static volatile uint16_t dma_adc_buff2[DMA_BUFFER_SIZE] __attribute__((aligned(32)));
AnalogBufferDMA adc_dma(dma_adc_buff1, DMA_BUFFER_SIZE, dma_adc_buff2, DMA_BUFFER_SIZE);

IntervalTimer frameTimer;
TinyGPSPlus gps;

// -----------------------------
// Runtime state
// -----------------------------
volatile bool frameReady = false;
volatile uint32_t frameCounter = 0;

float rawDecay[DECAY_LEN];
float filteredDecay[DECAY_LEN];

float emaState = 0.0f;
float calibrationOffset = 0.0f;
float noiseFloor = 1.0f;
float currentTempC = 25.0f;

float currentLat = NAN;
float currentLon = NAN;
float gpsHdop = 99.0f;

float nearestPriorityScore = 0.0f;
float nearestGeoBias = 0.0f;
float nearestDistanceM = 999999.0f;
float nearestSilica = 0.0f;
float nearestIron = 0.0f;
float nearestTerrain = 0.0f;

uint32_t largeMassCandidateStartMs = 0;
uint32_t lastSnapshotMs = 0;

// -----------------------------
// Geo data
// -----------------------------
static constexpr uint16_t MAX_PRIORITY_POINTS = 850;

struct GeoPriorityPoint {
  float lat;
  float lon;
  float priorityScore;
  float silica;
  float iron;
  float terrain;
  float groundBias;
  char zone[16];
};

GeoPriorityPoint priorityPoints[MAX_PRIORITY_POINTS];
uint16_t priorityCount = 0;

// -----------------------------
// Region presets
// -----------------------------
struct SniperPreset {
  const char *name;
  float mineralizationLevel;
  float groundBiasBase;
  float ironRejectStrength;
  float sniperThreshold;
  float suspectThreshold;
  float lateRatioMin;
  float lowFreqNoiseMax;
  float pulsePeriodUs;
  float txPulseUs;
  float rxBlankUs;
  float emaBaseAlpha;
};

SniperPreset PRESET_ARBAAT = {
  "ARBAAT", 0.88f, 0.64f, 0.88f, 86.0f, 68.0f, 0.54f, 0.30f, 6000.0f, 92.0f, 26.0f, 0.064f
};

SniperPreset PRESET_SINKAT = {
  "SINKAT", 0.72f, 0.52f, 0.72f, 82.0f, 64.0f, 0.48f, 0.34f, 5300.0f, 84.0f, 20.0f, 0.078f
};

SniperPreset PRESET_GEBEIT = {
  "GEBEIT", 0.80f, 0.58f, 0.80f, 84.0f, 66.0f, 0.51f, 0.32f, 5600.0f, 88.0f, 23.0f, 0.070f
};

SniperPreset activePreset = PRESET_SINKAT;

// -----------------------------
// Feature structures
// -----------------------------
struct DecayFeatures {
  float v0;
  float tauUs;
  float tauEarlyUs;
  float tauLateUs;
  float dEnergy;
  float d2Energy;
  float curvature;
  float lateEarlyRatio;
  float normalizedArea;
  float residualRms;
  float lowFrequencyNoise;
  float goldScore;
  float ironScore;
  float soilScore;
};

enum SniperDecision : uint8_t {
  SCAN_CONTINUE = 1,
  SUSPECT_QUARTZ_POCKET = 2,
  DIG_CONFIRMED = 3
};

struct SniperResult {
  SniperDecision decision;
  float weightedDecision;
  bool largeMass;
  bool stableLateDecay;
  bool lowFreqNoiseOk;
  float geoBias;
  float signalScore;
};

// -----------------------------
// Utilities
// -----------------------------
float clampf(float x, float lo, float hi) {
  if (x < lo) return lo;
  if (x > hi) return hi;
  return x;
}

float safeDiv(float a, float b, float fallback = 0.0f) {
  if (fabsf(b) < 1e-9f) return fallback;
  return a / b;
}

float haversineMeters(float lat1, float lon1, float lat2, float lon2) {
  static constexpr float R = 6371000.0f;
  const float p1 = lat1 * DEG_TO_RAD;
  const float p2 = lat2 * DEG_TO_RAD;
  const float dp = (lat2 - lat1) * DEG_TO_RAD;
  const float dl = (lon2 - lon1) * DEG_TO_RAD;
  const float a = sinf(dp * 0.5f) * sinf(dp * 0.5f) +
                  cosf(p1) * cosf(p2) * sinf(dl * 0.5f) * sinf(dl * 0.5f);
  return 2.0f * R * atan2f(sqrtf(a), sqrtf(1.0f - a));
}

// -----------------------------
// Thermal
// -----------------------------
float getTemperatureC() {
  const uint16_t raw = analogRead(PIN_TEMP);
  const float voltage = raw * (3.3f / 1023.0f);
  return voltage * 100.0f;
}

void thermalCompensation() {
  currentTempC = getTemperatureC();
  const float deltaT = currentTempC - 25.0f;
  const float K_frontend = 0.050f;
  const float K_soil = (strcmp(activePreset.name, "ARBAAT") == 0) ? 0.012f :
                       (strcmp(activePreset.name, "GEBEIT") == 0) ? 0.010f : 0.008f;
  calibrationOffset = K_frontend * deltaT + K_soil * activePreset.mineralizationLevel * deltaT;
}

// -----------------------------
// ADC DMA
// -----------------------------
void configureADC_DMA_100kHz() {
  analogReadResolution(12);
  analogReadAveraging(1);

  adc->adc0->setAveraging(1);
  adc->adc0->setResolution(12);
  adc->adc0->setConversionSpeed(ADC_CONVERSION_SPEED::HIGH_SPEED);
  adc->adc0->setSamplingSpeed(ADC_SAMPLING_SPEED::HIGH_SPEED);

  adc_dma.init(adc, ADC_0);
  adc->adc0->startContinuous(PIN_RX_ADC);
}

void ADC_Sampling(float *out, int len) {
  volatile uint16_t *src = adc_dma.bufferLastISRFilled();

  if (src == nullptr) {
    for (int i = 0; i < len; ++i) out[i] = 0.0f;
    return;
  }

  const int n = min(len, static_cast<int>(DMA_BUFFER_SIZE));

  for (int i = 0; i < n; ++i) {
    out[i] = static_cast<float>(src[i]) - 2048.0f - calibrationOffset;
  }

  for (int i = n; i < len; ++i) out[i] = out[n - 1];
}

// -----------------------------
// TX pulse
// -----------------------------
void txOff() {
  digitalWriteFast(PIN_TX_GATE_A, LOW);
  digitalWriteFast(PIN_TX_GATE_B, LOW);
}

void txSniperPulse() {
  digitalWriteFast(PIN_RX_BLANK, HIGH);
  digitalWriteFast(PIN_TX_GATE_A, HIGH);
  digitalWriteFast(PIN_TX_GATE_B, LOW);
  delayMicroseconds(static_cast<uint32_t>(activePreset.txPulseUs));
  txOff();
  delayMicroseconds(static_cast<uint32_t>(activePreset.rxBlankUs));
  digitalWriteFast(PIN_RX_BLANK, LOW);
}

void frameISR() {
  txSniperPulse();
  frameReady = true;
  frameCounter++;
}

// -----------------------------
// Filtering and decay analysis
// -----------------------------
float estimateNoiseFloor(const float *buffer, int len) {
  const int start = max(0, len - 48);
  float mean = 0.0f;
  int n = 0;

  for (int i = start; i < len; ++i) {
    mean += buffer[i];
    n++;
  }
  mean /= max(n, 1);

  float acc = 0.0f;
  for (int i = start; i < len; ++i) {
    const float d = buffer[i] - mean;
    acc += d * d;
  }

  return sqrtf(acc / max(n - 1, 1));
}

float adaptiveAlpha(float sample) {
  const float diff = fabsf(sample - emaState);
  const float ratio = diff / max(noiseFloor, 0.001f);

  float alpha = activePreset.emaBaseAlpha;
  if (ratio > 12.0f) alpha = 0.55f;
  else if (ratio > 6.0f) alpha = 0.34f;
  else if (ratio > 3.0f) alpha = 0.18f;

  if (noiseFloor > 5.0f) alpha *= 0.75f;
  if (noiseFloor > 9.0f) alpha *= 0.58f;

  return clampf(alpha, 0.030f, 0.60f);
}

float applyAdaptiveEMA(float input, float alpha) {
  alpha = clampf(alpha, 0.001f, 0.999f);
  emaState = alpha * input + (1.0f - alpha) * emaState;
  return emaState;
}

float estimateTauLogFit(const float *buffer, int startIndex, int endIndex) {
  float minV = 1e9f;
  for (int i = startIndex; i < endIndex; ++i) minV = min(minV, buffer[i]);
  const float lift = minV < 1.0f ? 1.0f - minV : 0.0f;

  float sx = 0.0f, sy = 0.0f, sxx = 0.0f, sxy = 0.0f;
  int n = 0;

  for (int i = startIndex; i < endIndex; ++i) {
    const float v = buffer[i] + lift;
    if (v <= 1.0f) continue;
    const float t = static_cast<float>(i - startIndex) * SAMPLE_DT_US;
    const float y = logf(v);
    sx += t;
    sy += y;
    sxx += t * t;
    sxy += t * y;
    n++;
  }

  if (n < 8) return 0.0f;
  const float denom = n * sxx - sx * sx;
  if (fabsf(denom) < 1e-6f) return 0.0f;

  const float slope = (n * sxy - sx * sy) / denom;
  if (slope >= -1e-6f) return 0.0f;
  return -1.0f / slope;
}

float residualRmsAgainstExp(const float *buffer, int startIndex, int endIndex, float tauUs) {
  if (tauUs <= 0.0f) return 9999.0f;
  const float v0 = max(buffer[startIndex], 1.0f);
  float acc = 0.0f;
  int n = 0;

  for (int i = startIndex; i < endIndex; ++i) {
    const float t = static_cast<float>(i - startIndex) * SAMPLE_DT_US;
    const float model = v0 * expf(-t / tauUs);
    const float e = buffer[i] - model;
    acc += e * e;
    n++;
  }

  return sqrtf(acc / max(n, 1));
}

float computeLowFrequencyNoise(const float *buffer, int startIndex, int endIndex) {
  float slowAcc = 0.0f;
  float fastAcc = 0.0f;

  for (int i = startIndex + 4; i < endIndex; ++i) {
    const float slow = buffer[i] - buffer[i - 4];
    const float fast = buffer[i] - buffer[i - 1];
    slowAcc += fabsf(slow);
    fastAcc += fabsf(fast);
  }

  return safeDiv(slowAcc, max(fastAcc * 4.0f, 0.001f), 1.0f);
}

DecayFeatures extractDecayFeatures(float *buffer, int len) {
  DecayFeatures f{};
  f.residualRms = 9999.0f;

  noiseFloor = estimateNoiseFloor(buffer, len);

  for (int i = 0; i < len; ++i) {
    filteredDecay[i] = applyAdaptiveEMA(buffer[i], adaptiveAlpha(buffer[i]));
  }

  float lateMean = 0.0f;
  int lateCount = 0;

  for (int i = len - 44; i < len; ++i) {
    lateMean += filteredDecay[i];
    lateCount++;
  }
  lateMean /= max(lateCount, 1);

  for (int i = 0; i < len; ++i) {
    filteredDecay[i] = fabsf(filteredDecay[i] - lateMean);
  }

  f.v0 = filteredDecay[ANALYSIS_START];
  f.tauUs = estimateTauLogFit(filteredDecay, ANALYSIS_START, ANALYSIS_END);
  f.tauEarlyUs = estimateTauLogFit(filteredDecay, ANALYSIS_START, ANALYSIS_START + 64);
  f.tauLateUs = estimateTauLogFit(filteredDecay, ANALYSIS_START + 64, ANALYSIS_END);
  f.lowFrequencyNoise = computeLowFrequencyNoise(filteredDecay, ANALYSIS_START, ANALYSIS_END);

  float areaEarly = 0.0f;
  float areaLate = 0.0f;

  for (int i = ANALYSIS_START + 2; i < ANALYSIS_END - 2; ++i) {
    const float d1 = filteredDecay[i] - filteredDecay[i - 1];
    const float d2 = filteredDecay[i + 1] - 2.0f * filteredDecay[i] + filteredDecay[i - 1];
    f.dEnergy += fabsf(d1);
    f.d2Energy += fabsf(d2);

    if (i < ANALYSIS_START + 76) areaEarly += filteredDecay[i];
    else areaLate += filteredDecay[i];
  }

  f.curvature = safeDiv(f.d2Energy, max(f.dEnergy, 0.001f));
  f.lateEarlyRatio = safeDiv(areaLate, max(areaEarly, 0.001f));
  f.normalizedArea = safeDiv(areaEarly + areaLate, max(f.v0 * (ANALYSIS_END - ANALYSIS_START), 0.001f));
  f.residualRms = residualRmsAgainstExp(filteredDecay, ANALYSIS_START, ANALYSIS_END, f.tauUs);

  const float tauScore = clampf((f.tauUs - 110.0f) / 850.0f, 0.0f, 1.0f);
  const float lateScore = clampf((f.lateEarlyRatio - 0.28f) / 0.65f, 0.0f, 1.0f);
  const float smoothScore = clampf(1.0f - f.curvature / 0.72f, 0.0f, 1.0f);
  const float residualScore = clampf(1.0f - f.residualRms / max(noiseFloor * 8.0f, 1.0f), 0.0f, 1.0f);
  const float lowFreqScore = clampf(1.0f - f.lowFrequencyNoise / 0.50f, 0.0f, 1.0f);
  const float ampScore = clampf(f.v0 / max(noiseFloor * 65.0f, 1.0f), 0.0f, 1.0f);

  f.goldScore = 100.0f * (
    0.24f * tauScore +
    0.24f * lateScore +
    0.18f * smoothScore +
    0.16f * residualScore +
    0.10f * lowFreqScore +
    0.08f * ampScore
  );

  const float fastTau = clampf((170.0f - f.tauUs) / 170.0f, 0.0f, 1.0f);
  const float curveIron = clampf(f.curvature / 0.58f, 0.0f, 1.0f);
  const float residualIron = clampf(f.residualRms / max(noiseFloor * 5.0f, 1.0f), 0.0f, 1.0f);

  f.ironScore = 100.0f * (0.34f * fastTau + 0.34f * curveIron + 0.22f * residualIron + 0.10f * activePreset.mineralizationLevel);
  f.soilScore = 100.0f * clampf(noiseFloor / 18.0f, 0.0f, 1.0f);

  return f;
}

// -----------------------------
// Geo priority and GPS
// -----------------------------
bool parsePriorityCsvLine(char *line, GeoPriorityPoint &p) {
  char *token = strtok(line, ",");
  if (!token) return false;
  p.lat = atof(token);

  token = strtok(nullptr, ",");
  if (!token) return false;
  p.lon = atof(token);

  token = strtok(nullptr, ",");
  if (!token) return false;
  p.priorityScore = atof(token);

  token = strtok(nullptr, ",");
  if (!token) return false;
  p.silica = atof(token);

  token = strtok(nullptr, ",");
  if (!token) return false;
  p.iron = atof(token);

  token = strtok(nullptr, ",");
  if (!token) return false;
  p.terrain = atof(token);

  token = strtok(nullptr, ",");
  if (!token) return false;
  p.groundBias = atof(token);

  token = strtok(nullptr, ",\r\n");
  if (!token) token = (char *)"UNKNOWN";
  strncpy(p.zone, token, sizeof(p.zone) - 1);
  p.zone[sizeof(p.zone) - 1] = '\0';
  return true;
}

void loadPriorityFileFromSD() {
  priorityCount = 0;

  if (!SD.begin(PIN_SD_CS)) {
    Serial.println("SD init failed.");
    return;
  }

  File file = SD.open("priority.csv", FILE_READ);
  if (!file) {
    Serial.println("priority.csv not found.");
    return;
  }

  char line[180];
  bool header = true;

  while (file.available() && priorityCount < MAX_PRIORITY_POINTS) {
    int n = file.readBytesUntil('\n', line, sizeof(line) - 1);
    line[n] = '\0';

    if (header) {
      header = false;
      continue;
    }

    GeoPriorityPoint p;
    if (parsePriorityCsvLine(line, p)) {
      priorityPoints[priorityCount++] = p;
    }
  }

  file.close();
  Serial.print("Loaded priority points: ");
  Serial.println(priorityCount);
}

void updateGps() {
  while (Serial1.available()) {
    gps.encode(Serial1.read());
  }

  if (gps.location.isUpdated()) {
    currentLat = gps.location.lat();
    currentLon = gps.location.lng();
  }

  if (gps.hdop.isUpdated()) {
    gpsHdop = gps.hdop.hdop();
  }
}

void selectPresetByLocation() {
  if (!isfinite(currentLat) || !isfinite(currentLon)) return;

  if (currentLat > 19.65f && currentLon < 36.75f) activePreset = PRESET_ARBAAT;
  else if (currentLat < 19.35f && currentLon > 36.75f) activePreset = PRESET_GEBEIT;
  else activePreset = PRESET_SINKAT;
}

void updateGeoBiasFromPriority() {
  nearestPriorityScore = 0.0f;
  nearestGeoBias = activePreset.groundBiasBase;
  nearestDistanceM = 999999.0f;
  nearestSilica = 0.0f;
  nearestIron = 0.0f;
  nearestTerrain = 0.0f;

  if (!isfinite(currentLat) || !isfinite(currentLon)) return;

  for (uint16_t i = 0; i < priorityCount; ++i) {
    const float d = haversineMeters(currentLat, currentLon, priorityPoints[i].lat, priorityPoints[i].lon);
    if (d < nearestDistanceM) {
      nearestDistanceM = d;
      nearestPriorityScore = priorityPoints[i].priorityScore;
      nearestGeoBias = priorityPoints[i].groundBias;
      nearestSilica = priorityPoints[i].silica;
      nearestIron = priorityPoints[i].iron;
      nearestTerrain = priorityPoints[i].terrain;
    }
  }

  const float proximity = clampf(1.0f - nearestDistanceM / 500.0f, 0.0f, 1.0f);
  const float quartzBias = clampf(nearestSilica / 100.0f, 0.0f, 1.0f);
  const float ironPenalty = clampf(nearestIron / 100.0f, 0.0f, 1.0f) * activePreset.ironRejectStrength;
  const float terrainBias = clampf(nearestTerrain / 100.0f, 0.0f, 1.0f);

  float sniperGeo = (
    0.42f * clampf(nearestPriorityScore / 100.0f, 0.0f, 1.0f) +
    0.26f * quartzBias +
    0.18f * terrainBias -
    0.14f * ironPenalty
  );

  sniperGeo = clampf(sniperGeo, 0.0f, 1.0f);

  nearestGeoBias = proximity * sniperGeo + (1.0f - proximity) * activePreset.groundBiasBase;
}

// -----------------------------
// Large Mass Logic
// -----------------------------
static constexpr uint16_t STABILITY_HISTORY = 40;
float tauHistory[STABILITY_HISTORY];
float lateRatioHistory[STABILITY_HISTORY];
float lowFreqHistory[STABILITY_HISTORY];
uint16_t historyIndex = 0;
uint16_t historyCount = 0;

void updateStabilityHistory(const DecayFeatures &f) {
  tauHistory[historyIndex] = f.tauLateUs > 1.0f ? f.tauLateUs : f.tauUs;
  lateRatioHistory[historyIndex] = f.lateEarlyRatio;
  lowFreqHistory[historyIndex] = f.lowFrequencyNoise;

  historyIndex = (historyIndex + 1) % STABILITY_HISTORY;
  if (historyCount < STABILITY_HISTORY) historyCount++;
}

float meanOf(const float *arr, uint16_t count) {
  float s = 0.0f;
  for (uint16_t i = 0; i < count; ++i) s += arr[i];
  return safeDiv(s, count, 0.0f);
}

float stdOf(const float *arr, uint16_t count) {
  if (count < 2) return 9999.0f;
  const float m = meanOf(arr, count);
  float acc = 0.0f;
  for (uint16_t i = 0; i < count; ++i) {
    const float d = arr[i] - m;
    acc += d * d;
  }
  return sqrtf(acc / (count - 1));
}

bool isStableLateDecayLargeMass(const DecayFeatures &f) {
  if (historyCount < 20) return false;

  const float tauStd = stdOf(tauHistory, historyCount);
  const float lateStd = stdOf(lateRatioHistory, historyCount);
  const float lowFreqMean = meanOf(lowFreqHistory, historyCount);

  const bool stableLate =
    tauStd <= LATE_DECAY_STABILITY_TAU_STD_MAX &&
    lateStd <= LATE_RATIO_STABILITY_STD_MAX &&
    f.lateEarlyRatio >= activePreset.lateRatioMin &&
    f.tauLateUs >= f.tauEarlyUs * 0.85f;

  const bool lowFreqOk =
    lowFreqMean <= activePreset.lowFreqNoiseMax &&
    f.lowFrequencyNoise <= activePreset.lowFreqNoiseMax;

  if (stableLate && lowFreqOk) {
    if (largeMassCandidateStartMs == 0) {
      largeMassCandidateStartMs = millis();
    }
  } else {
    largeMassCandidateStartMs = 0;
  }

  return largeMassCandidateStartMs > 0 && (millis() - largeMassCandidateStartMs) >= LARGE_MASS_CONFIRM_MS;
}

// -----------------------------
// Sniper Decision Matrix
// -----------------------------
float signalScoreFromFeatures(const DecayFeatures &f) {
  const float antiIron = clampf(100.0f - f.ironScore, 0.0f, 100.0f);
  const float antiSoil = clampf(100.0f - f.soilScore, 0.0f, 100.0f);

  return clampf(
    0.46f * f.goldScore +
    0.20f * antiIron +
    0.14f * antiSoil +
    0.12f * clampf((f.lateEarlyRatio - 0.25f) / 0.70f * 100.0f, 0.0f, 100.0f) +
    0.08f * clampf((1.0f - f.lowFrequencyNoise / 0.50f) * 100.0f, 0.0f, 100.0f),
    0.0f,
    100.0f
  );
}

SniperResult decisionEngine(float signal, float geoBias, const DecayFeatures &f) {
  SniperResult r{};
  r.signalScore = signal;
  r.geoBias = clampf(geoBias * 100.0f, 0.0f, 100.0f);
  r.stableLateDecay = isStableLateDecayLargeMass(f);
  r.lowFreqNoiseOk = f.lowFrequencyNoise <= activePreset.lowFreqNoiseMax;
  r.largeMass = r.stableLateDecay && r.lowFreqNoiseOk;

  const float quartzPocketBonus =
    clampf(nearestSilica / 100.0f, 0.0f, 1.0f) * 7.0f +
    clampf(nearestTerrain / 100.0f, 0.0f, 1.0f) * 4.0f -
    clampf(nearestIron / 100.0f, 0.0f, 1.0f) * activePreset.ironRejectStrength * 6.0f;

  r.weightedDecision = clampf(
    (signal * 0.68f) +
    (r.geoBias * 0.22f) +
    quartzPocketBonus,
    0.0f,
    100.0f
  );

  if (r.weightedDecision >= activePreset.sniperThreshold && r.largeMass && f.ironScore < 48.0f) {
    r.decision = DIG_CONFIRMED;
  } else if (r.weightedDecision >= activePreset.suspectThreshold && f.ironScore < 62.0f && f.lateEarlyRatio >= activePreset.lateRatioMin * 0.82f) {
    r.decision = SUSPECT_QUARTZ_POCKET;
  } else {
    r.decision = SCAN_CONTINUE;
  }

  return r;
}

bool shouldDig(float rawSignal, float geoBias, const DecayFeatures &f) {
  SniperResult r = decisionEngine(rawSignal, geoBias, f);
  return r.decision == DIG_CONFIRMED;
}

// -----------------------------
// SD Snapshot Logging
// -----------------------------
void writeSnapshotHeaderIfNeeded() {
  if (!SD.exists("dig_snapshots.csv")) {
    File file = SD.open("dig_snapshots.csv", FILE_WRITE);
    if (file) {
      file.println("timestamp_ms,frame,lat,lon,preset,tempC,gpsHdop,nearestDistanceM,priorityScore,geoBias,silica,iron,terrain,v0,tauUs,tauEarlyUs,tauLateUs,curvature,lateEarlyRatio,lowFrequencyNoise,residualRms,noiseFloor,goldScore,ironScore,soilScore,weightedDecision,largeMass,decision");
      file.close();
    }
  }
}

void logDigSnapshot(const DecayFeatures &f, const SniperResult &r) {
  if (millis() - lastSnapshotMs < SNAPSHOT_COOLDOWN_MS) return;
  lastSnapshotMs = millis();

  writeSnapshotHeaderIfNeeded();

  File file = SD.open("dig_snapshots.csv", FILE_WRITE);
  if (!file) return;

  file.print(millis()); file.print(",");
  file.print(frameCounter); file.print(",");
  file.print(currentLat, 7); file.print(",");
  file.print(currentLon, 7); file.print(",");
  file.print(activePreset.name); file.print(",");
  file.print(currentTempC, 2); file.print(",");
  file.print(gpsHdop, 2); file.print(",");
  file.print(nearestDistanceM, 2); file.print(",");
  file.print(nearestPriorityScore, 2); file.print(",");
  file.print(nearestGeoBias, 4); file.print(",");
  file.print(nearestSilica, 2); file.print(",");
  file.print(nearestIron, 2); file.print(",");
  file.print(nearestTerrain, 2); file.print(",");
  file.print(f.v0, 3); file.print(",");
  file.print(f.tauUs, 2); file.print(",");
  file.print(f.tauEarlyUs, 2); file.print(",");
  file.print(f.tauLateUs, 2); file.print(",");
  file.print(f.curvature, 6); file.print(",");
  file.print(f.lateEarlyRatio, 6); file.print(",");
  file.print(f.lowFrequencyNoise, 6); file.print(",");
  file.print(f.residualRms, 4); file.print(",");
  file.print(noiseFloor, 4); file.print(",");
  file.print(f.goldScore, 2); file.print(",");
  file.print(f.ironScore, 2); file.print(",");
  file.print(f.soilScore, 2); file.print(",");
  file.print(r.weightedDecision, 2); file.print(",");
  file.print(r.largeMass ? 1 : 0); file.print(",");
  file.println("DIG_CONFIRMED");

  file.close();
}

void triggerSniperAlert() {
  tone(PIN_BUZZER, 2000, 500);
  digitalWriteFast(PIN_LED, HIGH);
  Serial.println("SNIPER DECISION: LARGE MASS / QUARTZ POCKET PRIORITY - FIELD VERIFY NOW");
}

void triggerSuspectAlert() {
  tone(PIN_BUZZER, 780, 90);
  digitalWriteFast(PIN_LED, HIGH);
}

void triggerScanContinue() {
  noTone(PIN_BUZZER);
  digitalWriteFast(PIN_LED, LOW);
}

// -----------------------------
// Serial output
// -----------------------------
void printSniperFrame(const DecayFeatures &f, const SniperResult &r) {
  Serial.print("frame=");
  Serial.print(frameCounter);
  Serial.print(", preset=");
  Serial.print(activePreset.name);
  Serial.print(", lat=");
  Serial.print(currentLat, 6);
  Serial.print(", lon=");
  Serial.print(currentLon, 6);
  Serial.print(", signal=");
  Serial.print(r.signalScore, 1);
  Serial.print(", geoBias=");
  Serial.print(r.geoBias, 1);
  Serial.print(", weighted=");
  Serial.print(r.weightedDecision, 1);
  Serial.print(", tauLate=");
  Serial.print(f.tauLateUs, 1);
  Serial.print(", lateEarly=");
  Serial.print(f.lateEarlyRatio, 3);
  Serial.print(", lowFreq=");
  Serial.print(f.lowFrequencyNoise, 3);
  Serial.print(", iron=");
  Serial.print(f.ironScore, 1);
  Serial.print(", largeMass=");
  Serial.print(r.largeMass ? "YES" : "NO");
  Serial.print(", decision=");
  if (r.decision == DIG_CONFIRMED) Serial.println("DIG_CONFIRMED");
  else if (r.decision == SUSPECT_QUARTZ_POCKET) Serial.println("SUSPECT");
  else Serial.println("SCAN");
}

// -----------------------------
// Setup / loop
// -----------------------------
void setup() {
  pinMode(PIN_TX_GATE_A, OUTPUT);
  pinMode(PIN_TX_GATE_B, OUTPUT);
  pinMode(PIN_RX_BLANK, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_LED, OUTPUT);

  txOff();
  digitalWriteFast(PIN_RX_BLANK, HIGH);

  Serial.begin(115200);
  Serial1.begin(9600);

  while (!Serial && millis() < 3000) {}

  Serial.println("BOUH ZVT Sniper Geological Strategy booting...");

  configureADC_DMA_100kHz();

  if (SD.begin(PIN_SD_CS)) {
    loadPriorityFileFromSD();
    writeSnapshotHeaderIfNeeded();
  } else {
    Serial.println("SD not available. Snapshot logging disabled.");
  }

  frameTimer.begin(frameISR, static_cast<uint32_t>(activePreset.pulsePeriodUs));
  Serial.println("Sniper OS armed.");
}

void loop() {
  updateGps();
  selectPresetByLocation();
  updateGeoBiasFromPriority();
  thermalCompensation();

  if (!frameReady) return;

  noInterrupts();
  frameReady = false;
  interrupts();

  ADC_Sampling(rawDecay, DECAY_LEN);
  DecayFeatures f = extractDecayFeatures(rawDecay, DECAY_LEN);
  updateStabilityHistory(f);

  const float rawSignal = signalScoreFromFeatures(f);
  SniperResult result = decisionEngine(rawSignal, nearestGeoBias, f);

  if (result.decision == DIG_CONFIRMED) {
    triggerSniperAlert();
    logDigSnapshot(f, result);
  } else if (result.decision == SUSPECT_QUARTZ_POCKET) {
    triggerSuspectAlert();
  } else {
    triggerScanContinue();
  }

  static uint32_t lastPrint = 0;
  if (millis() - lastPrint >= 180) {
    lastPrint = millis();
    printSniperFrame(f, result);
  }
}
