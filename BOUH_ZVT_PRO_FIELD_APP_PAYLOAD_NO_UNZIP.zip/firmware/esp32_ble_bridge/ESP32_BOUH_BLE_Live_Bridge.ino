/*
  BOUH ESP32 BLE Bridge - Live Action System

  Function:
    - Receives live telemetry lines from Teensy over UART2.
    - Broadcasts them immediately via BLE Notify characteristic.
    - No SD upload required.
    - Compatible with Flutter app BLE client.

  Wiring example:
    Teensy TX -> ESP32 RX2 GPIO16
    Teensy GND -> ESP32 GND
    Optional ESP32 TX2 GPIO17 -> Teensy RX if command channel needed

  BLE:
    Device name: BOUH-ZVT-LIVE
    Service UUID: 6e400001-b5a3-f393-e0a9-e50e24dcca9e
    Notify UUID:  6e400003-b5a3-f393-e0a9-e50e24dcca9e

  Teensy should send newline-terminated packets:
    decision=DIG,lat=19.8251647,lon=36.7557669,gps=2.8,mineralization=0.76,geoBias=0.84,signal=91,weighted=88,tauLate=720,lateEarly=0.61,lowFreq=0.19,iron=27,gold=84,largeMass=1,temp=41.2,preset=SINKAT,seq=1024
*/

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

static const char *DEVICE_NAME = "BOUH-ZVT-LIVE";
static const char *SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";
static const char *CHAR_NOTIFY_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e";

static constexpr int UART_RX_PIN = 16;
static constexpr int UART_TX_PIN = 17;
static constexpr uint32_t UART_BAUD = 115200;
static constexpr size_t MAX_PACKET_LEN = 240;

BLECharacteristic *notifyCharacteristic = nullptr;
bool deviceConnected = false;
String lineBuffer;

class ServerCallbacks final : public BLEServerCallbacks {
  void onConnect(BLEServer *server) override {
    deviceConnected = true;
  }

  void onDisconnect(BLEServer *server) override {
    deviceConnected = false;
    BLEDevice::startAdvertising();
  }
};

void setupBle() {
  BLEDevice::init(DEVICE_NAME);
  BLEServer *server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());

  BLEService *service = server->createService(SERVICE_UUID);

  notifyCharacteristic = service->createCharacteristic(
    CHAR_NOTIFY_UUID,
    BLECharacteristic::PROPERTY_NOTIFY | BLECharacteristic::PROPERTY_READ
  );

  notifyCharacteristic->addDescriptor(new BLE2902());
  notifyCharacteristic->setValue("BOUH LIVE READY\n");

  service->start();

  BLEAdvertising *advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setScanResponse(true);
  advertising->setMinPreferred(0x06);
  advertising->setMinPreferred(0x12);
  BLEDevice::startAdvertising();
}

void notifyLine(const String &line) {
  if (!notifyCharacteristic || !deviceConnected) {
    return;
  }

  String payload = line;
  if (!payload.endsWith("\n")) {
    payload += "\n";
  }

  // BLE MTU can be small. Chunk safely.
  const int mtuChunk = 180;
  for (int start = 0; start < payload.length(); start += mtuChunk) {
    String chunk = payload.substring(start, min(start + mtuChunk, payload.length()));
    notifyCharacteristic->setValue((uint8_t *)chunk.c_str(), chunk.length());
    notifyCharacteristic->notify();
    delay(8);
  }
}

bool isPriorityPacket(const String &line) {
  return line.indexOf("decision=DIG") >= 0 ||
         line.indexOf("decision=SUSPECT") >= 0 ||
         line.indexOf("\"decision\":\"DIG\"") >= 0 ||
         line.indexOf("\"decision\":\"SUSPECT\"") >= 0 ||
         line.indexOf("\"decision\": \"DIG\"") >= 0 ||
         line.indexOf("\"decision\": \"SUSPECT\"") >= 0;
}

void processTeensyByte(char c) {
  if (c == '\r') return;

  if (c == '\n') {
    String line = lineBuffer;
    line.trim();
    lineBuffer = "";

    if (line.length() == 0) return;

    // Live Action rule:
    // DIG and SUSPECT go immediately.
    // SCAN can also be sent if you want continuous motion feedback.
    notifyLine(line);

    Serial.print("BLE OUT: ");
    Serial.println(line);
    return;
  }

  if (lineBuffer.length() < MAX_PACKET_LEN) {
    lineBuffer += c;
  } else {
    lineBuffer = "";
  }
}

void setup() {
  Serial.begin(115200);
  Serial2.begin(UART_BAUD, SERIAL_8N1, UART_RX_PIN, UART_TX_PIN);
  setupBle();
  Serial.println("BOUH ESP32 BLE Bridge Live started.");
}

void loop() {
  while (Serial2.available()) {
    processTeensyByte((char)Serial2.read());
  }

  // Optional USB debug injection
  while (Serial.available()) {
    processTeensyByte((char)Serial.read());
  }
}
