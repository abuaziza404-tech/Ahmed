package com.bouh.zvtpro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
