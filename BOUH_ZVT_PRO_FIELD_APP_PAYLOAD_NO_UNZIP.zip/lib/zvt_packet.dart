import 'dart:convert';

enum SniperDecision { scan, suspect, dig }

class ZvtPacket {
  const ZvtPacket({
    required this.decision,
    required this.latitude,
    required this.longitude,
    required this.gpsAccuracy,
    required this.mineralization,
    required this.geoBias,
    required this.signal,
    required this.weightedDecision,
    required this.tauLate,
    required this.lateEarlyRatio,
    required this.lowFrequencyNoise,
    required this.ironScore,
    required this.goldScore,
    required this.largeMass,
    required this.temperature,
    required this.preset,
    required this.timestamp,
    required this.sequence,
  });

  final SniperDecision decision;
  final double latitude;
  final double longitude;
  final double gpsAccuracy;
  final double mineralization;
  final double geoBias;
  final double signal;
  final double weightedDecision;
  final double tauLate;
  final double lateEarlyRatio;
  final double lowFrequencyNoise;
  final double ironScore;
  final double goldScore;
  final bool largeMass;
  final double temperature;
  final String preset;
  final DateTime timestamp;
  final int sequence;

  static ZvtPacket empty() => ZvtPacket(
        decision: SniperDecision.scan,
        latitude: 19.8251647,
        longitude: 36.7557669,
        gpsAccuracy: 2.2,
        mineralization: 0.40,
        geoBias: 0.32,
        signal: 26,
        weightedDecision: 34,
        tauLate: 170,
        lateEarlyRatio: 0.21,
        lowFrequencyNoise: 0.63,
        ironScore: 74,
        goldScore: 20,
        largeMass: false,
        temperature: 39,
        preset: 'SINKAT',
        timestamp: DateTime.now(),
        sequence: 0,
      );

  static ZvtPacket demo(int tick) {
    final phase = tick % 100;
    final isDig = phase > 78;
    final isSuspect = phase > 52 && !isDig;
    return ZvtPacket(
      decision: isDig ? SniperDecision.dig : isSuspect ? SniperDecision.suspect : SniperDecision.scan,
      latitude: 19.8251647 + phase * 0.000001,
      longitude: 36.7557669 + phase * 0.000001,
      gpsAccuracy: 2.2 + (phase % 8) * 0.35,
      mineralization: isDig ? 0.78 : isSuspect ? 0.64 : 0.40,
      geoBias: isDig ? 0.87 : isSuspect ? 0.66 : 0.32,
      signal: isDig ? 94 : isSuspect ? 71 : 26,
      weightedDecision: isDig ? 91 : isSuspect ? 68 : 34,
      tauLate: isDig ? 760 : isSuspect ? 480 : 170,
      lateEarlyRatio: isDig ? 0.64 : isSuspect ? 0.47 : 0.21,
      lowFrequencyNoise: isDig ? 0.16 : isSuspect ? 0.28 : 0.63,
      ironScore: isDig ? 22 : isSuspect ? 46 : 74,
      goldScore: isDig ? 88 : isSuspect ? 63 : 20,
      largeMass: isDig,
      temperature: 39 + (phase % 7),
      preset: phase < 34 ? 'ARBAAT' : phase < 67 ? 'SINKAT' : 'GEBEIT',
      timestamp: DateTime.now(),
      sequence: tick,
    );
  }

  factory ZvtPacket.fromBleLine(String line) {
    final trimmed = line.trim();
    if (trimmed.isEmpty) return ZvtPacket.empty();
    try {
      if (trimmed.startsWith('{')) {
        return ZvtPacket.fromMap(jsonDecode(trimmed) as Map<String, dynamic>);
      }
      final map = <String, dynamic>{};
      for (final part in trimmed.split(',')) {
        final index = part.indexOf('=');
        if (index > 0) {
          map[part.substring(0, index).trim()] = part.substring(index + 1).trim();
        }
      }
      return ZvtPacket.fromMap(map);
    } catch (_) {
      return ZvtPacket.empty();
    }
  }

  factory ZvtPacket.fromMap(Map<String, dynamic> map) {
    double d(String key, [double fallback = 0]) {
      final v = map[key];
      if (v is num) return v.toDouble();
      if (v is String) return double.tryParse(v) ?? fallback;
      return fallback;
    }

    int i(String key, [int fallback = 0]) {
      final v = map[key];
      if (v is int) return v;
      if (v is num) return v.toInt();
      if (v is String) return int.tryParse(v) ?? fallback;
      return fallback;
    }

    bool b(String key) {
      final v = map[key];
      if (v is bool) return v;
      if (v is num) return v != 0;
      if (v is String) return ['1', 'true', 'yes', 'y'].contains(v.toLowerCase());
      return false;
    }

    final rawDecision = '${map['decision'] ?? map['class'] ?? 'SCAN'}'.toUpperCase();
    final decision = rawDecision.contains('DIG')
        ? SniperDecision.dig
        : rawDecision.contains('SUSPECT')
            ? SniperDecision.suspect
            : SniperDecision.scan;

    return ZvtPacket(
      decision: decision,
      latitude: d('lat', 19.8251647),
      longitude: d('lon', 36.7557669),
      gpsAccuracy: d('gps', d('gpsAccuracy', 2.2)),
      mineralization: d('mineralization', 0.40),
      geoBias: d('geoBias', 0.32),
      signal: d('signal', 26),
      weightedDecision: d('weighted', d('weightedDecision', 34)),
      tauLate: d('tauLate', 170),
      lateEarlyRatio: d('lateEarly', 0.21),
      lowFrequencyNoise: d('lowFreq', 0.63),
      ironScore: d('iron', 74),
      goldScore: d('gold', 20),
      largeMass: b('largeMass'),
      temperature: d('temp', d('temperature', 39)),
      preset: '${map['preset'] ?? 'FIELD'}',
      timestamp: DateTime.now(),
      sequence: i('seq', i('sequence')),
    );
  }

  String get decisionLabel {
    switch (decision) {
      case SniperDecision.dig:
        return 'DIG';
      case SniperDecision.suspect:
        return 'SUSPECT';
      case SniperDecision.scan:
        return 'SCAN';
    }
  }
}
