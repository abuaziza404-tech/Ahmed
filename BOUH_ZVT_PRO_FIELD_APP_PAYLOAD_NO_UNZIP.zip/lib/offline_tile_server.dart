import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class OfflineTileServer {
  OfflineTileServer({this.assetPath = 'assets/offline/BOUH_FIELD_OFFLINE.mbtiles', this.port = 8765});
  final String assetPath;
  final int port;
  HttpServer? _server;
  Database? _db;

  Future<void> start() async {
    if (_server != null) return;
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/BOUH_FIELD_OFFLINE.mbtiles');
    if (!await file.exists() || await file.length() == 0) {
      final data = await rootBundle.load(assetPath);
      await file.writeAsBytes(data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes), flush: true);
    }
    _db = await openDatabase(file.path, readOnly: true);
    _server = await HttpServer.bind(InternetAddress.loopbackIPv4, port, shared: true);
    _server!.listen(_handle);
  }

  Future<void> stop() async {
    await _server?.close(force: true);
    await _db?.close();
    _server = null;
    _db = null;
  }

  Future<void> _handle(HttpRequest req) async {
    try {
      if (req.uri.path == '/health') {
        req.response.write('BOUH_OFFLINE_TILE_SERVER_OK');
        await req.response.close();
        return;
      }
      final p = req.uri.path.split('/').where((x) => x.isNotEmpty).toList();
      if (p.length != 4 || p[0] != 'tiles') {
        req.response.statusCode = HttpStatus.notFound;
        await req.response.close();
        return;
      }
      final z = int.parse(p[1]);
      final x = int.parse(p[2]);
      final y = int.parse(p[3].replaceAll('.png', ''));
      final tmsY = (1 << z) - 1 - y;
      final rows = await _db!.rawQuery(
        'SELECT tile_data FROM tiles WHERE zoom_level=? AND tile_column=? AND tile_row=? LIMIT 1',
        <Object?>[z, x, tmsY],
      );
      final bytes = rows.isEmpty ? _transparentPng : rows.first['tile_data'] as Uint8List;
      req.response.headers.contentType = ContentType('image', 'png');
      req.response.add(bytes);
      await req.response.close();
    } catch (_) {
      try { req.response.statusCode = 500; await req.response.close(); } catch (_) {}
    }
  }

  static final Uint8List _transparentPng = Uint8List.fromList(<int>[
    137,80,78,71,13,10,26,10,0,0,0,13,73,72,68,82,0,0,0,1,0,0,0,1,8,6,0,0,0,31,21,196,137,
    0,0,0,13,73,68,65,84,120,156,99,248,15,4,0,9,251,3,253,167,89,224,188,0,0,0,0,73,69,78,68,174,66,96,130
  ]);
}
