import 'dart:async';
import 'dart:convert';

import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

import 'zvt_packet.dart';

class BleSniperService {
  static final Guid serviceUuid = Guid('6e400001-b5a3-f393-e0a9-e50e24dcca9e');
  static final Guid notifyUuid = Guid('6e400003-b5a3-f393-e0a9-e50e24dcca9e');

  final StreamController<ZvtPacket> _packets = StreamController<ZvtPacket>.broadcast();
  final StreamController<String> _status = StreamController<String>.broadcast();

  Stream<ZvtPacket> get packets => _packets.stream;
  Stream<String> get status => _status.stream;

  BluetoothDevice? _device;
  BluetoothCharacteristic? _notifyCharacteristic;
  StreamSubscription<List<ScanResult>>? _scanSub;
  StreamSubscription<List<int>>? _notifySub;
  String _lineBuffer = '';

  Future<void> requestPermissions() async {
    await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse,
    ].request();
  }

  Future<void> connectLive({String deviceNamePrefix = 'BOUH'}) async {
    await requestPermissions();
    _status.add('LIVE SCAN: searching ESP32 bridge...');
    await FlutterBluePlus.stopScan();
    await _scanSub?.cancel();

    _scanSub = FlutterBluePlus.scanResults.listen((results) async {
      for (final result in results) {
        final name = '${result.device.platformName} ${result.advertisementData.advName}'.trim();
        final matchName = name.toUpperCase().contains(deviceNamePrefix.toUpperCase());
        final matchService = result.advertisementData.serviceUuids.contains(serviceUuid);
        if (matchName || matchService) {
          await FlutterBluePlus.stopScan();
          await _connect(result.device);
          return;
        }
      }
    });

    await FlutterBluePlus.startScan(timeout: const Duration(seconds: 15));
  }

  Future<void> _connect(BluetoothDevice device) async {
    _device = device;
    _status.add('Connecting ${device.platformName}...');
    await device.connect(autoConnect: false, timeout: const Duration(seconds: 15));
    final services = await device.discoverServices();

    for (final service in services) {
      for (final characteristic in service.characteristics) {
        final canNotify = characteristic.properties.notify || characteristic.properties.indicate;
        final match = characteristic.uuid == notifyUuid || service.uuid == serviceUuid;
        if (canNotify && match) {
          _notifyCharacteristic = characteristic;
          await characteristic.setNotifyValue(true);
          _notifySub = characteristic.lastValueStream.listen(_onBytes);
          _status.add('LIVE CONNECTED: packets streaming');
          return;
        }
      }
    }
    _status.add('BLE connected but notify characteristic not found');
  }

  void _onBytes(List<int> bytes) {
    _lineBuffer += utf8.decode(bytes, allowMalformed: true);
    while (_lineBuffer.contains('\n')) {
      final idx = _lineBuffer.indexOf('\n');
      final line = _lineBuffer.substring(0, idx).trim();
      _lineBuffer = _lineBuffer.substring(idx + 1);
      if (line.isNotEmpty) _packets.add(ZvtPacket.fromBleLine(line));
    }
  }

  Future<void> disconnect() async {
    await _notifySub?.cancel();
    _notifySub = null;
    if (_notifyCharacteristic != null) {
      try {
        await _notifyCharacteristic!.setNotifyValue(false);
      } catch (_) {}
    }
    if (_device != null) {
      try {
        await _device!.disconnect();
      } catch (_) {}
    }
    _device = null;
    _status.add('Disconnected');
  }

  Future<void> dispose() async {
    await disconnect();
    await _scanSub?.cancel();
    await _packets.close();
    await _status.close();
  }
}
