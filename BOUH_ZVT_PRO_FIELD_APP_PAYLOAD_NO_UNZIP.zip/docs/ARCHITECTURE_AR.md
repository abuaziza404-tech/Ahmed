# Architecture

```text
Teensy ZVT Sniper Firmware
→ Serial live packet
→ ESP32 BLE Bridge
→ Flutter BLE client
→ Native Radar + WebView Field Map
→ DIG/SUSPECT alert
```
