# رفع GitHub

فك الضغط وارفع محتويات المجلد مباشرة إلى جذر المستودع بحيث ترى:

```text
.github/workflows/build.yml
android/
assets/
firmware/
lib/
pubspec.yaml
README.md
```

ثم افتح Actions وشغّل workflow.
