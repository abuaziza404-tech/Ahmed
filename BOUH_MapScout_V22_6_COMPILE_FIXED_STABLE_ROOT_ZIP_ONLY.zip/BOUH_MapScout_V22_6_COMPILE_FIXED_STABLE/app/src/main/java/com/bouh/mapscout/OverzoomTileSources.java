
package com.bouh.mapscout;

import org.osmdroid.tileprovider.tilesource.XYTileSource;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.util.MapTileIndex;

public final class OverzoomTileSources {
    public static final int DISPLAY_MAX_ZOOM = 24;
    public static final int DEFAULT_NATIVE_MAX_ZOOM = 17;

    private OverzoomTileSources() {}

    public static OnlineTileSourceBase esriSatellite() {
        return overzoomXYZ("Esri Satellite Overzoom",
                "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
                DEFAULT_NATIVE_MAX_ZOOM, DISPLAY_MAX_ZOOM, ".jpg");
    }

    public static OnlineTileSourceBase osmRoads() {
        return overzoomXYZ("OSM Roads Overzoom",
                "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
                DEFAULT_NATIVE_MAX_ZOOM, DISPLAY_MAX_ZOOM, ".png");
    }

    public static OnlineTileSourceBase openTopo() {
        return overzoomXYZ("OpenTopo Overzoom",
                "https://a.tile.opentopomap.org/{z}/{x}/{y}.png",
                DEFAULT_NATIVE_MAX_ZOOM, DISPLAY_MAX_ZOOM, ".png");
    }

    public static OnlineTileSourceBase cartoLight() {
        return overzoomXYZ("Carto Light Overzoom",
                "https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png",
                DEFAULT_NATIVE_MAX_ZOOM, DISPLAY_MAX_ZOOM, ".png");
    }

    public static OnlineTileSourceBase customOverzoom(final String name, final String template, final int nativeMaxZoom, final int displayMaxZoom) {
        return overzoomXYZ(name, template, nativeMaxZoom, displayMaxZoom, ".png");
    }

    public static OnlineTileSourceBase overzoomXYZ(final String name, final String template, final int nativeMaxZoom, final int displayMaxZoom, final String ext) {
        return new XYTileSource(name, 0, displayMaxZoom, 256, ext, new String[]{template}) {
            @Override public String getTileURLString(long idx) {
                int reqZ = MapTileIndex.getZoom(idx);
                int reqX = MapTileIndex.getX(idx);
                int reqY = MapTileIndex.getY(idx);

                int nativeZ = Math.min(reqZ, nativeMaxZoom);
                int shift = Math.max(0, reqZ - nativeZ);
                int nativeX = shift == 0 ? reqX : (reqX >> shift);
                int nativeY = shift == 0 ? reqY : (reqY >> shift);

                return template
                        .replace("{z}", String.valueOf(nativeZ))
                        .replace("{x}", String.valueOf(nativeX))
                        .replace("{y}", String.valueOf(nativeY));
            }
        };
    }
}
