
package com.bouh.mapscout;

public class RemoteSensingEngine {
    public enum Mode { NATURAL, CLAY, IRON, PROSPECTING_RADAR }

    public static String formula(Mode m) {
        if(m == Mode.CLAY) return "Q/Clay: Quartz-Clay visual proxy. Real ratios require SWIR GeoTIFF/JP2.";
        if(m == Mode.IRON) return "Fe: Iron oxide visual thermal-style proxy. Real ratios require calibrated bands.";
        if(m == Mode.PROSPECTING_RADAR) return "P: Prospecting Radar mode combines pin terrain proxy + GPR bars.";
        return "Natural mode.";
    }
}
