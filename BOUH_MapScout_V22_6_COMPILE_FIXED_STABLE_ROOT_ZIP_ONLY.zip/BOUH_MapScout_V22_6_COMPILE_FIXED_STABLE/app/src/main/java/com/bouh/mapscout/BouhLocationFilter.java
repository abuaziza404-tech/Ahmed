
package com.bouh.mapscout;

import android.location.Location;
import org.osmdroid.util.GeoPoint;

public class BouhLocationFilter {
    private double lat = Double.NaN;
    private double lon = Double.NaN;
    private float accuracy = -1f;
    private float bearing = -1f;
    private long lastMs = 0L;

    private static final double MIN_MOVE_M = 2.0;
    private static final float BEARING_ALPHA = 0.18f;
    private static final double POS_ALPHA = 0.25;

    public boolean accept(Location loc) {
        if (loc == null) return false;
        if (Double.isNaN(lat)) return true;

        double d = distance(lat, lon, loc.getLatitude(), loc.getLongitude());
        float newAcc = loc.hasAccuracy() ? loc.getAccuracy() : 999f;
        boolean muchBetter = accuracy > 0 && newAcc + 4f < accuracy;
        boolean stale = System.currentTimeMillis() - lastMs > 10000L;

        return d >= MIN_MOVE_M || muchBetter || stale;
    }

    public GeoPoint update(Location loc) {
        double newLat = loc.getLatitude();
        double newLon = loc.getLongitude();

        if (Double.isNaN(lat)) {
            lat = newLat;
            lon = newLon;
        } else {
            lat = lat + POS_ALPHA * (newLat - lat);
            lon = lon + POS_ALPHA * (newLon - lon);
        }

        accuracy = loc.hasAccuracy() ? loc.getAccuracy() : accuracy;
        if (loc.hasBearing()) {
            bearing = smoothBearing(bearing, loc.getBearing(), BEARING_ALPHA);
        }
        lastMs = System.currentTimeMillis();
        return new GeoPoint(lat, lon);
    }

    public float getAccuracy() { return accuracy; }
    public float getBearing() { return bearing; }

    private float smoothBearing(float oldB, float newB, float alpha) {
        if (oldB < 0) return newB;
        float delta = ((newB - oldB + 540f) % 360f) - 180f;
        float out = oldB + alpha * delta;
        if (out < 0) out += 360f;
        if (out >= 360f) out -= 360f;
        return out;
    }

    private double distance(double lat1, double lon1, double lat2, double lon2) {
        double R = 6371000.0;
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2);
        double dp = Math.toRadians(lat2-lat1), dl = Math.toRadians(lon2-lon1);
        double a = Math.sin(dp/2)*Math.sin(dp/2) + Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
        return 2*R*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }
}
