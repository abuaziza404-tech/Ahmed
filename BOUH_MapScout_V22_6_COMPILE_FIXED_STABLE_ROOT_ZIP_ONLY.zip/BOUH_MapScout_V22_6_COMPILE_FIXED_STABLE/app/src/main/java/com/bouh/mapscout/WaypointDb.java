
package com.bouh.mapscout;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class WaypointDb extends SQLiteOpenHelper {
    public WaypointDb(Context c) { super(c, "bouh_v22_4.sqlite", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE waypoints(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "time TEXT, name TEXT, lat REAL, lon REAL, alt REAL, acc REAL, zoom REAL, layer TEXT," +
                "structure INTEGER, carrier INTEGER, trap INTEGER, feox INTEGER, score INTEGER, decision TEXT, report TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public long insert(Waypoint w) {
        android.content.ContentValues v = new android.content.ContentValues();
        v.put("time", w.time); v.put("name", w.name); v.put("lat", w.lat); v.put("lon", w.lon);
        v.put("alt", w.alt); v.put("acc", w.acc); v.put("zoom", w.zoom); v.put("layer", w.layer);
        v.put("structure", w.structure ? 1 : 0); v.put("carrier", w.carrier ? 1 : 0);
        v.put("trap", w.trap ? 1 : 0); v.put("feox", w.feox ? 1 : 0);
        v.put("score", w.score); v.put("decision", w.decision); v.put("report", w.report);
        return getWritableDatabase().insert("waypoints", null, v);
    }

    public ArrayList<Waypoint> all() {
        ArrayList<Waypoint> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT * FROM waypoints ORDER BY id ASC", null);
        try {
            while(c.moveToNext()) {
                Waypoint w = new Waypoint();
                w.time = c.getString(c.getColumnIndexOrThrow("time"));
                w.name = c.getString(c.getColumnIndexOrThrow("name"));
                w.lat = c.getDouble(c.getColumnIndexOrThrow("lat"));
                w.lon = c.getDouble(c.getColumnIndexOrThrow("lon"));
                w.alt = c.getDouble(c.getColumnIndexOrThrow("alt"));
                w.acc = (float)c.getDouble(c.getColumnIndexOrThrow("acc"));
                w.zoom = c.getDouble(c.getColumnIndexOrThrow("zoom"));
                w.layer = c.getString(c.getColumnIndexOrThrow("layer"));
                w.structure = c.getInt(c.getColumnIndexOrThrow("structure")) == 1;
                w.carrier = c.getInt(c.getColumnIndexOrThrow("carrier")) == 1;
                w.trap = c.getInt(c.getColumnIndexOrThrow("trap")) == 1;
                w.feox = c.getInt(c.getColumnIndexOrThrow("feox")) == 1;
                w.score = c.getInt(c.getColumnIndexOrThrow("score"));
                w.decision = c.getString(c.getColumnIndexOrThrow("decision"));
                w.report = c.getString(c.getColumnIndexOrThrow("report"));
                out.add(w);
            }
        } finally { c.close(); }
        return out;
    }

    public String csv() {
        StringBuilder sb = new StringBuilder("time,name,lat,lon,alt,acc,zoom,layer,structure,carrier,trap,feox,score,decision\n");
        for(Waypoint w: all()) {
            sb.append(clean(w.time)).append(",").append(clean(w.name)).append(",").append(w.lat).append(",").append(w.lon).append(",")
              .append(w.alt).append(",").append(w.acc).append(",").append(w.zoom).append(",").append(clean(w.layer)).append(",")
              .append(w.structure).append(",").append(w.carrier).append(",").append(w.trap).append(",").append(w.feox).append(",")
              .append(w.score).append(",").append(clean(w.decision)).append("\n");
        }
        return sb.toString();
    }

    public String kml() {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document><name>BOUH V22.4 Waypoints</name>");
        int i=1;
        for(Waypoint w: all()) {
            sb.append("<Placemark><name>").append(xml(w.decision)).append(" ").append(i++).append("</name>")
              .append("<description><![CDATA[Score ").append(w.score).append("<br>").append(clean(w.layer)).append("<br>").append(clean(w.report)).append("]]></description>")
              .append("<Point><coordinates>").append(w.lon).append(",").append(w.lat).append(",").append(w.alt).append("</coordinates></Point></Placemark>");
        }
        sb.append("</Document></kml>");
        return sb.toString();
    }

    private String clean(String s) { return s == null ? "" : s.replace(",", " ").replace("\n", " "); }
    private String xml(String s) { return s == null ? "" : s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"); }
}
