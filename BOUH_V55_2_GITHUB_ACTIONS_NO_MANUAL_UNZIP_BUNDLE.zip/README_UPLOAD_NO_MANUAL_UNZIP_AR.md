# BOUH V55.2 — GitHub Actions بدون فك ضغط يدوي

هذه الحزمة مصممة لكي ترفع ملف ZIP كما هو، بدون أن تفك ضغطه يدويًا.

## الملفات المطلوبة داخل المستودع

ارفع هذا الملف في جذر المستودع:

```text
BOUH_MapScout_V55_2_ANDROID_PAYLOAD_UPLOAD_ONLY.zip
```

وارفع ملف الـ workflow هنا:

```text
.github/workflows/build-bouh-v55-2-no-manual-unzip.yml
```

## ماذا يحدث بعد الرفع؟

GitHub Actions سيقوم تلقائيًا بـ:

```text
1. التحقق من وجود ZIP
2. اختبار سلامة ZIP
3. فك الضغط داخل GitHub Actions فقط
4. التحقق من بنية مشروع Android
5. تثبيت Java و Android SDK
6. بناء APK
7. إخراج app-debug.apk كـ Artifact
```

## أنت لا تحتاج إلى فك الضغط يدويًا

لا تفك ملف:

```text
BOUH_MapScout_V55_2_ANDROID_PAYLOAD_UPLOAD_ONLY.zip
```

ارفعه كما هو فقط.

## تشغيل البناء

من GitHub:

```text
Actions
→ Build BOUH MapScout V55.2 APK - ZIP Only
→ Run workflow
```

ثم بعد اكتمال البناء:

```text
Artifacts
→ BOUH_MapScout_V55_2_debug_apk
→ app-debug.apk
```
