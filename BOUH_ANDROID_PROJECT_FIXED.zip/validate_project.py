from pathlib import Path
import sys
import re

base = Path(__file__).resolve().parent
required = [
    "settings.gradle",
    "build.gradle",
    "gradle.properties",
    "app/build.gradle",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/res/values/styles.xml",
    "app/src/main/java/com/bouh/mapscout/MainActivity.java",
    "app/src/main/assets/BOUH_V55_2_Pro_Field_Radar_App.html",
]
missing = [p for p in required if not (base / p).exists()]
if missing:
    print("MISSING_FILES")
    for p in missing:
        print(p)
    sys.exit(1)

html = (base / "app/src/main/assets/BOUH_V55_2_Pro_Field_Radar_App.html").read_text(encoding="utf-8")
checks = {
    "html_contains_title": "BOUH V55.2" in html,
    "html_contains_data": "const CELLS=" in html,
    "html_contains_leaflet": "leaflet" in html.lower(),
    "html_contains_gps": "navigator.geolocation" in html,
}
failed = [k for k, v in checks.items() if not v]
if failed:
    print("FAILED_CHECKS")
    for f in failed:
        print(f)
    sys.exit(1)

manifest = (base / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
if 'android:name=".MainActivity"' not in manifest:
    print("MANIFEST_MAIN_ACTIVITY_MISSING")
    sys.exit(1)

main = (base / "app/src/main/java/com/bouh/mapscout/MainActivity.java").read_text(encoding="utf-8")
if "file:///android_asset/BOUH_V55_2_Pro_Field_Radar_App.html" not in main:
    print("ASSET_LOAD_PATH_MISSING")
    sys.exit(1)

print("PROJECT_VALIDATION_PASS")
