# BOUH MapScout V15 SUPREME-GPS

نسخة ميدانية مطورة:
- Satellite HD / OSM / Topo
- GPS + altitude + accuracy + speed + bearing
- HD zoom حتى 20 عند توفر البلاطات
- Grid 50m
- قياس المسافة والاتجاه من نقطة إلى مركز الخريطة
- حفظ أهداف و GPZ و SAMPLE
- تصدير CSV / KML / JSON
- قرار BOUH: Structure -> Carrier -> Trap -> FeOx
- قاعدة صدق: لا نسب طيفية من خريطة أو كاميرا؛ الطيف الحقيقي يحتاج GeoTIFF/RAW bands/DEM.

ارفع ZIP كما هو في جذر المستودع، ثم استخدم YAML المرسل في المحادثة.
