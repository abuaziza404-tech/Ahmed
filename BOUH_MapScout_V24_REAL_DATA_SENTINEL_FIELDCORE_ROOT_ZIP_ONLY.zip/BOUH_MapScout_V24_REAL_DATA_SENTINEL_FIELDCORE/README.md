# BOUH MapScout V24 Real Data Sentinel FieldCore

مبني على V23.2 العامل، لكن تم إيقاف النتائج الوهمية:
- لا يوجد Bedrock/GPR/Paleochannel افتراضي من الإحداثيات.
- التحليل يعتمد على شبكة محلية مشتقة من ملفات Sentinel-2 المرفوعة:
  B02, B03, B04, B08, B11, B12
- إذا كانت النقطة خارج شبكة North/Center/South يظهر OUTSIDE DATA.
- المؤشرات:
  Struct = texture/gradient proxy
  Alter = max(Iron/Clay/Quartz-SWIR)
  Noise = NDVI/vegetation noise risk
- Overzoom Z24 عاد كتكبير بصري فقط، وليس دقة حقيقية.
- GPS follow remains OFF by default.
