
package com.bouh.mapscout;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;

public class SentinelDataGrid {
    public static class Cell {
        public String zone;
        public double lat, lon, score, structure, iron, clay, quartz, ndvi, noise;
    }

    public static class Result {
        public boolean inside;
        public Cell cell;
        public double distanceM;
        public String decision;
        public String report;
    }

    private final ArrayList<Cell> cells = new ArrayList<>();
    private boolean loaded = false;

    public void load(Context ctx) {
        if (loaded) return;
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(ctx.getAssets().open("bouh_sentinel_grid_v24.csv"), "UTF-8"));
            String line = br.readLine(); // header
            while ((line = br.readLine()) != null) {
                String[] p = line.split(",");
                if (p.length < 10) continue;
                Cell c = new Cell();
                c.zone = p[0];
                c.lat = Double.parseDouble(p[1]);
                c.lon = Double.parseDouble(p[2]);
                c.score = Double.parseDouble(p[3]);
                c.structure = Double.parseDouble(p[4]);
                c.iron = Double.parseDouble(p[5]);
                c.clay = Double.parseDouble(p[6]);
                c.quartz = Double.parseDouble(p[7]);
                c.ndvi = Double.parseDouble(p[8]);
                c.noise = Double.parseDouble(p[9]);
                cells.add(c);
            }
            br.close();
            loaded = true;
        } catch(Exception e) {
            loaded = true;
        }
    }

    public Result nearest(double lat, double lon, boolean fieldStructure, boolean fieldCarrier, boolean fieldTrap, boolean fieldFe) {
        Result r = new Result();
        if (cells.isEmpty()) {
            r.inside = false;
            r.report = "لا توجد شبكة بيانات Sentinel داخل التطبيق.";
            return r;
        }

        Cell best = null;
        double bestM = Double.MAX_VALUE;
        for (Cell c: cells) {
            double d = distance(lat, lon, c.lat, c.lon);
            if (d < bestM) {
                bestM = d;
                best = c;
            }
        }

        r.cell = best;
        r.distanceM = bestM;
        // grid spacing is coarse sampled; allow up to 4500m from nearest cell; beyond = outside dataset
        r.inside = best != null && bestM <= 4500.0;

        if (!r.inside) {
            r.decision = "خارج نطاق البيانات";
            r.report = String.format(Locale.US,
                    "OUTSIDE DATA | nearest %.0fm\nهذه النقطة خارج شبكة North/Center/South المحملة. لا أعطي نتيجة وهمية.",
                    bestM);
            return r;
        }

        double fieldBoost = 0.0;
        if (fieldStructure) fieldBoost += 5.0;
        if (fieldCarrier) fieldBoost += 5.0;
        if (fieldTrap) fieldBoost += 3.0;
        if (fieldFe) fieldBoost += 2.0;

        double finalScore = Math.max(0, Math.min(100, best.score + fieldBoost));
        if (best.ndvi > 0.25) finalScore *= 0.65;

        if (finalScore >= 78) r.decision = "CLASS A DATA";
        else if (finalScore >= 62) r.decision = "CLASS B DATA";
        else if (finalScore >= 48) r.decision = "CLASS C CHECK";
        else r.decision = "LOW / REJECT";

        r.report = String.format(Locale.US,
                "%s | Score %.1f | %s\nNearest data cell: %.0fm\nStructure %.0f%% | Iron %.0f%% | Clay %.0f%% | Quartz/SWIR %.0f%%\nNDVI %.3f | Noise %.0f%%\nTruth: Sentinel-2 proxy only. No bedrock/GPR/gold depth claim.",
                r.decision, finalScore, best.zone, bestM,
                best.structure, best.iron, best.clay, best.quartz,
                best.ndvi, best.noise);
        return r;
    }

    private double distance(double lat1, double lon1, double lat2, double lon2) {
        double R = 6371000.0;
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2);
        double dp = Math.toRadians(lat2-lat1), dl = Math.toRadians(lon2-lon1);
        double a = Math.sin(dp/2)*Math.sin(dp/2) + Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
        return 2*R*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }
}
