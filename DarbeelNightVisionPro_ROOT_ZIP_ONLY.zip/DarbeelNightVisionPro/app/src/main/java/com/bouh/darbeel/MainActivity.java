package com.bouh.darbeel;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 7001;

    private NightVisionView nightView;
    private TextView statusText;
    private TextView modeText;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice cameraDevice;
    private CameraCaptureSession session;
    private CaptureRequest.Builder requestBuilder;
    private ImageReader imageReader;
    private String cameraId;
    private Rect sensorRect;
    private Float maxDigitalZoom = 1.0f;
    private Range<Integer> exposureRange = new Range<>(0, 0);
    private boolean hasFlash = false;
    private boolean torchEnabled = false;

    private int mode = 0;
    private float gain = 2.35f;
    private float contrast = 1.30f;
    private float gamma = 0.68f;
    private float zoom = 1.0f;
    private int exposureComp = 0;
    private long lastFrameMs = 0L;
    private int frameCounter = 0;
    private boolean hudVisible = true;
    private final String[] modeNames = {"GREEN NV", "WHITE BOOST", "AMBER DESERT", "EDGE SCOUT", "RED LOW-LIGHT"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildUi();
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        } else {
            startCamera();
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        nightView = new NightVisionView(this);
        root.addView(nightView, new FrameLayout.LayoutParams(-1, -1));
        nightView.setOnTouchListener((v, ev) -> {
            if (ev.getAction() == MotionEvent.ACTION_UP) {
                hudVisible = !hudVisible;
                int vis = hudVisible ? View.VISIBLE : View.GONE;
                findViewById(1001).setVisibility(vis);
                findViewById(1002).setVisibility(vis);
            }
            return true;
        });

        LinearLayout top = new LinearLayout(this);
        top.setId(1001);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(10), dp(8), dp(10), dp(6));
        top.setBackgroundColor(0x77000000);
        statusText = label("Darbeel Night Vision Pro V2 | camera warming...");
        modeText = label("Mode: GREEN NV | Zoom 1.0x | Gain 2.35 | Contrast 1.30");
        top.addView(statusText);
        top.addView(modeText);
        root.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setId(1002);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(8), dp(8), dp(8), dp(12));
        bottom.setBackgroundColor(0x66000000);

        LinearLayout row1 = new LinearLayout(this);
        row1.setGravity(Gravity.CENTER);
        row1.addView(btn("ZOOM +", v -> { zoom = clamp(zoom + 0.5f, 1f, Math.max(1f, maxDigitalZoom)); updateRepeating(); updateHud(); }));
        row1.addView(btn("ZOOM -", v -> { zoom = clamp(zoom - 0.5f, 1f, Math.max(1f, maxDigitalZoom)); updateRepeating(); updateHud(); }));
        row1.addView(btn("GAIN +", v -> { gain = clamp(gain + 0.25f, 1f, 9f); updateHud(); }));
        row1.addView(btn("GAIN -", v -> { gain = clamp(gain - 0.25f, 1f, 9f); updateHud(); }));

        LinearLayout row2 = new LinearLayout(this);
        row2.setGravity(Gravity.CENTER);
        row2.addView(btn("MODE", v -> { mode = (mode + 1) % modeNames.length; updateHud(); }));
        row2.addView(btn("LIGHT", v -> { torchEnabled = !torchEnabled; updateRepeating(); updateHud(); }));
        row2.addView(btn("EXP +", v -> { exposureComp = Math.min(exposureComp + 1, exposureRange.getUpper()); updateRepeating(); updateHud(); }));
        row2.addView(btn("EXP -", v -> { exposureComp = Math.max(exposureComp - 1, exposureRange.getLower()); updateRepeating(); updateHud(); }));
        row2.addView(btn("CAPTURE", v -> saveCurrentFrame()));

        LinearLayout row3 = new LinearLayout(this);
        row3.setGravity(Gravity.CENTER);
        row3.addView(btn("GAMMA +", v -> { gamma = clamp(gamma + 0.04f, 0.42f, 1.20f); updateHud(); }));
        row3.addView(btn("GAMMA -", v -> { gamma = clamp(gamma - 0.04f, 0.42f, 1.20f); updateHud(); }));
        row3.addView(btn("CON +", v -> { contrast = clamp(contrast + 0.10f, 0.80f, 2.40f); updateHud(); }));
        row3.addView(btn("CON -", v -> { contrast = clamp(contrast - 0.10f, 0.80f, 2.40f); updateHud(); }));
        row3.addView(btn("RESET", v -> { gain = 2.35f; contrast = 1.30f; gamma = 0.68f; zoom = 1f; exposureComp = 0; torchEnabled = false; updateRepeating(); updateHud(); }));

        bottom.addView(row1);
        bottom.addView(row2);
        bottom.addView(row3);
        root.addView(bottom, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        setContentView(root);
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xff9cff9c);
        t.setTextSize(13f);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private Button btn(String s, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(10f);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

    private void startCamera() {
        cameraThread = new HandlerThread("DarbeelCameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        cameraHandler.post(this::openCameraInternal);
    }

    private void openCameraInternal() {
        try {
            CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            cameraId = chooseBackCamera(manager);
            if (cameraId == null) {
                runOnUiThread(() -> statusText.setText("No usable camera found."));
                return;
            }
            CameraCharacteristics cc = manager.getCameraCharacteristics(cameraId);
            sensorRect = cc.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            Float zoomMax = cc.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            if (zoomMax != null) maxDigitalZoom = Math.min(12.0f, Math.max(1.0f, zoomMax));
            Range<Integer> exp = cc.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            if (exp != null) exposureRange = exp;
            Boolean flash = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            hasFlash = flash != null && flash;
            Size size = chooseAnalysisSize(cc);
            imageReader = ImageReader.newInstance(size.getWidth(), size.getHeight(), android.graphics.ImageFormat.YUV_420_888, 3);
            imageReader.setOnImageAvailableListener(reader -> {
                Image image = null;
                try {
                    image = reader.acquireLatestImage();
                    if (image != null) processImage(image);
                } catch (Exception ignored) {
                } finally {
                    if (image != null) image.close();
                }
            }, cameraHandler);
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice camera) { cameraDevice = camera; createSession(); }
                @Override public void onDisconnected(CameraDevice camera) { camera.close(); cameraDevice = null; }
                @Override public void onError(CameraDevice camera, int error) { camera.close(); cameraDevice = null; runOnUiThread(() -> statusText.setText("Camera error: " + error)); }
            }, cameraHandler);
        } catch (Exception e) {
            runOnUiThread(() -> statusText.setText("Camera open failed: " + e.getMessage()));
        }
    }

    private String chooseBackCamera(CameraManager manager) throws CameraAccessException {
        for (String id : manager.getCameraIdList()) {
            CameraCharacteristics cc = manager.getCameraCharacteristics(id);
            Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
            if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) return id;
        }
        String[] ids = manager.getCameraIdList();
        return ids.length > 0 ? ids[0] : null;
    }

    private Size chooseAnalysisSize(CameraCharacteristics cc) {
        android.hardware.camera2.params.StreamConfigurationMap map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        if (map == null) return new Size(640, 480);
        Size[] sizes = map.getOutputSizes(android.graphics.ImageFormat.YUV_420_888);
        if (sizes == null || sizes.length == 0) return new Size(640, 480);
        Arrays.sort(sizes, (a, b) -> Integer.compare(a.getWidth() * a.getHeight(), b.getWidth() * b.getHeight()));
        Size best = sizes[0];
        for (Size s : sizes) {
            int pixels = s.getWidth() * s.getHeight();
            if (pixels <= 1280 * 720 && pixels >= best.getWidth() * best.getHeight()) best = s;
        }
        return best;
    }

    private void createSession() {
        try {
            Surface surface = imageReader.getSurface();
            requestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            requestBuilder.addTarget(surface);
            ArrayList<Surface> surfaces = new ArrayList<>();
            surfaces.add(surface);
            cameraDevice.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession s) {
                    session = s;
                    updateRepeating();
                    runOnUiThread(() -> { statusText.setText("Live digital night binocular active. Tap screen to hide/show controls."); updateHud(); });
                }
                @Override public void onConfigureFailed(CameraCaptureSession s) { runOnUiThread(() -> statusText.setText("Camera session failed.")); }
            }, cameraHandler);
        } catch (Exception e) {
            runOnUiThread(() -> statusText.setText("Session failed: " + e.getMessage()));
        }
    }

    private void updateRepeating() {
        if (requestBuilder == null || session == null) return;
        try {
            requestBuilder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
            requestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            requestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            requestBuilder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, exposureComp);
            requestBuilder.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_FAST);
            requestBuilder.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_FAST);
            if (hasFlash) requestBuilder.set(CaptureRequest.FLASH_MODE, torchEnabled ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            if (sensorRect != null && zoom > 1f) requestBuilder.set(CaptureRequest.SCALER_CROP_REGION, cropForZoom(sensorRect, zoom));
            else requestBuilder.set(CaptureRequest.SCALER_CROP_REGION, sensorRect);
            session.setRepeatingRequest(requestBuilder.build(), null, cameraHandler);
        } catch (Exception e) {
            runOnUiThread(() -> statusText.setText("Camera update failed: " + e.getMessage()));
        }
    }

    private Rect cropForZoom(Rect sensor, float z) {
        int w = sensor.width();
        int h = sensor.height();
        int cw = (int) (w / z);
        int ch = (int) (h / z);
        int left = sensor.left + (w - cw) / 2;
        int top = sensor.top + (h - ch) / 2;
        return new Rect(left, top, left + cw, top + ch);
    }

    private void processImage(Image image) {
        Image.Plane yPlane = image.getPlanes()[0];
        ByteBuffer yBuf = yPlane.getBuffer();
        int width = image.getWidth();
        int height = image.getHeight();
        int rowStride = yPlane.getRowStride();
        int pixelStride = yPlane.getPixelStride();
        Bitmap out = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        int[] pixels = new int[width * height];
        byte[] data = new byte[yBuf.remaining()];
        yBuf.get(data);

        int idx = 0;
        for (int y = 0; y < height; y++) {
            int row = y * rowStride;
            for (int x = 0; x < width; x++) {
                int pos = row + x * pixelStride;
                int lum = pos < data.length ? (data[pos] & 0xff) : 0;
                int enhanced = enhance(lum, x, y, width, height, data, rowStride, pixelStride);
                pixels[idx++] = colorize(enhanced);
            }
        }
        out.setPixels(pixels, 0, width, 0, 0, width, height);
        nightView.setFrame(out);
        frameCounter++;
        long now = System.currentTimeMillis();
        if (now - lastFrameMs > 1000) {
            int fps = frameCounter;
            frameCounter = 0;
            lastFrameMs = now;
            runOnUiThread(() -> statusText.setText("Active | FPS " + fps + " | Flash " + (hasFlash ? (torchEnabled ? "ON" : "OFF") : "N/A") + " | Tap screen hides HUD"));
        }
    }

    private int enhance(int lum, int x, int y, int w, int h, byte[] data, int rowStride, int pixelStride) {
        float normalized = lum / 255f;
        normalized = (float) Math.pow(normalized, gamma);
        float v = normalized * gain;
        v = ((v - 0.5f) * contrast) + 0.5f;
        if ((mode == 3 || mode == 4) && x > 1 && y > 1 && x < w - 2 && y < h - 2) {
            int c = lumAt(data, x, y, rowStride, pixelStride);
            int r = lumAt(data, x + 1, y, rowStride, pixelStride);
            int d = lumAt(data, x, y + 1, rowStride, pixelStride);
            int l = lumAt(data, x - 1, y, rowStride, pixelStride);
            int u = lumAt(data, x, y - 1, rowStride, pixelStride);
            int edge = Math.abs(c - r) + Math.abs(c - d) + Math.abs(c - l) + Math.abs(c - u);
            v += edge / 510f * 0.50f;
        }
        return (int) clamp(v * 255f, 0f, 255f);
    }

    private int lumAt(byte[] data, int x, int y, int rowStride, int pixelStride) {
        int pos = y * rowStride + x * pixelStride;
        return pos >= 0 && pos < data.length ? (data[pos] & 0xff) : 0;
    }

    private int colorize(int v) {
        switch (mode) {
            case 1: return Color.rgb(v, v, v);
            case 2: return Color.rgb(v, Math.min(255, (int)(v * 0.64f)), Math.min(255, (int)(v * 0.20f)));
            case 3: return Color.rgb(Math.min(255, (int)(v * 0.35f)), v, Math.min(255, (int)(v * 0.25f)));
            case 4: return Color.rgb(v, Math.min(120, (int)(v * 0.22f)), Math.min(120, (int)(v * 0.18f)));
            default: return Color.rgb(Math.min(255, (int)(v * 0.18f)), v, Math.min(255, (int)(v * 0.18f)));
        }
    }

    private void updateHud() {
        runOnUiThread(() -> modeText.setText(String.format(Locale.US,
                "Mode: %s | Zoom %.1fx/%.1fx | Gain %.2f | Gamma %.2f | Contrast %.2f | EXP %+d | Light %s",
                modeNames[mode], zoom, maxDigitalZoom, gain, gamma, contrast, exposureComp, torchEnabled ? "ON" : "OFF")));
    }

    private void saveCurrentFrame() {
        Bitmap bmp = nightView.copyFrame();
        if (bmp == null) {
            Toast.makeText(this, "No frame ready yet.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            String fileName = "Darbeel_V2_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".png";
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DarbeelNightVision");
            }
            ContentResolver resolver = getContentResolver();
            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("MediaStore insert failed");
            try (OutputStream os = resolver.openOutputStream(uri)) {
                if (os == null) throw new IllegalStateException("Output stream failed");
                bmp.compress(Bitmap.CompressFormat.PNG, 100, os);
            }
            Toast.makeText(this, "Saved: Pictures/DarbeelNightVision/" + fileName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startCamera();
        else statusText.setText("Camera permission required.");
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { if (session != null) session.close(); } catch (Exception ignored) {}
        try { if (cameraDevice != null) cameraDevice.close(); } catch (Exception ignored) {}
        try { if (imageReader != null) imageReader.close(); } catch (Exception ignored) {}
        if (cameraThread != null) cameraThread.quitSafely();
    }

    public static class NightVisionView extends View {
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Bitmap frame;
        private final Object lock = new Object();

        public NightVisionView(Context context) {
            super(context);
            textPaint.setColor(0xaa9cff9c);
            textPaint.setTextSize(32f);
        }

        public void setFrame(Bitmap bmp) {
            synchronized (lock) {
                if (frame != null && frame != bmp && !frame.isRecycled()) frame.recycle();
                frame = bmp;
            }
            postInvalidate();
        }

        public Bitmap copyFrame() {
            synchronized (lock) {
                return frame == null ? null : frame.copy(Bitmap.Config.ARGB_8888, false);
            }
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(Color.BLACK);
            Bitmap local;
            synchronized (lock) { local = frame; }
            if (local == null) {
                canvas.drawText("Waiting for camera frame...", 40, getHeight() / 2f, textPaint);
                return;
            }
            Rect src = new Rect(0, 0, local.getWidth(), local.getHeight());
            RectF dst = fitCenterCrop(local.getWidth(), local.getHeight(), getWidth(), getHeight());
            canvas.drawBitmap(local, src, dst, paint);
            drawReticle(canvas);
            drawVignette(canvas);
        }

        private RectF fitCenterCrop(int bw, int bh, int vw, int vh) {
            float scale = Math.max(vw / (float) bw, vh / (float) bh);
            float dw = bw * scale;
            float dh = bh * scale;
            float left = (vw - dw) / 2f;
            float top = (vh - dh) / 2f;
            return new RectF(left, top, left + dw, top + dh);
        }

        private void drawReticle(Canvas c) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(0x889cff9c);
            p.setStrokeWidth(2f);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = Math.min(getWidth(), getHeight()) * 0.18f;
            c.drawCircle(cx, cy, r, p);
            c.drawCircle(cx, cy, r * 0.55f, p);
            c.drawLine(cx - 70, cy, cx - 15, cy, p);
            c.drawLine(cx + 15, cy, cx + 70, cy, p);
            c.drawLine(cx, cy - 70, cx, cy - 15, p);
            c.drawLine(cx, cy + 15, cx, cy + 70, p);
        }

        private void drawVignette(Canvas c) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(18f);
            p.setColor(0x66000000);
            c.drawOval(new RectF(8, 8, getWidth() - 8, getHeight() - 8), p);
        }
    }
}
