# Darbeel Night Vision Pro - no custom shrinking rules required.
